#!/usr/bin/perl
use strict;
use bytes;

$/ = undef;

my $d    = <>;
my $b    = '';
my $data = '';

sub parity($) { my ($b) = @_;
  my $bits = sprintf("%08b", ord($b));
  my $even = 0;

  print "$bits (", ord($b), ") => "; 

  while ($bits =~ /(.)/g) { ++$even if $1 eq '1'; }
   if ($even % 2 == 0) {
     $bits =~ s/^(.{7}).$/$1/;
     return $bits;
   }
   else {
     return '';
   }
}

while ($d =~ /(.)/g) {
  my $byte = parity($1);
  print "$byte\n";
  $data .= $byte;
}

#while ($data =~ /(.{8})/g) {
#  print oct("0b$1"), "\n";
#}

