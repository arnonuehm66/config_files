#!/usr/bin/perl
# !!!use the following Line to define the Perl Executable-Path!!!
# Path: C:\Perl64\bin\perl.exe
# !!!use the following Line to define further Commandline-Arguments!!!
# Arguments: -h
#*******************************************************************************
#** Name: skeleton.pl
#** Purpose:  What the program do.
#** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
#*******************************************************************************
#** Date        User  Changelog
#**-----------------------------------------------------------------------------
#** 09.01.2017  JE    Created program.
#** nn.nn.nnnn  JE    Now process 1 GiB chunks with 1024 Bytes overlap.
#** nn.nn.nnnn  JE    Adjusted usage text accordingly.
#** nn.nn.nnnn  JE    Adjusted function calls to new scheme.
#** nn.nn.nnnn  JE    Added initGlobalRegexes() and initGlobalVars().
#** nn.nn.nnnn  JE    Added setByteClass() to set byte class regex depending
#**                   Perl version.
#** nn.nn.nnnn  JE    Addded '--byteclass' to set byte regex for debugging.
#** nn.nn.nnnn  JE    Changed makeCoor() interface and name to utm2wgs84().
#** nn.nn.nnnn  JE    Changed Encode function from decode() to from_to().
#** nn.nn.nnnn  JE    Adjusted getOptions() to be able to pars a literal '0'.
#** nn.nn.nnnn  JE    Expanded dispatchErrors() with optional argument.
#** nn.nn.nnnn  JE    Adjusted UTF16-LE regex with negative lookahead.
#** nn.nn.nnnn  JE    Renamed  and extended dispatchError() with optional text.
#** nn.nn.nnnn  JE    Now all arguments are stored in the hash var '%g_a'.
#** nn.nn.nnnn  JE    Added setIfUndef() handling '%g_a'.
#** nn.nn.nnnn  JE    Simplified getMeName().
#** nn.nn.nnnn  JE    Added $g_meworkdir = getWorkDir().
#** nn.nn.nnnn  JE    Added findIt() and its wrapper findPath().
#** nn.nn.nnnn  JE    Added '--scalp3g' for SCalP3G support.
#** 02.03.2018  JE    Added global column var for SCalP3G to be adjustable.
#** 08.03.2018  JE    Added  file chunk variables to global arguments hash.
#** 17.04.2018  JE    Added  retValIfEmpty().
#** 29.05.2018  JE    Improved splitFile() with inline quotemeta regex.
#** 18.07.2018  JE    Added round().
#** 19.09.2018  JE    Changed stamp2utc() and utc2stamp() to ticks2utc() and
#**                   utc2ticks().
#** 14.02.2020  JE    Changed all pos(), $`, $& and $´ calcs to $-[N] and $+[N].
#** 20.03.2020  JE    Now getOptions() dispatch errors on its own.
#*******************************************************************************
#** Skript tested with:
#** TestDvice 123a.
#*******************************************************************************


#*******************************************************************************
#* pragmas

use 5.014;
use strict;
use bytes;                  # Remove if no byte semantics for strings is needed
use Encode qw/from_to/;     # Use if UTF conversion is needed.
use Math::Trig;             # for utm2wgs84()
use Time::Local qw(timegm); # for utc2ticks()
use Cwd;                    # for getWorkDir()
use File::Find;             # for findIt(), findPath()


#*******************************************************************************
#* infos

my $g_meversion           = '0.0.62';
my $g_mename              = getMeName();
my $g_meuser              = getMeUser();
my $g_meworkdir           = getWorkDir();
my $g_isWin32             = getIsOsWin();   # Must be prior to getMeHome()!
my $g_mehome              = getMeHome();
my ($g_merows, $g_mecols) = getTermSize();


#*******************************************************************************
#* constants

# usage()
use constant ERR_NOERR => 0x00;
use constant ERR_ARGS  => 0x01;
use constant ERR_FILE  => 0x02;
use constant ERR_ELSE  => 0xff;

use constant sERR_ARGS => 'Argument error';
use constant sERR_FILE => 'File error';
use constant sERR_ELSE => 'Unknown error';

# SCalP3G support
use constant HDG_NONE => 0x00;
use constant HDG_HEAD => 0x01;
use constant HDG_LINE => 0x02;

# utm2wgs84()
use constant iRADIUS => 6371000;          # Original value
use constant dPI     => 3.14159265358979; # acos(-1) :o)

# cmd(): Terminal colors.
use constant COL_OK     => "\033[01;32m";
use constant COL_FAILED => "\033[01;31m";
use constant COL_OFF    => "\033[00m";


#*******************************************************************************
#* global variables

# Test array.
my @g_test = ();

# Precisions and types.
my %g_prec = ();
my %g_type = ();

# Composition of entry.
my %g_e = ();

# Global var container.
my %g_ = ();

# SCalP3G support.
my %g_off   = ();   # Offsets for 'CreateVMO'.
my $g_nRows = 1000; # Max number of rows. For now it's fixed.
my $g_nCols = 13;   # Number of columns beeing written to stdout.

# Regexes.
my $g_C  = '';
my %g_rx = ();

# Arguments
my %g_a    = ();
my @g_args = ();


#*******************************************************************************
#* functions

#*******************************************************************************
#* Name:  version
#* Purpose: Prints version of script and end it.
#*******************************************************************************
sub version() {
  print "$g_mename v$g_meversion\n";
  exit(ERR_NOERR);
}

#*******************************************************************************
#* Name:  getMeName
#* Purpose: Gets calling name of the script.
#*******************************************************************************
sub getMeName() {
  $0 =~ /([^\\\/]+)$/;
  return $1;
}

#*******************************************************************************
#* Name:  getMeUser
#* Purpose: Gets my log in user name.
#*******************************************************************************
sub getMeUser() {
  my $user = ($ENV{"SUDO_USER"} ne '') ? $ENV{"SUDO_USER"} : $ENV{"USER"};
  return ($user ne '') ? $user : $ENV{"USERNAME"};  # if $g_isWin32;
}

#*******************************************************************************
#* Name:  getWorkDir
#* Purpose: Gets the working directory the perl way.
#*******************************************************************************
sub getWorkDir() {
  my $wd = cwd();
  return $wd;
}

#*******************************************************************************
#* Name:  getIsOsWin
#* Purpose: Gets OS the script is running. It's Win32 or else.
#*******************************************************************************
sub getIsOsWin() {
  return ($^O eq 'MSWin32') ? 1 : 0;
}

#*******************************************************************************
#* Name:  getMeHome
#* Purpose: Gets my home directory.
#*******************************************************************************
sub getMeHome() {
  my $user = ($ENV{"SUDO_USER"} ne '') ? $ENV{"SUDO_USER"} : $ENV{"USER"};
  my $home = ($user eq 'root') ? '/root' : "/home/$user";
  
  $home = $ENV{"USERPROFILE"} if $g_isWin32;
  $home = addSlash($home);
  return $home;
}

#*******************************************************************************
#* Name:  getTermSize
#* Purpose: Get size of terminal.
#*******************************************************************************
sub getTermSize() {
  my ($rows, $cols) = split(/ /, `/bin/stty size`);
  chomp($rows, $cols);
  return ($rows, $cols);
}

#*******************************************************************************
#* Name:  getNetIfs
#* Purpose: Get network interfaces.
#*******************************************************************************
sub getNetIfs($) { my ($if) = @_;
  my $ifs = `/sbin/ifconfig -a`;
  my @ifs = ();

  while ($ifs =~ m/^($if.+?)\b/g) {
    push(@ifs, $1);
  }
  return @ifs;
}

#*******************************************************************************
#* Name:  usage
#* Purpose: Prints usage of script and end it.
#*******************************************************************************
sub usage($;$) { my ($err, $txt) = @_;
  my $msg = '';

  # Ensure text ends appropriate, if printed.
  chomp($txt);
  $txt = "$txt\n\n" if defined $txt;

  #Summary:************************ 80 chars width ****************************************
  $msg .= "usage: $g_mename [-t] [-o] [-x n] [-p] file1 [file2 ...]\n";
  $msg .= "       $g_mename [--chunksize n] [--overlap n] ...\n";
  $msg .= "       $g_mename [-h|--help|-v|--version]\n";
  $msg .= " This will the program maybe do.\n";
  $msg .= " Searches images in chunks of 1GiB plus 1024 overlapped bytes per default.\n";
  $msg .= " '--chunksize' and '--overlap' can be entered as hexadecimal with '0x' prefix\n";
  $msg .= " or as decimal with post-fix K, M, G (meaning Kilo- Mega- and Gigabytes\n";
  $msg .= " based on 1024).\n";
  $msg .= "  -t:            don't execute printed commands (default execute)\n";
  $msg .= "  -o:            print additional offset column\n";
  $msg .= "  -x n:          this is an option eating n\n";
  $msg .= "  -p:            print progress of last match occured in file to stderr\n";
  $msg .= "  --chunksize n  memory size been looped over to be searched (default 1GiB)\n";
  $msg .= "  --overlap n    overlapped memory being at start of next loop (default 1KiB)\n";
#   $msg .= "  --scalp3g:     enable SCalP3G support\n";
#   $msg .= "  --byteclass    set internal byte class (i.e. '\\C' or '[\\x00-\\xff]')\n";
  $msg .= "  -h|--help:     print this help\n";
  $msg .= "  -v|--version:  print version of program\n";
  #Summary:************************ 80 chars width ****************************************

  # Print to appropriate output channel.
  if ($err == ERR_NOERR) {
    print STDOUT "$txt$msg";
  }
  else {
    print STDERR "$txt$msg";
  }
  
  exit($err);
}

#*******************************************************************************
#* Name:  dispatchError
#* Purpose: Print out specific error message, if any occurres.
#*******************************************************************************
sub dispatchError(@) { my ($rv, $msg) = @_;
  my $txt = ($msg ne '') ? ": $msg" : '';
  
  usage(ERR_ARGS, sERR_ARGS . $txt) if $rv == ERR_ARGS;
  usage(ERR_FILE, sERR_FILE . $txt) if $rv == ERR_FILE;
  usage(ERR_ELSE, sERR_ELSE . $txt) if $rv == ERR_ELSE;
}

#*******************************************************************************
#* Name:  getParm
#* Purpose: Converts parameter entered as hexadecimal with '0x' prefix or as
#*          decimal with postfix K, M, G (meaning Kilo- Mega- and Giga-bytes
#*          based on 1024).
#*******************************************************************************
sub getParm($) { my ($parm) = @_;
  my $post = '';
  my $val  = 0;

  # Hex
  if ($parm =~ /^0x(.*)$/) {
    return hex($1);
  }

  # Postfix
  if ($parm =~ /([KMGkmg])$/) {
    $post = $1;
    $parm =~ s/[KMGkmg]$//;
    $val  = $parm * 1024               if $post eq 'K' or $post eq 'k';
    $val  = $parm * 1024 * 1024        if $post eq 'M' or $post eq 'm';
    $val  = $parm * 1024 * 1024 * 1024 if $post eq 'G' or $post eq 'g';
    return $val;
  }

  # Decimal
  return $parm;
}

#*******************************************************************************
#* Name:  removeSlash
#* Purpose: Removes slash to path if existing. Do not alter empty or undef paths.
#*******************************************************************************
sub removeSlash($) { my ($path) = @_;
  $path =~ s/[\/\\]$//;
  return $path;
}

#*******************************************************************************
#* Name:  addSlash
#* Purpose: Adds slash to path if missing. Do not alter empty or undef paths.
#*******************************************************************************
sub addSlash($) { my ($path)  = @_;
  my $slash = ($g_isWin32) ? '\\' : '/';
  $path =~ s/(.*[^\/])$/$1$slash/;
  return $path;
}

#*******************************************************************************
#* Name:  retValIfEmpty
#* Purpose: Returns var's value or '-'.
#*******************************************************************************
sub retValIfEmpty($) { my ($var) = @_;
  return ($var eq '') ? '-' : $var;
}

#*******************************************************************************
#* Name:  setIfUndef
#* Purpose: Set global argument only if its undef.
#*******************************************************************************
sub setIfUndef($$) { my ($key, $val) = @_;
  $g_a{$key} = $val if not defined $g_a{$key};
}

#*******************************************************************************
#* Name:  getOptions
#* Purpose: Filters command line.
#*******************************************************************************
sub getOptions(@) { my (@args) = @_;
  my $arg = '';
  my $opt = '';
  
  # Set arguments's defaults.
  $g_a{'testMode'} = 0;
  $g_a{'prtOff'}   = 0;
  $g_a{'optX'}     = 'hello';
  $g_a{'prtPrgrs'} = 0;
  
  # File chunk variables.
  $g_a{'fcChunk'} = 0x40000000;  # 1 GiB
  $g_a{'fcTwice'} = 0x400;       # 1 KiB
  
  # Standard switches.
  $g_a{'scalp3g'}   = 0;
  $g_a{'byteclass'} = '';
  
  # Rest of cli list.
  @g_args = ();
  
  # Loop all arguments from command line POSIX style.
argument:
  while (defined($arg = shift(@args))) {
  
    # Long options:
    if ($arg =~ /^--/) {
      if ($arg eq '--help') {
        usage(ERR_NOERR);
      }
      if ($arg eq '--version') {
        version();
      }
      if ($arg eq '--test' ) {
        $g_a{'testMode'} = 1;
        next;
      }
      if ($arg eq '--opt' ) {
        $g_a{'optX'} = getParm(shift(@args));
        next;
      }
      if ($arg eq '--chunksize' ) {
        $g_a{'fcChunk'} = getParm(shift(@args));
        next;
      }
      if ($arg eq '--overlap' ) {
        $g_a{'fcTwice'} = getParm(shift(@args));
        next;
      }
      if ($arg eq '--scalp3g' ) {
        $g_a{'scalp3g'} = 1;
        next;
      }
      if ($arg eq '--byteclass' ) {
        $g_a{'byteclass'} = shift(@args);
        next;
      }
      dispatchError(ERR_ARGS, 'Invalid long option');
    }
  
    # Short options:
    if ($arg =~ /^-([^-].*)/) {
      $arg = $1;
      while ($arg =~ /(.)/g) {
        $opt = $1;
        if ($opt eq 'h') {
          usage(ERR_NOERR);
        }
        if ($opt eq 'v') {
          version();
        }
        if ($opt eq 't' ) {
          $g_a{'testMode'} = 1;
          next;
        }
        if ($opt eq 'o' ) {
          $g_a{'prtOff'} = 1;
          next;
        }
        if ($opt eq 'x' ) {
          $g_a{'optX'} = shift(@args);
          next;
        }
        if ($opt eq 'p' ) {
          $g_a{'prtPrgrs'} = 1;
          next;
        }
        dispatchError(ERR_ARGS, 'Invalid short option');
      }
      next argument;
    }

    # All else are treated as free arguments.
    push(@g_args, $arg);
  }
  
  # Sanity check of arguments and flags.
  dispatchError(ERR_ARGS, 'No file')      if @g_args == 0;
  dispatchError(ERR_ARGS, 'No byteclass') if not defined $g_a{'byteclass'};
  
  dispatchError(ERR_ARGS, 'X is missing') if $g_a{'optX'} eq '';       # Use, if option must have a value.
  dispatchError(ERR_ARGS, 'X not set')    if not defined $g_a{'optX'}; # Use, if option could be empty too.
  
  # Override options, if SCalP3G support is set.
  if ($g_a{'scalp3g'}) {
    $g_a{'testMode'} = 0;
    $g_a{'prtOff'}   = 1;
    $g_a{'prtPrgrs'} = 0;
  }
}

#*******************************************************************************
#* Name:  initGlobalVars
#* Purpose: Initialise arrays, hashes, regexes, etc.
#*******************************************************************************
sub initGlobalVars() {
  # Arrays:
  
  # Test array for show.
  @g_test = (
              '0x02',
              '0x04',
              '0x16',
              '0xff'
            );
  
  # Hahses:
  
  # Precisions and types.
  %g_prec = (
              1 => "City center",
              2 => "Street crossing",
              3 => "House number or premises",
              4 => "Anywhere on a street"
            );

  %g_type = (
              1 => "Entered via map or postcode",
              3 => "Favorite",
              4 => "Home location",
              5 => "Entered via adress",
              6 => "Entered via POI",
              7 => "Start of last calculated route"
            );
}

#*******************************************************************************
#* Name:  setByteClass
#* Purpose: Sets global var to '\C' or '[\x00-\xff]' for backwards compatebility
#**         prior version 5.020.
#*******************************************************************************
sub setByteClass() {
  my ($V, $v) = $] =~ /(\d)\.(\d\d\d)/;
  die "This script runs only with Perl's major version 5.\n" if $V != 5;  
  $g_C = ($v < 20) ? '\C' : '[\x00-\xff]';
  $g_C = $g_a{'byteclass'} if $g_a{'byteclass'} ne '';
}

#*******************************************************************************
#* Name:  initGlobalRegexes
#* Purpose: Assembles all global regexes.
#*******************************************************************************
sub initGlobalRegexes() {
  # Get Perl version related regex byte class.
  setByteClass();
  
  # Regular expression parts to compile entries:
  # Bitmasks of valid UTF-8 chars are:
  #   either 1 Byte: 0xxxxxxx
  #   or     2 Byte: 110xxxxx, 10xxxxxx
  #   or     3 Byte: 1110xxxx, 10xxxxxx, 10xxxxxx
  #   or     4 Byte: 11110xxx, 10xxxxxx, 10xxxxxx, 10xxxxxx
  # Well-Formed UTF-8 Byte Sequences
  # Code Points       |First Byte|Second Byte|Third Byte|Fourth Byte
  # ------------------+----------+-----------+----------+-----------
  # U+0000..U+007F    | 00..7F   |           |          |
  # ------------------+----------+-----------+----------+-----------
  # U+0080..U+07FF    | C2..DF   | 80..BF    |          |
  # ------------------+----------+-----------+----------+-----------
  # U+0800..U+0FFF    | E0       | A0..BF    | 80..BF   |
  # ------------------+----------+-----------+----------+-----------
  # U+1000..U+CFFF    | E1..EC   | 80..BF    | 80..BF   |
  # ------------------+----------+-----------+----------+-----------
  # U+D000..U+D7FF    | ED       | 80..9F    | 80..BF   |
  # ------------------+----------+-----------+----------+-----------
  # U+E000..U+FFFF    | EE..EF   | 80..BF    | 80..BF   |
  # ------------------+----------+-----------+----------+-----------
  # U+10000..U+3FFFF  | F0       | 90..BF    | 80..BF   | 80..BF
  # ------------------+----------+-----------+----------+-----------
  # U+40000..U+FFFFF  | F1..F3   | 80..BF    | 80..BF   | 80..BF
  # ------------------+----------+-----------+----------+-----------
  # U+100000..U+10FFFF| F4       | 80..8F    | 80..BF   | 80..BF
  # ------------------+----------+-----------+----------+-----------
  my $rxUtf8_11  = '(?:[\x20-\x7f])';
  my $rxUtf8_21  = '(?:[\xc2-\xdf] [\x80-\xbf])';
  my $rxUtf8_31  = '(?:\xe0        [\xa0-\xbf] [\x80-\xbf])';
  my $rxUtf8_32  = '(?:[\xe1-\xec] [\x80-\xbf] [\x80-\xbf])';
  my $rxUtf8_33  = '(?:\xed        [\x80-\x9f] [\x80-\xbf])';
  my $rxUtf8_34  = '(?:[\xee-\xef] [\x80-\xbf] [\x80-\xbf])';
  my $rxUtf8_41  = '(?:\xf0        [\x90-\xbf] [\x80-\xbf] [\x80-\xbf])';
  my $rxUtf8_42  = '(?:[\xf1-\xf3] [\x80-\xbf] [\x80-\xbf] [\x80-\xbf])';
  my $rxUtf8_43  = '(?:\xf4        [\x80-\x8f] [\x80-\xbf] [\x80-\xbf])';
  
  $g_rx{'charUtf8'} = qr/
                          $rxUtf8_11 | $rxUtf8_21 | $rxUtf8_31 |
                          $rxUtf8_32 | $rxUtf8_33 | $rxUtf8_34 |
                          $rxUtf8_41 | $rxUtf8_42 | $rxUtf8_43
                        /xo;
  
  # UTF-16LE chars are:
  #  16 Bit Integer: xxxxxxxx, xxxxxxxx
  # Code Points       |First Byte|Second Byte|Third Byte|Fourth Byte
  # ------------------+----------+-----------+----------+-----------
  # U+0000..U+D7FF    | 00..FF   | 00..D7    |          |
  # ------------------+----------+-----------+----------+-----------
  # U+E000..U+FFFF    | 00..FF   | E0..FF    |          |
  # ------------------+----------+-----------+----------+-----------
  # U+10000..U+10FFFF | see below for bit transformation
  # ------------------+----------+-----------+----------+-----------
  # 000uuuuuxxxxxxxxxxxxxxxx => 110110wwwwxxxxxx 110111xxxxxxxxxx
  # where wwww = uuuuu - 1
  # This definition skips symbols, asian, african and hebrew UTF-16 chars.
  my $utf16_1 = '[^\x20-\xff]'; # == '[\x00-\x1f]';
  my $utf16_2 = '[\x00-\x2c]';
  
  $g_rx{'charUtf16'} = qr/
                           (?! $utf16_1 \x00    )    # Fail, if non printable.
                               $g_C     $utf16_2     #   Ok, else.
                         /xo;

  
  # Full ASCII chars are:
  #  8 Bit Chars.
  # Code Points |First Byte|
  # ------------+----------+
  # 00..7F      | ASCII    |
  # ------------+----------+
  # 80..FF      | Ext      |
  # ------------+----------+
  $g_rx{'charAscii'} = qr/[\x20-\xff]/xo;
  
  # Simple UTF32LE chars.
  $g_rx{'charUtf32'} = qr/[\x20-\xff] $g_C \x00{2}/xo;
  
  # Sub matches.
  my $rxCPrec    = "\\x04\\x00(${g_C})\\x00{3}";
  my $rxCType    = "\\x04\\x00(${g_C})\\x00{3}";
  my $rxCcCoords = "\\x08\\x00(${g_C}{4})(${g_C}{4})";
  my $rxHeader   = "$rxCPrec $rxCType $rxCcCoords $rxCcCoords";
  
  # Regex scheme: Header ($g_C+?) Header or eof.
  $g_rx{'c6TomTom'} = qr/
                          ($rxHeader)
                            ($g_C+?)
                          (?= (?:$rxHeader) | \Z)
                        /xo;
}

#*******************************************************************************
#* Name:  findIt
#* Purpose: Finds file or folder.
#*******************************************************************************
sub findIt() {
  # $File::Find::dir  = /some/path/
  # $_                = foo.ext
  # $File::Find::name = /some/path/foo.ext
  $g_{'return'} = $File::Find::name if $_ eq $g_{'findPath'};
}

#*******************************************************************************
#* Name:  findPath
#* Purpose: Wrapper to findIt().
#*******************************************************************************
sub findPath($$) { my ($initDir, $findPath) = @_;
  my $ret = '';
  
  $g_{'findPath'} = $findPath;
  $g_{'return'}   = '';
  
  find(\&findIt, $initDir);
  
  $g_{'findPath'} = undef;
  $ret            = $g_{'return'};
  $g_{'return'}   = undef;
  
  return $ret;
}

#*******************************************************************************
#* Name: getDateTime
#* Purpose: Returns operating system independent local date and time string.
#*******************************************************************************
sub getDateTime() {
  my @day   = ('So', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa');
  my @month = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
               'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');
  my ($sec,  $min,   $hour,
      $mday, $month, $year,
      $day,  $yday,  $isdst) = localtime();

  my $cets = ($isdst) ? 'CEST' : 'CET';

  $year += 1900;

  my $date = sprintf('%s %d. %s %02d:%02d:%02d %s %d',
                     $day[$day], $mday, $month[$month],
                     $hour, $min, $sec,
                     $cets, $year);
  return $date;
}

#*******************************************************************************
#* Name:  utc2ticks
#* Purpose: Converts UTC time to integer.
#*******************************************************************************
sub utc2ticks($) { my ($time) = @_;
  my ($year, $month, $mday, $hour, $min, $sec)
     = $time 
     =~ /(\d{4}) \D (\d{2}) \D (\d{2}) \D{1,2} (\d{2}) \D (\d{2}) \D (\d{2})/xo;

  my $ticks = timegm($sec,  $min, $hour, $mday, $month - 1, $year - 1900);

  return $ticks;
}

#*******************************************************************************
#* Name:  ticks2utc
#* Purpose: Converts integer to UTC time.
#*******************************************************************************
sub ticks2utc($) { my ($ticks) = @_;
  my ($sec,  $min,   $hour,
      $mday, $month, $year,
      $day,  $yday,  $isdst) = gmtime($ticks);
  
  my $date = sprintf('%04d/%02d/%02d, %02d:%02d:%02d',
                     $year + 1900, $month + 1, $mday, $hour, $min, $sec);

  return "$date (UTC)";
}

#*******************************************************************************
#* Name:  splitFile
#* Purpose: Splits '/my/path/name.ext' into '/my/path/', 'name' and '.ext'.
#*******************************************************************************
sub splitFile($) { my ($file) = @_;
  my ($path) = $file =~ /^(.*[\/\\])/;
  my ($ext)  = $file =~ /^\Q$path\E.*(\.[^.]*)$/;
  my ($name) = $file =~ /^\Q$path\E(.*)\Q$ext\E/;
  return ($path, $name, $ext);
}

#*******************************************************************************
#* Name:  tryCmd
#* Purpose: Prints command, ececutes and prints result with success message.
#*******************************************************************************
sub tryCmd($;$) { my ($cmd, $txt) = @_;
  my $msg    = $cmd;
  my $ret    = '';
  my $err    = 0;
  my $result = '';

  # Hide real output if $txt is not empty.
  $msg = $txt if $txt ne '';

  # Response.
  print "[ try  ] $msg";
  
  if ($g_a{'testMode'}) {
    print "\n";
    return ERR_NOERR;
  }
  
  # Execute.
  $ret = `$cmd 2>&1`;
  chomp($ret);
  
  # Assemble result.
  $err    = ($? != 0);
  $result = ($err)
          ? COL_FAILED . '[failed] ' . COL_OFF
          : COL_OK     . '[  ok  ] ' . COL_OFF;

  # Print result.
  print "\r$result\n";
  print "$ret\n" if $ret ne '';

  return $err;
}

#*******************************************************************************
#* Name:  cmd
#* Purpose: Prints what will be done and do it.
#*******************************************************************************
sub cmd($) { my ($cmd) = @_;
  my $rv = '';
  
  print "$g_mename: [$cmd]\n";
#   $rv = `$cmd` if not $g_a{'testMode'};
  
  chomp($rv);
  return $rv;
}

#*******************************************************************************
#* Name:  trim
#* Purpose: Removes whitespaces around texts in an array.
#*******************************************************************************
sub trim(@) {
  foreach my $txt (@_) {
    $txt =~ s/^\s*(.+?)\s*$/$1/;
  }
}

#*******************************************************************************
#* Name:  trimA
#* Purpose: Removes non printables around texts in an array.
#*******************************************************************************
sub trimA(@) {
  foreach my $txt (@_) {
    $txt =~ s/^[\x00-\x20]+//;
    $txt =~ s/[\x00-\x20]+$//;
  }
}

#*******************************************************************************
#* Name:  straight
#* Purpose: Replaces all newlines and carriage returns with spaces.
#*******************************************************************************
sub straight($) { my ($string) = @_;
  $string =~ s/\n|\r/ /g;
  return $string;
}

#*******************************************************************************
#* Name:  toUtf8
#* Purpose: Decodes strings to UTF-8, with given encoding.
#*******************************************************************************
sub toUtf8($;$) { my ($string, $from) = @_;
  $from = 'UTF-16LE' if not defined $from;
  from_to($string, $from, 'utf8', 1);
  $string = straight($string);
  return $string;
}

#*******************************************************************************
#* Name:  round
#* Purpose: Rounds floating point number to given digits after decimal point.
#*******************************************************************************
sub round(dispatchError$$) { my ($number, $digits) = @_;
  $digits = 10**$digits;
  return int($number * $digits + 0.5) / $digits;
}

#*******************************************************************************
#* Name:  utm2wgs84
#* Purpose: Converts coordinates from Mercator (X, Y) into WGS84 (Lon, Lat).
#*******************************************************************************
sub utm2wgs84($$) { my ($x, $y) = @_;
  my $lon = 0.0;
  my $lat = 0.0;
  
  # Calculate the coordinate.
  $lon = $x / iRADIUS * 180 / dPI;
  $lat = 360 / dPI * atan(exp($y / iRADIUS)) - 90;
  
  # Round to 6 digits.
  $lon = int($lon * 1e6 + 0.5) / 1e6;
  $lat = int($lat * 1e6 + 0.5) / 1e6;
  
  # Check coordinate's integrity.
  return (''  , '') if $lon < -180 or $lon > 180;
  return (''  , '') if $lat <  -90 or $lat >  90;
  
  return ($lon, $lat);
}

#*******************************************************************************
#* Name:  printVmoLen
#* Purpose: Translate 'CreateVMO, begin, end, color' to 'offset, len, color'.
#*******************************************************************************
sub printVmoLen($$$) { my ($off, $len, $type) = @_;
  return if $len < 1;
  print 'CreateVMO;', $off, ';', $off + $len - 1, ";$type\n";
}

#*******************************************************************************
#* Name:  printVmo
#* Purpose: Paints hexedit types in colour.
#*******************************************************************************
sub printVmo() {
  # Paint some bytes in hex view.
  printVmoLen($g_off{'base'}, $g_off{'len'}, 'Location');
  
  # Flush offsets.
  %g_off = ();
}

#*******************************************************************************
#* Name:  prtLn
#* Purpose: Print line to stdout with scalp3g support.
#*******************************************************************************
sub prtLn($$) { my ($line, $type, $rows) = @_;
  if ($g_a{'scalp3g'}) {
    if ($type == HDG_HEAD) {
      print "CreateTable\tMapSettings\t$g_nRows\t$g_nCols\n";
      print "WriteHeaderLine\t";
    }
    if ($type == HDG_LINE) {
      # SCalP3G hexview.
      printVmo();
      print "WriteDataLine\t";
    }
  }
  print "$line\n";
}

#*******************************************************************************
#* Name:  printHeader
#* Purpose: Prints generic csv file header.
#*******************************************************************************
sub printHeader() {
  my $str = '';
  
  $str  = "Remark\tLongitude\tLatitude\tLabel";
  $str .= "\tOffset" if $g_a{'prtOff'};
  
  prtLn($str, HDG_HEAD);
}

#*******************************************************************************
#* Name:  getData
#* Purpose: Gets raw bytes and converts them to readable data.
#*******************************************************************************
sub getData(\$) { my ($rBytes) = @_;
  return $$rBytes;
}

#*******************************************************************************
#* Name:  printEntry
#* Purpose: Prints generic csv file entry.
#*******************************************************************************
sub printEntry() {
  my $str = '';
  
  $str  = "$g_e{'rem'}\t$g_e{'lon'}\t$g_e{'lat'}\t$g_e{'lbl'}";
  $str .= "\t$g_off{'base'}" if $g_a{'prtOff'};
  
  prtLn($str, HDG_LINE);
  
  # Flush old data.
  %g_e = ();
}

#*******************************************************************************
#* Name:  printProgress
#* Purpose: Prints progress of search.
#*******************************************************************************
sub printProgress($$) { my ($file, $fcSize) = @_;
  my $percent = 0;
  
  $percent = int($g_off{'base'} / $fcSize * 100 * 1e2 + .5) / 1e2;
  $fcSize  =~ s/(?<=\d) (?= (?:\d{3})+ (?!\d) )/,/xog;
  
  print STDERR "\rLast match in '$file' at $percent% of $fcSize Bytes   ";
}

#*******************************************************************************
#* Name:  debug
#* Purpose: Prints information for debugging.
#*******************************************************************************
sub debug() {
  print "\$g_meversion           = $g_meversion\n";
  print "\$g_mename              = $g_mename\n";
  print "\$g_meuser              = $g_meuser\n";
  print "\$g_isWin32             = $g_isWin32\n";
  print "\$g_mehome              = $g_mehome\n";
  print "(\$g_merows, \$g_mecols) = ($g_merows, $g_mecols)\n";
  print "\n";
  
  print "Arguments:\n";
  foreach my $key (keys %g_a) {
    my $var = "\$g_a{'$key'}";
    my $len = length($var);
    my $spc = ' ' x (23 - $len);
    print "$var$spc= $g_a{$key}\n";
  }
  print "\n";
  
  print "Entry composition:\n";
  foreach my $key (keys %g_e) {
    my $var = "\$g_e{'$key'}";
    my $len = length($var);
    my $spc = ' ' x (23 - $len);
    print "$var$spc= $g_e{$key}\n";
  }
  print "\n";
  
  print "Regexes:\n";
  foreach my $key (keys %g_rx) {
    my $var = "\$g_rx{'$key'}";
    my $len = length($var);
    my $spc = ' ' x (23 - $len);
    print "$var$spc= $g_rx{$key}\n";
  }
  print "\n";
  
  print "--byteclass = '$g_a{'byteclass'}' (for debugging purpose)\n";
  print "byte regex  = '$g_C' (depends on Perl version '<'/'>=' 5.20)\n";
  print "file(s)     = ", join(", ", @g_args), "\n";
  print "\n";
  cmd("test-command -f -o opt file");
  
  exit(0);
}


#*******************************************************************************
#* main

sub main() {
  my $file  = '';
  my $data  = '';
  my $bytes = '';
  
  # File chunk variables.
  my $fcSize  = 0;
  my $fcCount = 0;
  
  # Print apropriate error message, if necessary.
  getOptions(@ARGV);

  # Initialisations:
  initGlobalVars();
  initGlobalRegexes();
  
  debug(); # Remove after finish debugging.

  # Get chunks of data with overlapped bytes.
  $/ = \($g_a{'fcChunk'} + $g_a{'fcTwice'});    # Remove if not wanted.
  
  # Get all data from all files.
  foreach $file (@g_args) {
    dispatchError(ERR_FILE, "Can't open '$file'") unless open(IN, "<:raw", $file);
#-- file -----------------------------------------------------------------------
    $fcSize  = -s $file;
    $fcCount = 0;
    printProgress($file, $fcSize) if $g_a{'prtPrgrs'};
    
    while ($data = <IN>) {
      while ($data =~ /$g_rx{'c6TomTom'}/g) {
        ($g_e{'prec'}, $g_e{'type'},
         $g_e{'lon1'}, $g_e{'lat1'},
         $g_e{'lon2'}, $g_e{'lat2'}, $bytes) = ($1, $2, $3, $4, $5, $6, $7);
        
        # Offset and length calculation.
        if ($g_a{'prtOff'} or $g_a{'prtPrgrs'} or $g_a{'scalp3g'}) {
          $g_off{'len'}  = $+[0] - $-[0];
          $g_off{'base'} = $fcCount * $g_a{'fcChunk'} + $-[0];
        }
        
        printProgress($file, $fcSize) if $g_a{'prtPrgrs'};
        
        getData($bytes);
        printEntry();
      }
      # Go back the overlapped bytes before reading next chunk.
      seek(IN, -$g_a{'fcTwice'}, 1) if tell(IN) < $fcSize;
      ++$fcCount;
    }
#-- file -----------------------------------------------------------------------
    # Print a last new line, if the progress was printed.
    print STDERR "\n" if $g_a{'prtPrgrs'};
    
    close(IN);
  }
  exit(ERR_NOERR);
}


#*******************************************************************************
#* start programm
main()
__END__
