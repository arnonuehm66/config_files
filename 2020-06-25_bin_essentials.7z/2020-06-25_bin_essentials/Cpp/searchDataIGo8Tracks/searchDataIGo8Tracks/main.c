/*******************************************************************************
 ** Name: searchDataIGo8Tracks
 ** Purpose:  Retrieve tracks from binary autolog trk-files and images
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 30.10.2017  JE    Rewrote C program from 'searchDataIGo8Tracks.pl' v0.7.1.
 ** 01.02.2018  JE    Now use leak free 'c_string.h'.
 ** 13.02.2018  JE    Now use 'c_dynamic_arrays.h'.
 ** 15.02.2018  JE    Now use new interface of 'c_string.h'.
 ** 15.02.2018  JE    Adjusted functions to 'skeleton_main_c v0.0.5'.
 ** 21.03.2018  JE    Adjusted functions to 'skeleton_main_c v0.0.6'.
 ** 11.09.2018  JE    Now uses c_string_v0.9.1.h with csSetf().
 ** 11.09.2018  JE    Added tzset(), ticks2datetime() and datetime2ticks().
 ** 11.09.2018  JE    Removed YEARSECS.
 ** 11.09.2018  JE    Added '-Y' for maximum year.
 ** 17.09.2018  JE    Changed shift() to avoid a cstr memory leak.
 ** 10.10.2018  JE    Changed ticks2datetime() to avoid a cstr memory leak.
 ** 11.02.2019  JE    Added 'csFree(&csItem);' in datetime2ticks() preventing a
 **                   memory hole.
 ** 15.02.2019  JE    Now continue loop after getValidData() in main().
 ** 23.04.2019  JE    Now use c_dynamic_arrays.h v0.3.3.
 ** 24.04.2019  JE    Added struct names and changed int's to -time_t's ticks.
 ** 24.04.2019  JE    Changed interface of getBytes()m toInt() and getInt().
 ** 31.05.2019  JE    Added openFile() for convenience.
 ** 10.07.2019  JE    Adjusted toInt() working with endian.h.
 ** 17.07.2019  JE    Now tm_isdst is set permanentely to 0 in datetime2ticks().
 ** 05.09.2019  JE    Changed complete offset reset logic pattern.
 ** 05.09.2019  JE    Made current tEntry variable a local one.
 ** 06.09.2019  JE    Refracted some function names.
 ** 06.09.2019  JE    Added offset of used entries in printNflushFifo().
 ** 10.09.2019  JE    Refined main logic structure.
 ** 10.09.2019  JE    Restructured main logic.
 ** 10.09.2019  JE    Simplified printEntry()/printHeader() and adjusted output.
 ** 10.09.2019  JE    Now uses ticks2datetime().
 ** 12.09.2019  JE    Changed offset logic in printNflushFifo().
 ** 20.01.2020  JE    Now use functions, includes and defines from 'stdfcns.c'.
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "searchDataIGo8Tracks"
#define ME_VERSION "0.6.2"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"

// getOptions(): Defines empty values.
#define NO_TICK ((time_t) ~0)   // Fancy contruction to get a (-1). ;o)


//******************************************************************************
//* outsourced standard functions, includes and defines

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// For convienience.
typedef unsigned int  uint;
typedef unsigned char uchar;
typedef long double   ldbl;


// Arguments and options.
typedef struct s_options {
  long   lByteOff;
  int    iPrtOff;
  int    iMatchCount;
  time_t tTicksMin;
  time_t tTicksMax;
} t_options;

// Fifo
typedef struct s_entry {
  int    iUsed;
  ldbl   ldLon;
  ldbl   ldLat;
  int    iLon;
  int    iLat;
  time_t tTicks;
  long   lOffset;
} t_entry;


//******************************************************************************
//* Global variables

// Fifo.
t_entry* g_ptFifo;

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-b n] [-o] [-n n] [-y yyyy [-Y yyyy]] file1 [file2 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Retrieve tracks from binary iGo8 track files or image. With image '-n' can be\n"
  " set to higher values to get fewer false positives.\n"
  " '-b' can be entered as hexadecimal with '0x' prefix or as decimal with postfix\n"
  " K, M, G (meaning Kilo- Mega- and Giga-bytes based on 1024).\n"
  "  -b n:          byte offset, in files it starts usually at 341 (default 0)\n"
  "  -o:            print additional offset column (default none)\n"
  "  -n n:          set the number of matches before printing entries (default 3)\n"
  "                 must be higher than or equal 3\n"
  "  -y yyyy:       min year to consider a track as valid (default 2002)\n"
  "  -Y yyyy:       max year to consider a track as valid (default this year)\n"
  "                 -y and -Y must be between 1970 and 2038\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  zeroEntry
 * Purpose: Set  an entry object to '0'.
 *******************************************************************************/
void clearEntry(t_entry* ptEntry) {
  ptEntry->iUsed   = 0;
  ptEntry->ldLon   = 0.0;
  ptEntry->ldLat   = 0.0;
  ptEntry->iLon    = 0;
  ptEntry->iLat    = 0;
  ptEntry->lOffset = 0;
  ptEntry->tTicks  = 0;
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  int  iArg   = 1;  // Omit programm name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Set defaults.
  g_tOpts.lByteOff    = 0;
  g_tOpts.iPrtOff     = 0;
  g_tOpts.iMatchCount = 3;
  g_tOpts.tTicksMin   = 2002;   // This year will be converted into seconds.
  g_tOpts.tTicksMax   = NO_TICK;

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'b') {
          if (! getArgLong((ll*) &g_tOpts.lByteOff, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Byte offset is missing");
          continue;
        }
        if (cOpt == 'o') {
          g_tOpts.iPrtOff = 1;
          continue;
        }
        if (cOpt == 'n') {
          if (! getArgLong((ll*) &g_tOpts.iMatchCount, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Match counter is missing");
          continue;
        }
        if (cOpt == 'y') {
          if (! getArgLong((ll*) &g_tOpts.tTicksMin, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Min year is missing");
          continue;
        }
        if (cOpt == 'Y') {
          if (! getArgLong((ll*) &g_tOpts.tTicksMax, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Max year is missing");
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount == 0)
    dispatchError(ERR_ARGS, "No file");

  if (g_tOpts.iMatchCount < 3)
    dispatchError(ERR_ARGS, "Match counter must be > 2") ;

  if (g_tOpts.tTicksMin < 1970 || g_tOpts.tTicksMin > 2038)
    dispatchError(ERR_ARGS, "Year out of limits (1970 - 2038)");

  if (g_tOpts.tTicksMax != NO_TICK &&
     (g_tOpts.tTicksMax < 1970 || g_tOpts.tTicksMax > 2038))
    dispatchError(ERR_ARGS, "Max year out of limits (1970 - 2038)");

  // Get timestamps limits for verification.
  g_tOpts.tTicksMin = datetime2ticks(0, "", g_tOpts.tTicksMin, 1, 1, 0, 0, 0);
  if (g_tOpts.tTicksMax == NO_TICK)
    g_tOpts.tTicksMax = time(NULL);
  else
    // To fit this year it must end 1 sec befor end of last year!
    g_tOpts.tTicksMax = datetime2ticks(0, "", g_tOpts.tTicksMax - 1, 12, 31, 23, 59, 59);

  if (g_tOpts.tTicksMin >= g_tOpts.tTicksMax)
    dispatchError(ERR_ARGS, "'-Y' should be grater than '-y'");

//// XXX *************************************************************************
//cstr csTmp1 = csNew(""); cstr csTmp2 = csNew("");
//ticks2datetime(&csTmp1, "", g_tOpts.tTicksMin);
//ticks2datetime(&csTmp2, "", g_tOpts.tTicksMax);
//printf("min: %ld\nmax: %ld\n", g_tOpts.tTicksMin, g_tOpts.tTicksMax);
//printf("min: %s\nmax: %s\n", csTmp1.cStr, csTmp2.cStr); exit(0);
//// XXX *************************************************************************

  // Create fifo according option.
  g_ptFifo = (t_entry*) malloc(sizeof(t_entry) * g_tOpts.iMatchCount);

  // Init all entry objects;
  for(int i = 0; i < g_tOpts.iMatchCount; ++i)
    clearEntry(&g_ptFifo[i]);

  csFree(&csArgv);
  csFree(&csRv);

  return;
}

/*******************************************************************************
 * Name:  absLd
 * Purpose: Yields abs(dA).
 *******************************************************************************/
ldbl absLd(ldbl ldA) {
  if (ldA < 0.0) return -ldA;
  return ldA;
}

/*******************************************************************************
 * Name:  round6
 * Purpose: Yields float, rounded to 6 digits.
 *******************************************************************************/
ldbl round6(ldbl ldA) {
  return ((ldbl) ((int) (ldA * 1e6 + 0.5))) / 1e6;
}

/*******************************************************************************
 * Name:
 * Purpose: Reads up to 4 bytes from file into a buffer.
 *******************************************************************************/
void getBytes(FILE* hFile, char* pcBuffer, int iCount, int* piErr) {
  for (int i = 0; i < iCount; ++i)
    pcBuffer[i] = getc(hFile);

  *piErr = feof(hFile);
  return;
}

/*******************************************************************************
 * Name:  getInt
 * Purpose: Converts up to 4 bytes into an short integer.
 *******************************************************************************/
int getInt(FILE* hFile, int iCount, int* piErr) {
  char ac4Bytes[4] = {0};

  getBytes(hFile, ac4Bytes, iCount, piErr);

  if (*piErr)
    return -1;

  *piErr = 0;
  return toInt(ac4Bytes, iCount);
}

/*******************************************************************************
 * Name:  printHeader
 * Purpose: Prints generic csv file header.
 *******************************************************************************/
void printHeader(void) {
  printf("Remark\tLongitude\tLatitude\tDate Time (UTC)");
  if (g_tOpts.iPrtOff)
    printf("\tOffset");

  printf("\n");
}

/*******************************************************************************
 * Name:  toWgs84
 * Purpose: Converts coordinates to WGS84.
 *******************************************************************************/
int toWgs84(t_entry* ptEntry) {
  // 1<<23 entspricht 2**23!
  ptEntry->ldLon = round6((ldbl) ptEntry->iLon / (1<<23));
  ptEntry->ldLat = round6((ldbl) ptEntry->iLat / (1<<23));

  // Check coordinate's integrity.
  if (ptEntry->ldLon < -180 || ptEntry->ldLon > 180) return 0;
  if (ptEntry->ldLat <  -90 || ptEntry->ldLat >  90) return 0;

  return 1;
}

/*******************************************************************************
 * Name:  validData
 * Purpose: Gets raw bytes, converts the data and check its validity.
 *******************************************************************************/
int validData(t_entry* ptEntry) {
  ptEntry->iUsed = 0;

  // Check for timestamp inconsistencies.
  if (ptEntry->tTicks < g_tOpts.tTicksMin) return 0;
  if (ptEntry->tTicks > g_tOpts.tTicksMax) return 0;

  // Get coordinates and check for validity.
  if (!toWgs84(ptEntry))
    return 0;

  ptEntry->iUsed = 1;
  return 1;
}

/*******************************************************************************
 * Name:  fitsToLast
 * Purpose: Check if current entry is a valid continuation to the last.
 *******************************************************************************/
int fitsToLast(t_entry* ptCe) {                       // Current entry.
  t_entry* ptLe = &g_ptFifo[g_tOpts.iMatchCount - 1]; // Last entry.

  // Try to get a positive follow up position in a possible track.
  if (ptCe->lOffset     - ptLe->lOffset != 20) return 0;  // Is not the next data set->
  if (ptCe->tTicks      - ptLe->tTicks  <   1) return 0;  // Is prior to last one->
  if (ptCe->tTicks      - ptLe->tTicks  >   5) return 0;  // Diff more than 5 sec (usually 2 sec)->
  if (absLd(ptCe->ldLon - ptLe->ldLon)  > 1.0) return 0;  // Lon's diff is way too big for Europe->
  if (absLd(ptCe->ldLat - ptLe->ldLat)  > 1.0) return 0;  // Lat's diff is way too big->

  return 1;
}

/*******************************************************************************
 * Name:  pushNpopFifo
 * Purpose: Fills 'first in, first out' buffer.
 *          head => [0], [1],  ... [n - 1], [n] => tail
 *******************************************************************************/
t_entry pushNpopFifo(t_entry* ptTail) {
  t_entry tHead = g_ptFifo[0];  // Pop top entry.

  // Shift entries one step ahead the line.
  for(int i = 1; i < g_tOpts.iMatchCount; ++i)
    g_ptFifo[i - 1] = g_ptFifo[i];

  // Insert new tail.
   g_ptFifo[g_tOpts.iMatchCount - 1] = *ptTail;

  // Return popped entry.
  return tHead;
}

/*******************************************************************************
 * Name:  printEntry
 * Purpose: Prints entry if its not empty.
 *******************************************************************************/
void printEntry(t_entry* ptEntry) {
  if (!ptEntry->iUsed) return;  // Sanity check.

  cstr csTime = csNew("");

  ticks2datetime(&csTime, "", ptEntry->tTicks);

  printf("Trackpoint\t%.6Lf\t%.6Lf\t%s",
         ptEntry->ldLon, ptEntry->ldLat, csTime.cStr);

  if (g_tOpts.iPrtOff) {
    printf("\t%ld", ptEntry->lOffset);
  }
  printf("\n");

  csFree(&csTime);
}

/*******************************************************************************
 * Name:  printNflushFifo.
 * Purpose: Deletes entries, prints them if fifo is full. Returns last offset.
 *******************************************************************************/
long printNflushFifo(t_entry* ptCe) {
  long lOff = ptCe->lOffset;

  // Print entries if full or get lowest offset, i.e. first used entry.
  if (g_ptFifo[0].iUsed)
    for(int i = 0; i < g_tOpts.iMatchCount; ++i)
      printEntry(&g_ptFifo[i]);
  else {
    for(int i = 0; i < g_tOpts.iMatchCount; ++i)
      if (g_ptFifo[i].iUsed) {
        lOff = g_ptFifo[i].lOffset;
        break;
      }
  }

  // Flush fifo.
  for(int i = 0; i < g_tOpts.iMatchCount; ++i)
    clearEntry(&g_ptFifo[i]);

  return lOff;
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  FILE*   hFile      = NULL;
  t_entry tTopEntry  = {0};
  t_entry tEntry     = {0};
  int     iEndOfFile = 0;
  int     iValid     = 0;
  int     iFitsLast  = 0;
  long    lLastOff   = 0;


  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // To populate the var 'timezone' used in datetime2ticks().
  tzset();

  printHeader();

  // Get all data from all files.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    hFile = openFile(g_tArgs.pStr[i].cStr, "rb");
//-- file ----------------------------------------------------------------------
    // Set byte offset for each file.
    fseek(hFile, g_tOpts.lByteOff, SEEK_SET);

    // Loop all bytes in a file.
    iEndOfFile = 0;
    while (!iEndOfFile) {
      tEntry.lOffset = ftell(hFile);
      tEntry.tTicks  = getInt(hFile, 4, &iEndOfFile);
      tEntry.iLon    = getInt(hFile, 4, &iEndOfFile);
      tEntry.iLat    = getInt(hFile, 4, &iEndOfFile);
      /* unknown */    getInt(hFile, 4, &iEndOfFile);
      /* unknown */    getInt(hFile, 4, &iEndOfFile);

      // End while loop if EOF and execute printNflushFifo() for the last time.
      if (iEndOfFile) {
        printNflushFifo(&tEntry);
        continue; // or break; It doesn't matter here!
      }

      // Calculate fitting of current entry to last found entry.
      iValid    = validData(&tEntry);
      iFitsLast = fitsToLast(&tEntry);

      // If fitting fails get the last valid/current offset and flush fifo.
      if (!iValid || !iFitsLast)
        lLastOff = printNflushFifo(&tEntry);

      // If entry isn't valid or don't fit last fifo entry, reset offset to on
      // byte after start of first fifo entry.
      if (!iValid || (!iFitsLast && lLastOff < tEntry.lOffset))
        fseek(hFile, lLastOff + 1, SEEK_SET);

      // If fifo is empty add entry to it.
      if (!iFitsLast && lLastOff == tEntry.lOffset)
        pushNpopFifo(&tEntry);

      // All OK: Add to fifo and print top entry if used.
      if (iValid && iFitsLast) {
        tTopEntry = pushNpopFifo(&tEntry);
        printEntry(&tTopEntry);
      }
    }
//-- file ----------------------------------------------------------------------
    fclose(hFile);
  }
  return ERR_NOERR;
}
