/*******************************************************************************
 ** Filename: nodiffpp
 ** Purpose:  Identifies signatures of unknown file types.
 ** Author:   Jens Elstner (JE)
 *******************************************************************************
 ** Date        User  Log
 ** ----------------------------------------------------------------------------
 ** 18.12.2004  JE    Created file.
 ** 23.12.2004  JE    Deleted main.h and minor adjustments.
 ** 23.12.2004  JE    Now usage() exit with given error code.
 ** 23.12.2004  JE    Added flag -d making hex dumping of file.
 ** 23.12.2004  JE    Now byteToHexOut() only shows chars 32 and higher.
 ** 23.12.2004  JE    Changed all singned chars to unsigne in dump.
 ** 23.12.2004  JE    Made converting from char to UINT instead of UCHAR!
 ** 25.12.2004  JE    Extended dump with db= parameter.
 ** 27.12.2004  JE    Limited ASCII output between 32 to 126 for LINUX.
 ** 27.12.2004  JE    Now intercept out of bounds error in readDataFromFile().
 ** 09.09.2005  JE    Made nicer output with spaces. ;-)
 ** 09.09.2005  JE    Now calculate length of address after uiByteCount.
 ** 09.09.2005  JE    Now use conditionally compiling for Linux/Windows.
 ** 09.05.2008  JE    Now print usage to cerr if error occurred.
 ** 23.01.2009  JE    Added "(LINUX)", "(WINDOWS)" to verion string.
 ** 31.08.2009  JE    Changed LINUX switch logic for ASCII-output.
 ** 31.08.2009  JE    Project added to QT Creator. Switched language to english.
 ** 01.09.2009  JE    Set '-uiByteCount' to '-long(uiByteCount)' in seekg() to
 **                   prevent wrong footer count, thus eof() error.
 ** 31.10.2009  JE    Added 'cstdlib' on kubuntu 9.10 for usage of exit() and
 **                   atoi().
 ** 12.01.2011  JE    Prevents system from using first two files exclusively.
 ** 28.02.2013  JE    Now use a struct for all options.
 *******************************************************************************/


//******************************************************************************
//* ToDo:
//*-----------------------------------------------------------------------------
//* - add offset parameter for each file like:
//*   of1=0x200 [of2=123 ...] file1 [file2 ...]
//******************************************************************************


//******************************************************************************
//* Switches

//#undef LINUX
#define LINUX


//******************************************************************************
//* Includes

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;


//******************************************************************************
//* Definitions

#define ME_NAME  "nodiff"
#define ME_VERNR "0.9.2"

#ifdef LINUX
  #define ME_VERSION  ME_VERNR " (Linux)"
  #define MAX_PRINTABLE_ASCII 126
#else
  #define ME_VERSION  ME_VERNR " (Windows)"
  #define MAX_PRINTABLE_ASCII 255
#endif

#define ERR_NO_ERROR      0x00
#define ERR_CMD_PARAMETER 0x01
#define ERR_FILE_IO       0x02
#define ERR_DIFF          0x03

#define NO_ENTRY 999

// Flags:
#define DUMP   0x00
#define HEADER 0x01
#define FOOTER 0x02

// For convenience.
#define UINT  unsigned int
#define UCHAR unsigned char


//******************************************************************************
//* Structs

struct structOptions {
  bool           fHeader;
  bool           fFooter;
  bool           fDumpFile;
  UINT           uiHeadCount;
  UINT           uiFootCount;
  UINT           uiDumpCount;
  UINT           uiFileCount;
  vector<string> vstrFiles;
  vector<UINT>   vuiHeadOut;
  vector<UINT>   vuiFootOut;
};


//******************************************************************************
//* Functions

/*******************************************************************************
 * Function:  usage
 * Purpose:   Printing help.
 * Parameter: iError: Error code program is exited.
 * Returns:   Nothing.
 *******************************************************************************/
void usage(int iError) {
  string sUsage =
    "usage: "ME_NAME" [--help] [-v|--version]\n"
    "       "ME_NAME" [-nhfd] [hb=] [fb=] [db=] file1 file2 [...]\n\n"
    "  -n:           No search for header signature.\n"
    "  -h:           Search for header signature (default).\n"
    "  -f:           Search for footer signature.\n"
    "  -d:           Print complete hex dump from file1.\n"
    "  hb:           Count of scanned header bytes. (default hb=128).\n"
    "  fb:           Count of scanned footer bytes. (default fb=128).\n"
    "  db:           Count of bytes for hex dump. (default db=0).\n"
    "  --help:       Print this help.\n"
    "  -v --version: Print version.\n";

  if (iError == ERR_NO_ERROR)
    cout << sUsage;
  else
    cerr << sUsage;

  exit(iError);
}

/*******************************************************************************
 * Function:  version
 * Purpose:   Prints program's version.
 * Parameter: Keine.
 * Returns:   Nothing.
 *******************************************************************************/
void version(void) {
  cout << ME_NAME << ": Version " << ME_VERSION << "\n";
  exit(ERR_NO_ERROR);
}

/*******************************************************************************
 * Function:  getOptions
 * Purpose:   Parsing commandline. Errors trigger usage().
 * Parameter: argc: Count of commandline parameters.
 *            argv: Value of commandline parameters.
 *            All othe paramters are references of returning values.
 * Returns:   Nothing.
 *******************************************************************************/
void getOptions(int            argc,
                char*          argv[],
                structOptions& stcOpts) {
  string strArgv = "";
  int    iLen    = 0;
  int    iChar   = 0;
  int    iPos    = 0;
  int    iArgv   = 0;
  int    i       = 0;

  // Defaultwerte.
  stcOpts.fHeader     = true;
  stcOpts.fFooter     = false;
  stcOpts.fDumpFile   = false;
  stcOpts.uiHeadCount = 128;
  stcOpts.uiFootCount = 128;
  stcOpts.uiDumpCount = 0,
  stcOpts.uiFileCount = 0;


  // Parsing all arguments.
  for (i = 1; i < argc; ++i) {
    // Convert argument to STL string.
    strArgv = argv[i];
    iLen = strArgv.size();

    // Parsing --help kind of arguments.
    if (strArgv[0] == '-' && strArgv[1] == '-') {
      if (strArgv == "--help")    usage(ERR_NO_ERROR);
      if (strArgv == "--version") version();
      continue; // Next argument.
    }

    // Parsing -nhfd kind of arguments.
    if (strArgv[0] == '-') {
      for (iChar = 1; iChar < iLen; ++iChar) {
        if (strArgv[iChar] == 'v') version();
        if (strArgv[iChar] == 'n') stcOpts.fHeader   = false;
        if (strArgv[iChar] == 'h') stcOpts.fHeader   = true;
        if (strArgv[iChar] == 'f') stcOpts.fFooter   = true;
        if (strArgv[iChar] == 'd') stcOpts.fDumpFile = true;
      }
      continue; // Next argument.
    }

    // Parsing hb=128 kind of arguments.
    iPos = strArgv.find('=');
    if (iPos > 0) {
      iArgv   = atoi(strArgv.substr(iPos + 1, iLen - iPos).c_str());
      strArgv = strArgv.substr(0, iPos);
      if (strArgv == "hb") stcOpts.uiHeadCount = iArgv;
      if (strArgv == "fb") stcOpts.uiFootCount = iArgv;
      if (strArgv == "db") stcOpts.uiDumpCount = iArgv;
      continue; // Next argument.
    }

    // Else argument is file name.
    stcOpts.vstrFiles.push_back(strArgv);
    stcOpts.uiFileCount += 1;
  }

  // Check of plausibility.
  if (stcOpts.uiFileCount == 0)                                   usage(ERR_CMD_PARAMETER);
  if (stcOpts.uiFileCount == 1 && !stcOpts.fDumpFile)             usage(ERR_CMD_PARAMETER);
  if (!stcOpts.fHeader && !stcOpts.fFooter && !stcOpts.fDumpFile) usage(ERR_CMD_PARAMETER);

  // Dump option has stronger binding as header and footer options.
  if (stcOpts.fDumpFile) {
    stcOpts.fHeader = false;
    stcOpts.fFooter = false;
  }
}

/*******************************************************************************
 * Function:  readDataFromFile
 * Purpose:   Reads given count of bytes from file.
 * Parameter: vuiData:      Vector with necessary data.
 *            strFile:      file to be opened.
 *            uiByteCount:  Count of bytes to be read.
 *            uiReadMode:   Determin from which side to read bytes.
 * Returns:   True: file could be read.
 *******************************************************************************/
bool readDataFromFile(vector<UINT>& viData,
                      string&       strFile,
                      UINT&         uiByteCount,
                      UINT          uiReadMode) {
  ifstream istFile;
  UINT     uiFilesize = 0;
  UINT     ui         = 0;
  char     cData      = 0;

  istFile.open(strFile.c_str(), ifstream::in | ifstream::binary);

  if (!istFile) {
    cout << "Could not open '" << strFile << "'!\n";
    return (false);
  }

  // Clear previous stored data.
  viData.clear();

  // Get file size.
  istFile.seekg(0, ifstream::end);
  uiFilesize = (UINT) istFile.tellg();
  istFile.seekg(0, ifstream::beg);

  // Adjust byte count for hex dump and smaller files.
  if ((uiByteCount > uiFilesize) || (uiReadMode == DUMP && uiByteCount == 0))
    uiByteCount = uiFilesize;

  // Set file pointer at the end if footer is needed.
  if (uiReadMode == FOOTER)
    istFile.seekg(-long(uiByteCount), ifstream::end);

  // Reads bytes into vector and convert to integers.
  for (ui = 0; ui < uiByteCount && !istFile.eof(); ++ui) {
    istFile.get(cData);
    viData.push_back ((UINT) (UCHAR) cData);
  }

  istFile.close();

  return (true);
}

/*******************************************************************************
 * Function:  diff
 * Purpose:   Generates byte vector with result of comparison.
 * Parameter: uiMode:       Mode is header, footer or hex dump.
 *            uiByteCount:  Number of bytes to compare.
 *            uiFileCount:  Number of files in vector.
 *            vstrFiles:    Paths of files to compare.
 *            vuiOut:       Generated valid and invalid bytes.
 * Returns:   0: No error occurred.
 *******************************************************************************/
int diff(UINT            uiMode,
         UINT            uiByteCount,
         UINT            uiFileCount,
         vector<string>& vstrFiles,
         vector<UINT>&   vuiOut) {
  vector<UINT> viCompare;
  UINT         uiByte = 0;
  UINT         ui     = 0;

  // Read first file.
  if (!readDataFromFile(vuiOut, vstrFiles[0], uiByteCount, uiMode))
    return (ERR_FILE_IO);

  // Sufficient for hex dump. ;-)
  if (uiMode == DUMP) return (ERR_NO_ERROR);

  // Compare additional files with first one.
  for (ui = 1; ui < uiFileCount; ++ui) {
    if (!readDataFromFile(viCompare, vstrFiles[ui], uiByteCount, uiMode))
      return (ERR_FILE_IO);

    for (uiByte = 0; uiByte < uiByteCount; ++uiByte) {
      if (vuiOut[uiByte] == NO_ENTRY)
        continue;

      if (vuiOut[uiByte] != viCompare[uiByte])
        vuiOut[uiByte] = NO_ENTRY;
    }
  }

  return (ERR_NO_ERROR);
}

/*******************************************************************************
 * Function:  tellDiff
 * Purpose:   Generates two byte vector with result of comparison.
 * Parameter: fDoHeader:    Set search header mode.
 *            fDoFooter:    Set search footer mode.
 *            fDumpFile:    Print hex dump of first file.
 *            uiHeadCount:  Number of headerbytes to compare.
 *            uiFootCount:  Number of footer bytes to compare.
 *            uiDumpCount:  Number of bytes to dump.
 *            uiFileCount:  Number of files in vector.
 *            vstrFiles:    Paths of files to compare.
 *            vuiHeadOut:   Generated valid and invalid header bytes.
 *            vuiFootOut:   Generated valid and invalid footer bytes.
 * Returns:   0: No error occurred.
 *******************************************************************************/
int tellDiff(structOptions& stcOpts) {
  if (stcOpts.fDumpFile) {
    if (diff(DUMP, stcOpts.uiDumpCount, stcOpts.uiFileCount, stcOpts.vstrFiles, stcOpts.vuiHeadOut)
        != ERR_NO_ERROR)
      return (ERR_DIFF);

    return (ERR_NO_ERROR);
  }

  if (stcOpts.fHeader)
    if (diff(HEADER, stcOpts.uiHeadCount, stcOpts.uiFileCount, stcOpts.vstrFiles, stcOpts.vuiHeadOut)
        != ERR_NO_ERROR)
      return (ERR_DIFF);

  if (stcOpts.fFooter)
    if (diff(FOOTER, stcOpts.uiFootCount, stcOpts.uiFileCount, stcOpts.vstrFiles, stcOpts.vuiFootOut)
        != ERR_NO_ERROR)
      return (ERR_DIFF);

  return (ERR_NO_ERROR);
}

/*******************************************************************************
 * Function:  byteToHexOut
 * Purpose:   Convert valid and invalid bytes to hex output.
 * Parameters:  vuiOut: Vector of integers to convert.
 * Return:      Hex output string.
 *******************************************************************************/
string printHexOut(vector<UINT>& vuiOut) {
  string strAdr      = "";
  string strHex      = "";
  string strAsc      = "";
  string strOut      = "";
  string strFrm      = "";
  bool   fLastLine   = false;
  UINT   uiByteCount = vuiOut.size();
  UINT   uiLine      = 0;
  UINT   uiByte      = 0;
  UINT   uiAdrLen    = 1;
  UINT   uiHexCount  = 0x10;
  char   cBuffer[50];

  // Output will look like this:
  // 00000000 |ff ff xx ff xx ff ff ff ff ff ff ff ff ff ff ff |01x3x56789abcdef

  // Check to make sure there is something to do.
  if (uiByteCount == 0)
    return ("-");

  // Compute max address for leading zeros in format string, e.g. "%08x ".
  while (uiHexCount < uiByteCount) {
    ++uiAdrLen;
    uiHexCount *= 0x10;
  }
  sprintf(cBuffer, "%i",uiAdrLen);
  strFrm   = "%0" + (string) cBuffer + "x ";

  // Join hex-editor-like output string.
  while (!fLastLine) {
    // Add address.
    sprintf(cBuffer, strFrm.c_str(),uiLine);
    strAdr += cBuffer;

    // Format bytes as hex and ASCII values.
    for (uiByte = uiLine; uiByte < uiLine + 0x10; ++uiByte) {
      // Hex values
      if (uiByte < uiByteCount) {
        if (vuiOut[uiByte] != NO_ENTRY) {
            sprintf(cBuffer, "%02x ",vuiOut[uiByte]);
            strHex += cBuffer;
        }
        else {
          strHex += "xx ";
        }
      }
      else {
        strHex += "   ";
      }

      // ASCII values.
      if (uiByte < uiByteCount) {
        if (vuiOut[uiByte] != NO_ENTRY) {
          if (vuiOut[uiByte] >= 32 && vuiOut[uiByte] <= MAX_PRINTABLE_ASCII) {
            sprintf(cBuffer, "%c",vuiOut[uiByte]);
            strAsc += cBuffer;
          }
          else {
            strAsc += ".";
          }
        }
        else {
          strAsc += "x";
        }
      }
      else {
        strAsc += " ";
      }
    }

    strOut += strAdr + "| " + strHex + "| " + strAsc + "\n";

    strAdr = "";
    strHex = "";
    strAsc = "";

    uiLine += 0x10;

    if (uiByteCount <= uiLine)
      fLastLine = true;
  }

  return (strOut);
}


//******************************************************************************
//* Main

/*******************************************************************************
 * Function:  main
 * Purpose:   Main entrance point of application.
 * Parameter: argc: Count of parameters.
 *            argv: Value of parameters.
 * Returns:   0: No error occurred.
 *******************************************************************************/
int main(int argc, char *argv[]) {
  structOptions  stcOpts;

  stcOpts.fHeader     = true;
  stcOpts.fFooter     = false;
  stcOpts.fDumpFile   = false;
  stcOpts.uiHeadCount = 128;
  stcOpts.uiFootCount = 128;
  stcOpts.uiDumpCount = 0;
  stcOpts.uiFileCount = 0;

  // Evaluate options.
  getOptions(argc, argv, stcOpts);

  // Compare files.
  if (tellDiff(stcOpts) != ERR_NO_ERROR)
    return (ERR_FILE_IO);

  // Print formatted result to stdout.
  if (stcOpts.fDumpFile) {
    cout << printHexOut(stcOpts.vuiHeadOut);
    return (ERR_NO_ERROR);
  }

  if (stcOpts.fHeader) {
    cout << "\nHeader:\n";
    cout << printHexOut(stcOpts.vuiHeadOut) << "\n\n";
  }

  if (stcOpts.fFooter) {
    cout << "\nFooter:\n";
    cout << printHexOut(stcOpts.vuiFootOut) << "\n\n";
  }

  return (ERR_NO_ERROR);
}
