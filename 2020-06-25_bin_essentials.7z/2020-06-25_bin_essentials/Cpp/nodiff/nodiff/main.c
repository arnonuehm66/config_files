/*******************************************************************************
 ** Name: nodiff
 ** Purpose: Identifies signatures of unknown file types.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 18.12.2004  JE    Created file.
 ** 23.12.2004  JE    Deleted main.h and minor adjustments.
 ** 23.12.2004  JE    Now usage() exit with given error code.
 ** 23.12.2004  JE    Added flag -d making hex dumping of file.
 ** 23.12.2004  JE    Now byteToHexOut() only shows chars 32 and higher.
 ** 23.12.2004  JE    Changed all singned chars to unsigne in dump.
 ** 23.12.2004  JE    Made converting from char to uint instead of UCHAR!
 ** 25.12.2004  JE    Extended dump with db= parameter.
 ** 27.12.2004  JE    Limited ASCII output between 32 to 126 for LINUX.
 ** 27.12.2004  JE    Now intercept out of bounds error in readDataFromFile().
 ** 09.09.2005  JE    Made nicer output with spaces. ;-)
 ** 09.09.2005  JE    Now calculate length of address after uiByteCount.
 ** 09.09.2005  JE    Now use conditionally compiling for Linux/Windows.
 ** 09.05.2008  JE    Now print usage to cerr if error occurred.
 ** 23.01.2009  JE    Added "(LINUX)", "(WINDOWS)" to verion cstr.
 ** 31.08.2009  JE    Changed LINUX switch logic for ASCII-output.
 ** 31.08.2009  JE    Project added to QT Creator. Switched language to english.
 ** 01.09.2009  JE    Set '-uiByteCount' to '-long(uiByteCount)' in seekg() to
 **                   prevent wrong footer count, thus eof() error.
 ** 31.10.2009  JE    Added 'cstdlib' on kubuntu 9.10 for usage of exit() and
 **                   atoi().
 ** 12.01.2011  JE    Prevents system from using first two files exclusively.
 ** 28.02.2013  JE    Now use a struct for all options.
 ** 22.08.2018  JE    Translate C++ to a plain C program.
 ** 22.08.2018  JE    Now use 'c_string.h' and 'c_dynamic_arrays.h'.
 ** 23.08.2018  JE    Now prints result insead of returning a string form func.
 ** 28.08.2018  JE    Added getHexIntParm() with new c_string.h version.
 ** 28.08.2018  JE    Changed all uint to apropriate ll and int.
 ** 11.09.2018  JE    Now uses c_string_v0.9.1.h with csSetf().
 ** 17.09.2018  JE    Changed shift() to avoid a cstr memory leak.
 ** 01.10.2018  JE    Now use csSetf() with "Can't open 'file'".
 ** 01.10.2018  JE    Corrected minor issues with int uint mismatch.
 ** 01.10.2018  JE    Switched from char buffer to cstr now use csSetf().
 ** 01.10.2018  JE    Changed printout.
 ** 23.04.2019  JE    Now use c_dynamic_arrays.h v0.3.3.
 ** 24.04.2019  JE    Added struct names.
 ** 31.05.2019  JE    Minor adjustements to standard functions.
 ** 31.05.2019  JE    Added openFile() and getFileSize() for convenience.
 ** 17.01.2020  JE    Now use external functions from 'stdfcns.c' source file.
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************/


//******************************************************************************
//* Switches

//#undef LINUX
#define LINUX


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME  "nodiff"
#define ME_VERNR "0.11.2"

#ifdef LINUX
  #define ME_VERSION  ME_VERNR " (Linux)"
  #define MAX_PRINTABLE_ASCII 126
#else
  #define ME_VERSION  ME_VERNR " (Windows)"
  #define MAX_PRINTABLE_ASCII 255
#endif

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"

#define NO_ENTRY 999

// Mode flags.
#define DUMP   0x00
#define HEADER 0x01
#define FOOTER 0x02


//******************************************************************************
//* outsourced standard functions

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  int fHeader;
  int fFooter;
  int fDump;
  ll  llHeadCount;
  ll  llFootCount;
  ll  llDumpCount;
} t_options;


//******************************************************************************
//* Global variables

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.
t_array_int  g_daiHeadOut;
t_array_int  g_daiFootOut;


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-Hfd] [hb=n] [fb=n] [db=n] file1 file2 [...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " This program identifies signatures of unknown file types by telling differences\n"
  " of given files at same byte offsets.\n"
  " Reads files and compares header and footer bytes. Print compared bytes similar\n"
  " to hex editor output, with a '--' ( and 'x'), where the bytes differ.\n"
  " 'hb', 'fb' and 'db' can be entered as hexadecimal with '0x' prefix or as\n"
  " decimal with postfix K, M, G (meaning Kilo- Mega- and Giga-bytes\n"
  " based on 1024).\n"
  "  -H:            don't search for header signature (default search header)\n"
  "  -f:            search for footer signature\n"
  "  -d:            print hex dump from file1\n"
  "  hb:            count of scanned header bytes (default hb=128)\n"
  "  fb:            count of scanned footer bytes (default fb=128)\n"
  "  db:            count of bytes for hex dump (default db=0 i.e. dump all bytes)\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv  = csNew("");
  cstr csRv    = csNew("");
  cstr csOpt   = csNew("");
  int  iArg    = 1;  // Omit programm name in arg loop.
  int  iChar   = 0;
  ll   llPos   = 0;
  char cOpt    = 0;

  // Set defaults.
  g_tOpts.fHeader     = 1;
  g_tOpts.fFooter     = 0;
  g_tOpts.fDump       = 0;
  g_tOpts.llHeadCount = 128;
  g_tOpts.llFootCount = 128;
  g_tOpts.llDumpCount = 0;

  daiInit(&g_daiHeadOut);
  daiInit(&g_daiFootOut);

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'H') {
          g_tOpts.fHeader = 0;
          continue;
        }
        if (cOpt == 'f') {
          g_tOpts.fFooter = 1;
          continue;
        }
        if (cOpt == 'd') {
          g_tOpts.fDump   = 1;
          g_tOpts.fHeader = 0;
          g_tOpts.fFooter = 0;
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }

    // Equality options:
    llPos = csInStr(0, csArgv.cStr, "=");
    if (llPos > 0) {
      csSplit(&csOpt, &csRv, csArgv.cStr, "=");
      if (!strcmp(csOpt.cStr, "hb")) {
        if (! getArgHexLong(&g_tOpts.llHeadCount, NULL, 0, NULL, ARG_VALUE, csRv.cStr))
          dispatchError(ERR_ARGS, "No valid hb or missing");
        continue;
      }
      if (!strcmp(csOpt.cStr, "fb")) {
        if (! getArgHexLong(&g_tOpts.llFootCount, NULL, 0, NULL, ARG_VALUE, csRv.cStr))
          dispatchError(ERR_ARGS, "No valid fb or missing");
        continue;
      }
      if (!strcmp(csOpt.cStr, "db")) {
        if (! getArgHexLong(&g_tOpts.llDumpCount, NULL, 0, NULL, ARG_VALUE, csRv.cStr))
          dispatchError(ERR_ARGS, "No valid db or missing");
        continue;
      }
      dispatchError(ERR_ARGS, "Invalid equality option");
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount == 0)
    dispatchError(ERR_ARGS, "No file");

  if (g_tArgs.sCount == 1 && g_tOpts.fDump == 0)
    dispatchError(ERR_ARGS, "Need mor than one file for comparisons");

  // Free cstr memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);

  return;
}


/*******************************************************************************
 * Function:  firstFile2Array
 * Purpose:   Opens first file and read all bytes into apropriate array.
 *******************************************************************************/
void firstFile2Array(void) {
  FILE* hFile       = NULL;
  ll    llFileSize  = 0;
  ll    llByteCount = 0;
  ll    llByte      = 0;

  hFile      = openFile(g_tArgs.pStr[0].cStr, "rb");
  llFileSize = getFileSize(hFile);

  //  Write bytes into appropriate array.
  if (g_tOpts.fDump) {
    llByteCount = (g_tOpts.llDumpCount > 0) ? g_tOpts.llDumpCount : llFileSize;

    if (llByteCount > llFileSize)
      llByteCount = llFileSize;

    for (llByte = 0; llByte < llByteCount; ++llByte)
      daiAdd(&g_daiHeadOut, (int) getc(hFile));
  }

  if (g_tOpts.fHeader) {
    llByteCount = (g_tOpts.llHeadCount > 0) ? g_tOpts.llHeadCount : llFileSize;

    if (llByteCount > llFileSize)
      llByteCount = llFileSize;

    for (llByte = 0; llByte < llByteCount; ++llByte)
      daiAdd(&g_daiHeadOut, (int) getc(hFile));
  }

  if (g_tOpts.fFooter) {
    llByteCount = (g_tOpts.llFootCount > 0) ? g_tOpts.llFootCount : llFileSize;

    if (llByteCount > llFileSize)
      llByteCount = llFileSize;

    fseek(hFile, -((long) llByteCount), SEEK_END);

    for (llByte = 0; llByte < llByteCount && !feof(hFile); ++llByte)
      daiAdd(&g_daiFootOut, (int) getc(hFile));
  }

  fclose(hFile);
}

/*******************************************************************************
 * Function:  diffFiles
 * Purpose:   Generates byte vector with result of comparison.
 *******************************************************************************/
void diffFiles(int iMode, t_array_int* pdaiOut) {
  FILE* hFile       = NULL;
  int   iFile       = 0;
  ll    llByteCount = 0;
  ll    llByte      = 0;

  // Security check.
  if (iMode == DUMP)
    return;

  for(iFile = 1; iFile < g_tArgs.sCount; ++iFile) {
    hFile = openFile(g_tArgs.pStr[iFile].cStr, "rb");

    // Set proper byte count ...
    llByteCount = (iMode == HEADER)
                ? g_tOpts.llHeadCount
                : g_tOpts.llFootCount;

    // ... and file offset.
    if (iMode == FOOTER)
      fseek(hFile, -llByteCount, SEEK_END);

    // Compare this array against file's bytes.
    for (llByte = 0; llByte < llByteCount && !feof(hFile); ++llByte)
      if (pdaiOut->pInt[llByte] != (int) getc(hFile))
        pdaiOut->pInt[llByte] = NO_ENTRY;

    fclose(hFile);
  }
}

/*******************************************************************************
 * Function:  tellDiffs
 * Purpose:   Tells difference between first and all other files.
 *******************************************************************************/
void tellDiffs(void) {
  if (g_tOpts.fDump)
    return;

  if (g_tOpts.fHeader)
    diffFiles(HEADER, &g_daiHeadOut);

  if (g_tOpts.fFooter)
    diffFiles(FOOTER, &g_daiFootOut);
}

/*******************************************************************************
 * Function:  byteToHexOut
 * Purpose:   Converts valid and invalid bytes and prints hex dump.
 *******************************************************************************/
void printHexOut(t_array_int* pdaiOut) {
  cstr csAdr     = csNew("");
  cstr csHex     = csNew("");
  cstr csAsc     = csNew("");
  cstr csFrm     = csNew("");
  cstr csTmp     = csNew("");
  int  fLastLine = 0;
  int  iLine     = 0;
  int  iByte     = 0;
  int  iAdrLen   = 1;
  int  iHexCount = 0x10;

  // Output will look like this:
  // 00000000| ff ff -- ff -- ff ff ff ff ff ff ff ff ff ff ff |01x3x56789abcdef|

  // Check to make sure there is something to do.
  if (pdaiOut->sCount == 0)
    return;

  // Compute max address for leading zeros in format cstr, e.g. "%08x ".
  while (iHexCount < pdaiOut->sCount) {
    ++iAdrLen;
    iHexCount *= 0x10;
  }

  // Calculate format string for printing correct address length.
  // csFrm = "%0" + iAdrLen + "x ";
  csSetf(&csFrm, "%%0%ix", iAdrLen);

  // Join hex-editor-like output line as cstr.
  while (!fLastLine) {
    // Save address in hex format of calculated length.
    csSetf(&csAdr, csFrm.cStr, iLine);

    // Assemble line with hex and ASCII values.
    for (iByte = iLine; iByte < iLine + 0x10; ++iByte) {

      // If line exceeds byte count in array, rest becomes empty.
      if (iByte >= pdaiOut->sCount) {
        csCat(&csHex, csHex.cStr, "   ");
        csCat(&csAsc, csAsc.cStr, " ");
        continue;
      }

      // Mark hex and ASCII byte if it's different.
      if (pdaiOut->pInt[iByte] == NO_ENTRY) {
        csCat(&csHex, csHex.cStr, "-- ");
        csCat(&csAsc, csAsc.cStr, "x");
        continue;
      }

      // Format hex and ASCII if it's equal (or dumped).
      csSetf(&csTmp, "%02x ", pdaiOut->pInt[iByte]);
      csCat(&csHex, csHex.cStr, csTmp.cStr);

      if (pdaiOut->pInt[iByte] >= 32 &&
          pdaiOut->pInt[iByte] <= MAX_PRINTABLE_ASCII) {
        csSetf(&csTmp, "%c", pdaiOut->pInt[iByte]);
        csCat(&csAsc, csAsc.cStr, csTmp.cStr);
      }
      else
        csCat(&csAsc, csAsc.cStr, ".");
    }

    // print csAdr + "| " + csHex + "|" + csAsc + "|\n";
    printf("%s| %s|%s|\n", csAdr.cStr, csHex.cStr, csAsc.cStr);

    csSet(&csHex, "");
    csSet(&csAsc, "");

    iLine += 0x10;

    if (iLine >= pdaiOut->sCount)
      fLastLine = 1;
  }

  csFree(&csAdr);
  csFree(&csHex);
  csFree(&csAsc);
  csFree(&csFrm);
  csFree(&csTmp);
}

/*******************************************************************************
 * Function:  printDiffs
 * Purpose:   Prints all diffs or dump.
 *******************************************************************************/
void printDiffs(void) {
  if (g_tOpts.fDump) {
    printHexOut(&g_daiHeadOut);
    return;
  }

  if (g_tOpts.fHeader) {
    printf("Header:\n");
    printHexOut(&g_daiHeadOut);
  }

  if (g_tOpts.fHeader && g_tOpts.fFooter) {
    printf("\n");
  }

  if (g_tOpts.fFooter) {
    printf("Footer:\n");
    printHexOut(&g_daiFootOut);
  }
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  firstFile2Array();
  tellDiffs();
  printDiffs();

  // Free all used memory, prior end of program.
  dacsFree(&g_tArgs);

  return ERR_NOERR;
}
