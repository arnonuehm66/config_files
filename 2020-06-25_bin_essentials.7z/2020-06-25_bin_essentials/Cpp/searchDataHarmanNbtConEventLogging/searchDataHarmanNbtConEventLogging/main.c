/*******************************************************************************
 ** Name: searchDataHarmanNbtConEventLogging
 ** Purpose:  Retrieves NBT's conEventLogging data from images.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 22.08.2018  JE    Created program.
 ** 04.09.2014  JE    Added '-i' for switch on filtering known IDs.
 ** 11.09.2018  JE    Now uses c_string_v0.9.1.h with csSetf().
 ** 13.09.2018  JE    Changed ID count from 128 to 118 to avoid IDs mismatches.
 ** 17.09.2018  JE    Changed shift() to avoid a cstr memory leak.
 ** 10.10.2018  JE    Changed ticks2datetime() to avoid a cstr memory leak.
 ** 17.10.2018  JE    Added new known IDs for filtering.
 ** 10.01.2019  JE    Simplified version().
 ** 10.01.2019  JE    Changed printEntry() from a collecting cstr to printf().
 ** 11.02.2019  JE    Added 'csFree(&csItem);' in datetime2ticks() preventing a
 **                   memory hole.
 ** 24.04.2019  JE    Added struct names and changed int's to -time_t's ticks.
 ** 20.05.2019  JE    Changed name from 'searchDataNbtHuConEventLog'.
 ** 31.05.2019  JE    Added openFile() for convenience.
 ** 10.07.2019  JE    Adjusted toInt() working with endian.h.
 ** 17.07.2019  JE    Now tm_isdst is set permanentely to 0 in datetime2ticks().
 ** 11.11.2019  JE    Deleted superflous variable 'iTicks' in 'printEntry()'.
 ** 20.01.2020  JE    Now use functions, includes and defines from 'stdfcns.c'.
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#define _XOPEN_SOURCE 700  // To get POSIX 2008 (SUS) strptime() and mktime()
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <endian.h>       // To get __LITTLE_ENDIAN

// Own libs :o)
#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "searchDataHarmanNbtConEventLogging"
#define ME_VERSION "0.4.2"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"

// getOptions(): Defines empty values.
#define NO_TICK ((time_t) ~0)   // Fancy contruction to get a (-1). ;o)


//******************************************************************************
//* outsourced standard functions

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  long   lByteOff;
  int    iPrtOff;
  int    iMatchCount;
  int    fIdMatching;
  time_t tTicksMin;
  time_t tTicksMax;
} t_options;

// Fifo
typedef struct s_entry {
  int    iUsed;
  time_t tTicks;
  int    iEventID;
  int    iEventData1;
  int    iEventData2;
  int    iEventData3;
  long   lOffset;
} t_entry;


//******************************************************************************
//* Global variables

// Entry's FIFO.
t_entry* g_ptFifo;

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.

// List of known IDs from 'conEventLoggong.bin' files.
int const g_icIDmax = 206;
int       g_aiID[]  = {   // count = 10 x 20 + 6 = 206
0x0100, 0x0102, 0x0102, 0x0103, 0x0106, 0x0106, 0x010c, 0x010c, 0x010d, 0x010e,
0x010e, 0x0114, 0x0115, 0x0116, 0x0118, 0x0119, 0x0119, 0x0200, 0x0202, 0x0202,
0x020c, 0x020d, 0x020e, 0x020e, 0x0210, 0x0210, 0x0215, 0x0218, 0x0219, 0x0219,
0x021c, 0x0280, 0x02c0, 0x0300, 0x0300, 0x0303, 0x0303, 0x0306, 0x0306, 0x030d,
0x030e, 0x0310, 0x0312, 0x0319, 0x0402, 0x0402, 0x0403, 0x0403, 0x0406, 0x040d,
0x0412, 0x0412, 0x0414, 0x0418, 0x0419, 0x0419, 0x0502, 0x0502, 0x0503, 0x0506,
0x050d, 0x0512, 0x0518, 0x0602, 0x0606, 0x060d, 0x0612, 0x0618, 0x0702, 0x0702,
0x0703, 0x070d, 0x070e, 0x0710, 0x0710, 0x0718, 0x0802, 0x0802, 0x0806, 0x080e,
0x080e, 0x0811, 0x0811, 0x0902, 0x0908, 0x0908, 0x090d, 0x0910, 0x0911, 0x0912,
0x0912, 0x0914, 0x0918, 0x0a00, 0x0a02, 0x0a03, 0x0a03, 0x0a08, 0x0a0d, 0x0a0e,
0x0a12, 0x0a12, 0x0a14, 0x0a18, 0x0a1c, 0x0b00, 0x0b02, 0x0b02, 0x0b08, 0x0b0d,
0x0b0d, 0x0b14, 0x0b17, 0x0c02, 0x0c02, 0x0c08, 0x0c11, 0x0c11, 0x0c17, 0x0c1c,
0x0d02, 0x0d06, 0x0d06, 0x0d08, 0x0d0c, 0x0d0e, 0x0d11, 0x0d11, 0x0d17, 0x0e02,
0x0e06, 0x0e0c, 0x0e0d, 0x0e0d, 0x0e0e, 0x0e10, 0x0e11, 0x0e1c, 0x0f00, 0x0f02,
0x0f02, 0x0f06, 0x0f0c, 0x0f0d, 0x0f0d, 0x0f0e, 0x0f1c, 0x1002, 0x1002, 0x101c,
0x1102, 0x1106, 0x110c, 0x110d, 0x110e, 0x1111, 0x1202, 0x1206, 0x120c, 0x120d,
0x120e, 0x1211, 0x1280, 0x12c0, 0x130d, 0x130d, 0x130e, 0x130e, 0x1311, 0x140e,
0x1411, 0x1508, 0x150e, 0x1511, 0x160e, 0x1806, 0x180e, 0x1811, 0x190e, 0x1a0e,
0x1a11, 0x1b0e, 0x1b11, 0x1c06, 0x1d0c, 0x1d11, 0x1e0c, 0x1e0e, 0x1e11, 0x1f0e,
0x200c, 0x200e, 0x210c, 0x2111, 0x230c, 0x240c, 0x2a06, 0x2b06, 0x2c0c, 0x2e06,
0x2e1a, 0x2f1a, 0x301a, 0x386d, 0x5b27, 0x9868
                      };

//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Prints help text and exit program.
 *******************************************************************************/
void usage(int iErr, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-b n] [-o] [-n n] [-i] [-y yyyy [-Y yyyy]] file1 [file2 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Retrieves NBT's conEventLogging data from images. With image '-n' can be set\n"
  " to higher values to get fewer false positives. If set to 1 the program will\n"
  " check for valid year in limits only.\n"
  " Limits are given as 4 digit year.\n"
  "  -b n:          byte offset in each file at cli (default 0)\n"
  "  -o:            print additional offset column (default none)\n"
  "  -n n:          set the number of matches before printing entries (default 3)\n"
  "                 must be higher than 0\n"
  "  -i:            enable known ID filtering (default disabled)\n"
  "  -y yyyy:       min year to consider a track as valid (default 2002)\n"
  "  -Y yyyy:       max year to consider a track as valid (default this year)\n"
  "                 -y and -Y must be between 1970 and 2038\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  zeroEntry
 * Purpose: Set  an entry object to '0'.
 *******************************************************************************/
void clearEntry(t_entry* ptEntry) {
  ptEntry->iUsed       = 0;
  ptEntry->tTicks      = 0;
  ptEntry->iEventID    = 0;
  ptEntry->iEventData1 = 0;
  ptEntry->iEventData2 = 0;
  ptEntry->iEventData3 = 0;
  ptEntry->lOffset     = 0;
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csLon  = csNew("");
  cstr csLat  = csNew("");
  int  iArg   = 1;  // Omit program name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Set defaults.
  g_tOpts.lByteOff    = 0;
  g_tOpts.iPrtOff     = 0;
  g_tOpts.iMatchCount = 3;
  g_tOpts.fIdMatching = 0;
  g_tOpts.tTicksMin   = 2002;   // This year will be converted into seconds.
  g_tOpts.tTicksMax   = NO_TICK;

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'b') {
          if (! getArgLong((ll*) &g_tOpts.lByteOff, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Byte offset is missing");
          continue;
        }
        if (cOpt == 'o') {
          g_tOpts.iPrtOff = 1;
          continue;
        }
        if (cOpt == 'n') {
          if (! getArgLong((ll*) &g_tOpts.iMatchCount, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Match counter is missing");
          continue;
        }
        if (cOpt == 'i') {
          g_tOpts.fIdMatching = 1;
          continue;
        }
        if (cOpt == 'y') {
          if (! getArgTime(&g_tOpts.tTicksMin, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Min year is missing");
          continue;
        }
        if (cOpt == 'Y') {
          if (! getArgTime(&g_tOpts.tTicksMax, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Max year is missing");
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount == 0)
    dispatchError(ERR_ARGS, "No file");

  if (g_tOpts.iMatchCount < 1)
    dispatchError(ERR_ARGS, "Match counter must be > 0") ;

  if (g_tOpts.tTicksMin < 1970 || g_tOpts.tTicksMin > 2038)
    dispatchError(ERR_ARGS, "Min year out of limits (1970 - 2038)");

  if (g_tOpts.tTicksMax != NO_TICK &&
     (g_tOpts.tTicksMax < 1970 || g_tOpts.tTicksMax > 2038))
    dispatchError(ERR_ARGS, "Max year out of limits (1970 - 2038)");

  // Get timestamps limits for verification.
  g_tOpts.tTicksMin = datetime2ticks(0, "", g_tOpts.tTicksMin, 1, 1, 0, 0, 0);
  if (g_tOpts.tTicksMax == NO_TICK)
    g_tOpts.tTicksMax = time(NULL);
  else
    // To fit this year it must end 1 sec befor end of last year!
    g_tOpts.tTicksMax = datetime2ticks(0, "", g_tOpts.tTicksMax - 1, 12, 31, 23, 59, 59);

  if (g_tOpts.tTicksMin >= g_tOpts.tTicksMax)
    dispatchError(ERR_ARGS, "'-Y' should be grater than '-y'");

//// XXX *************************************************************************
//cstr csTmp1 = csNew(""); cstr csTmp2 = csNew("");
//ticks2datetime(&csTmp1, "", (time_t*) &g_tOpts.iTicksMin);
//ticks2datetime(&csTmp2, "", (time_t*) &g_tOpts.iTicksMax);
//printf("min: %d\nmax: %d\n", g_tOpts.iTicksMin, g_tOpts.iTicksMax);
//printf("min: %s\nmax: %s\n", csTmp1.cStr, csTmp2.cStr); exit(0);
//// XXX *************************************************************************

  // Create fifo according option.
  g_ptFifo = (t_entry*) malloc(sizeof(t_entry) * g_tOpts.iMatchCount);

  // Init all entry objects;
  for(int i = 0; i < g_tOpts.iMatchCount; ++i)
    clearEntry(&g_ptFifo[i]);

  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csLon);
  csFree(&csLat);

  return;
}

/*******************************************************************************
 * Name:  getBytes
 * Purpose: Reads up to 4 bytes from file into a buffer.
 *******************************************************************************/
void getBytes(FILE* hFile, char* pcBuffer, int iCount, int* piErr) {
  for (int i = 0; i < iCount; ++i)
    pcBuffer[i] = getc(hFile);

  *piErr = feof(hFile);
  return;
}

/*******************************************************************************
 * Name:  getInt
 * Purpose: Converts up to 4 bytes into an short integer.
 *******************************************************************************/
int getInt(FILE* hFile, int iCount, int* piErr) {
  char ac4Bytes[4] = {0};

  getBytes(hFile, ac4Bytes, iCount, piErr);

  if (*piErr)
    return -1;

  *piErr = 0;
  return toInt(ac4Bytes, iCount);
}

/*******************************************************************************
 * Name:  printHeader
 * Purpose: Prints generic csv file header.
 *******************************************************************************/
void printHeader(void) {
  cstr csOut = csNew("");

  csSet(&csOut, "Timestamp (UTC)\tEvent ID\tData1\tData2\tData3");
  if (g_tOpts.iPrtOff)
    csCat(&csOut, csOut.cStr, "\tOffset");

  printf("%s\n", csOut.cStr);

  csFree(&csOut);
}

/*******************************************************************************
 * Name:  getValidData
 * Purpose: Gets raw bytes, converts the data and check its validity.
 *******************************************************************************/
int getValidData(t_entry* ptEntry) {
  ptEntry->iUsed = 0;

  // Check for timestamp inconsistencies.
  if (ptEntry->tTicks < g_tOpts.tTicksMin) return 0;
  if (ptEntry->tTicks > g_tOpts.tTicksMax) return 0;

  // Check for a valid ID.
  if (g_tOpts.fIdMatching) {
    for (int i = 0; i < g_icIDmax; ++i) {
      if (ptEntry->iEventID == g_aiID[i]) goto isOK;
    }
    return 0;
  }

isOK:
  ptEntry->iUsed = 1;
  return 1;
}

/*******************************************************************************
 * Name:  itFitsToLastEntry
 * Purpose: Check if current entry (tCe) is a valid successor of last (tLe).
 *******************************************************************************/
int itFitsToLastEntry(t_entry tCe) {
  t_entry tLe   = g_ptFifo[g_tOpts.iMatchCount - 1];
  long    lDiff = tCe.lOffset - tLe.lOffset;

  // Try to get a positive follow up position in a possible track.
  if (lDiff                  != 18) return 0;  // Is not the next data set in database.
  if (tCe.tTicks - tLe.tTicks <  0) return 0;  // Diff negative sec.
  if (tCe.tTicks - tLe.tTicks > 10) return 0;  // Diff more than 10 sec.

  return 1;
}

/*******************************************************************************
 * Name:  addEntryToFifo
 * Purpose: Fills 'first in, first out' buffer.
 *          head => [0], [1],  ... [n - 1], [n] => tail
 *******************************************************************************/
t_entry addEntryToFifo(t_entry tTail) {
  t_entry tHead = {0};

  // Pop top entry.
  tHead = g_ptFifo[0];

  // Shift entries one step ahead the line.
  for(int i = 1; i < g_tOpts.iMatchCount; ++i)
    g_ptFifo[i - 1] = g_ptFifo[i];

  // Insert new tail.
   g_ptFifo[g_tOpts.iMatchCount - 1] = tTail;

  // Return popped entry.
  return tHead;
}

/*******************************************************************************
 * Name:  printEntry
 * Purpose: Prints entry if its not empty.
 *******************************************************************************/
void printEntry(t_entry tEntry) {
  if (!tEntry.iUsed) return;  // Sanity check. Print used entries only.

  cstr csTime = csNew("");
  cstr scOff  = csNew("");

  ticks2datetime(&csTime, " (UTC)", tEntry.tTicks);

  printf("%s\t0x%04x\t0x%08x\t0x%08x\t0x%08x",
         csTime.cStr,
         tEntry.iEventID,
         tEntry.iEventData1,
         tEntry.iEventData2,
         tEntry.iEventData3);
  if (g_tOpts.iPrtOff)
    printf("\t%ld", tEntry.lOffset);
  printf("\n");

  csFree(&csTime);
  csFree(&scOff);
}

/*******************************************************************************
 * Name:  flushFifo.
 * Purpose: Print left entries in fifo, if it's full and delete them.
 *******************************************************************************/
void flushFifo() {
  // Print entries if fifo is full.
  if (g_ptFifo[0].iUsed) {
    for(int i = 0; i < g_tOpts.iMatchCount; ++i)
      printEntry(g_ptFifo[i]);
  }

  // Flush fifo.
  for(int i = 0; i < g_tOpts.iMatchCount; ++i)
    clearEntry(&g_ptFifo[i]);
}

//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  FILE*   hFile      = NULL;
  int     iEndOfFile = 0;
  t_entry tTopEntry  = {0};
  t_entry tCurrEntry = {0};

  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // To populate the var 'timezone' used in datetime2ticks().
  tzset();

  printHeader();

  // Get all data from all files.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    hFile = openFile(g_tArgs.pStr[i].cStr, "rb");
//-- file ----------------------------------------------------------------------
    // Set byte offset for each file.
    fseek(hFile, g_tOpts.lByteOff, SEEK_SET);

    // Loop all bytes in a file.
    while (!iEndOfFile) {
      tCurrEntry.lOffset     = ftell(hFile);
      tCurrEntry.tTicks      = getInt(hFile, 4, &iEndOfFile);
      tCurrEntry.iEventID    = getInt(hFile, 2, &iEndOfFile);
      tCurrEntry.iEventData1 = getInt(hFile, 4, &iEndOfFile);
      tCurrEntry.iEventData2 = getInt(hFile, 4, &iEndOfFile);
      tCurrEntry.iEventData3 = getInt(hFile, 4, &iEndOfFile);

      // End while-loop if EOF to execute flushFifo() the last time.
      if (iEndOfFile)
        continue;

      // Jump back to last offset plus one, if entry is not valid.
      if (!getValidData(&tCurrEntry)) {
        fseek(hFile, tCurrEntry.lOffset + 1, SEEK_SET);
        continue;
      }

      // Does it fit to last object in fifo?
      if (itFitsToLastEntry(tCurrEntry)) {
        tTopEntry = addEntryToFifo(tCurrEntry);
        printEntry(tTopEntry);
      }
      else {
        flushFifo();
        addEntryToFifo(tCurrEntry);
      }
    }
    flushFifo();
//-- file ----------------------------------------------------------------------
    fclose(hFile);
  }
  return ERR_NOERR;
}
