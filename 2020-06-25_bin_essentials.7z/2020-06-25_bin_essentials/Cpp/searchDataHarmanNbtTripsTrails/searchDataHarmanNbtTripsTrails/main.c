/*******************************************************************************
 ** Name: searchDataHarmanNbtTripsTrails
 ** Purpose:  Retrieve tracks from NBT's trips- and trails-files and images.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 02.04.2019  JE    Created program.
 ** 02.04.2019  JE    Copied from searchDataTomTomV3-4SqliteTracks.
 ** 11.04.2019  JE    Added '--hex' to process hex-string intead of binary data.
 ** 11.04.2019  JE    Added '--start' and '--end' as route's time interval.
 ** 23.04.2019  JE    Now use c_dynamic_arrays.h v0.3.3.
 ** 13.05.2019  JE    Added '--tracks' to process "start\tend\thex" csv files.
 ** 15.05.2019  JE    Renamed from 'searchDataNbtTripsTrails'.
 ** 31.05.2019  JE    Added openFile() for convenience.
 ** 10.07.2019  JE    Adjusted toInt() working with endian.h.
 ** 17.07.2019  JE    Now tm_isdst is set permanentely to 0 in datetime2ticks().
 ** 20.01.2020  JE    Now use functions, includes and defines from 'stdfcns.c'.
 ** 04.04.2020  JE    Corrected errors in usage text.
 ** 04.04.2020  JE    Now use c_string.h v0.14.1, thus changed csSplit() order.
 ** 04.04.2020  JE    Changed round5() to roundN() from stdfcns.c with 6 digits.
 ** 04.04.2020  JE    Now use initTimeFunctions() from stdfcns.c init tzset().
 ** 05.04.2020  JE    Now explicitly free 'pcLine' in readLine().
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Own libs :o)
#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "searchDataHarmanNbtTripsTrails"
#define ME_VERSION "0.4.7"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"

// getOptions(): Defines empty values.
#define NO_TICK ((time_t) ~0)   // Fancy contruction to get a (-1). ;o)


//******************************************************************************
//* outsourced standard functions

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  long   lByteOff;
  int    iPrtOff;
  int    iMatchCount;
  ldbl   ldLonMin;
  ldbl   ldLonMax;
  ldbl   ldLatMin;
  ldbl   ldLatMax;
  int    iTrkFile;
  cstr   csHexData;
  cstr   csDateStart;
  cstr   csDateEnd;
  time_t tTicksStart;
  time_t tTicksEnd;
} t_options;

// Fifo
typedef struct s_entry {
  int    iUsed;
  int    iId;
  ldbl   ldLon;
  ldbl   ldLat;
  int    iLon;
  int    iLat;
  time_t tStart;
  time_t tEnd;
  long   lOffset;
} t_entry;


//******************************************************************************
//* Global variables

// Entry and fifo.
t_entry  g_tE;
t_entry* g_ptFifo;

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Prints help text and exit program.
 *******************************************************************************/
void usage(int iErr, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-b n] [-o] [-n n] [-l 'lon,lat' -L 'lon,lat'] file1 [file2 ...]\n"
  "       " ME_NAME " [-n n] [-l 'lon,lat' -L 'lon,lat'] --tracks file1 [file2 ...]\n"
  "       " ME_NAME " [-n n] [-l 'lon,lat' -L 'lon,lat'] --hex <data> --start <date> --end <date>\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Retrieve tracks from binary SQLite's track files or image. With image '-n' can\n"
  " be set to higher values to get fewer false positives. If set to 1 the program\n"
  " will check for valid year and coordinates in limits only.\n"
  " Limits are given as WGS84 coordinates 'lonMin,latMin,lonMax,latMax', where lon\n"
  " and lat are decimal fractions.\n"
  " Example:\n"
  "  -l '-11,30' -L '40,70' => EU from Sweden to Spain and Ireland to Ukraine\n"
  " With '--hex', '--start' and '--end', data from a trips or trail database is expected.\n"
  " If '--tracks' is used the file must be comprised of three columns:\n"
  "   'UTC timestamp start \t UTC timestamp end \t path's BLOB hex string'\n"
  " The format of <date> is 'yyyy/mm/dd, hh:mm:ss, for <data> its a hex-string.\n"
  "  -b n:            byte offset per file (default 0)\n"
  "  -o:              print additional offset column (default none)\n"
  "  -n n:            set the number of matches before printing entries (default 2)\n"
  "                   must be higher than or equal 1\n"
  "  -l 'lon,lat'     min limit given as 'lon,lat' corrdinates (default no limit)\n"
  "  -L 'lon,lat'     max limit given as 'lon,lat' corrdinates (default no limit)\n"
  "  --tracks <file>: process a 'Start\tEnd\tHex' file\n"
  "  --hex <data>:    use this hex-string instead of a file\n"
  "  --start <date>:  date and time of route's start of hex-data (default '-')\n"
  "  --end <date>:    date and time of route's end of hex-data (default '-')\n"
  "  -h|--help:       print this help\n"
  "  -v|--version:    print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  zeroEntry
 * Purpose: Set an entry object to '0'.
 *******************************************************************************/
void clearEntry(t_entry* ptEntry) {
  ptEntry->iUsed   = 0;
  ptEntry->iId     = 0;
  ptEntry->ldLon   = 0.0;
  ptEntry->ldLat   = 0.0;
  ptEntry->iLon    = 0;
  ptEntry->iLat    = 0;
  ptEntry->tStart  = g_tOpts.tTicksStart;
  ptEntry->tEnd    = g_tOpts.tTicksEnd;
  ptEntry->lOffset = 0;
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr   csArgv   = csNew("");
  cstr   csRv     = csNew("");
  cstr   csLon    = csNew("");
  cstr   csLat    = csNew("");
  time_t tDateMin = 0;
  time_t tDateMax = 0;
  int    iArg     = 1;  // Omit program name in arg loop.
  int    iChar    = 0;
  char   cOpt     = 0;

  // Set defaults.
  g_tOpts.lByteOff    = 0;
  g_tOpts.iPrtOff     = 0;
  g_tOpts.iMatchCount = 2;
  g_tOpts.ldLonMin    = -180.0;
  g_tOpts.ldLonMax    =  180.0;
  g_tOpts.ldLatMin    =  -90.0;
  g_tOpts.ldLatMax    =   90.0;
  g_tOpts.iTrkFile    = 0;
  g_tOpts.csHexData   = csNew("");
  g_tOpts.csDateStart = csNew("2002/01/01, 00:00:00");
  g_tOpts.csDateEnd   = csNew("2038/01/01, 00:00:00");
  g_tOpts.tTicksStart = NO_TICK;
  g_tOpts.tTicksEnd   = NO_TICK;

  // Calc limits for checking below.
  tDateMin = datetime2ticks(1, g_tOpts.csDateStart.cStr, 0, 0, 0, 0, 0, 0);
  tDateMax = datetime2ticks(1, g_tOpts.csDateEnd.cStr,   0, 0, 0, 0, 0, 0);

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      if (!strcmp(csArgv.cStr, "--hex")) {

        shift(&csRv, &iArg, argc, argv);
        if (csRv.len == 0)
          dispatchError(ERR_ARGS, "Hex string is missing");
        csSet(&g_tOpts.csHexData, csRv.cStr);
        continue;
      }
      if (!strcmp(csArgv.cStr, "--tracks")) {
        g_tOpts.iTrkFile = 1;
        continue;
      }
      if (!strcmp(csArgv.cStr, "--start")) {

        shift(&csRv, &iArg, argc, argv);
        if (csRv.len == 0)
          dispatchError(ERR_ARGS, "Start date is missing");
        csSet(&g_tOpts.csDateStart, csRv.cStr);
        continue;
      }
      if (!strcmp(csArgv.cStr, "--end")) {

        shift(&csRv, &iArg, argc, argv);
        if (csRv.len == 0)
          dispatchError(ERR_ARGS, "End date is missing");
        csSet(&g_tOpts.csDateEnd, csRv.cStr);
        continue;
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'b') {
          if (! getArgLong((ll*) &g_tOpts.lByteOff, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Byte offset is missing");
          continue;
        }
        if (cOpt == 'o') {
          g_tOpts.iPrtOff = 1;
          continue;
        }
        if (cOpt == 'n') {
          if (! getArgLong((ll*) &g_tOpts.iMatchCount, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Match counter is missing");
          continue;
        }
        if (cOpt == 'l') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "Min limit coordinates are missing");
          csSplit(&csLon, &csLat, csRv.cStr, ",");
          g_tOpts.ldLonMin = cstr2ld(csLon);
          g_tOpts.ldLatMin = cstr2ld(csLat);
          continue;
        }
        if (cOpt == 'L') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "Max limit coordinates are missing");
          csSplit(&csLon, &csLat, csRv.cStr, ",");
          g_tOpts.ldLonMax = cstr2ld(csLon);
          g_tOpts.ldLatMax = cstr2ld(csLat);
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount == 0 && g_tOpts.csHexData.len == 0 && g_tOpts.iTrkFile == 0)
    dispatchError(ERR_ARGS, "No file and no hex-sting");

  if (g_tArgs.sCount > 0 && g_tOpts.csHexData.len > 0)
    dispatchError(ERR_ARGS, "No file needed for hex-sting proccessing");

  if (g_tOpts.iMatchCount < 1)
    dispatchError(ERR_ARGS, "Match counter must be > 0");

  if (g_tOpts.ldLonMin < -180.0 || g_tOpts.ldLonMax > 180.0)
    dispatchError(ERR_ARGS, "Longitude out of bounds (+/-180.0)");
  if (g_tOpts.ldLatMin < -90.0 || g_tOpts.ldLatMax > 90.0)
    dispatchError(ERR_ARGS, "Latitude out of bounds (+/-90.0)");

  // Use '--tracks' and '--hex' mutual exclusively.
  if (g_tOpts.iTrkFile && g_tOpts.csHexData.len > 0)
    dispatchError(ERR_ARGS, "Use either '--tracks' or '--hex'");

  // If '--hex' is used check for data errors.
  if (g_tOpts.csHexData.len > 0) {
    g_tOpts.tTicksStart = datetime2ticks(1, g_tOpts.csDateStart.cStr, 0, 0, 0, 0, 0, 0);
    g_tOpts.tTicksEnd   = datetime2ticks(1, g_tOpts.csDateEnd.cStr,   0, 0, 0, 0, 0, 0);

    if (g_tOpts.tTicksStart < tDateMin || g_tOpts.tTicksEnd > tDateMax)
      dispatchError(ERR_ARGS, "Date out of bounds (2002 - 2038)");

    if (g_tOpts.tTicksStart > g_tOpts.tTicksEnd)
      dispatchError(ERR_ARGS, "End date should be greater than start date");
  }

  // Create fifo according option.
  g_ptFifo = (t_entry*) malloc(sizeof(t_entry) * g_tOpts.iMatchCount);

  // Init all entry objects;
  clearEntry(&g_tE);
  for(int i = 0; i < g_tOpts.iMatchCount; ++i)
    clearEntry(&g_ptFifo[i]);

  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csLon);
  csFree(&csLat);

  return;
}

/*******************************************************************************
 * Name:  absLd
 * Purpose: Yields abs(dA).
 *******************************************************************************/
ldbl absLd(ldbl ldA) {
  if (ldA < 0.0) return -ldA;
  return ldA;
}

/*******************************************************************************
 * Name:
 * Purpose: Reads up to 4 bytes from file into a buffer.
 *******************************************************************************/
void getBytes(FILE* hFile, char* pcBuffer, int iCount, int* piErr) {
  for (int i = 0; i < iCount; ++i)
    pcBuffer[i] = getc(hFile);

  *piErr = feof(hFile);
  return;
}

/*******************************************************************************
 * Name:  getInt
 * Purpose: Converts up to 4 bytes into an short integer.
 *******************************************************************************/
int getInt(FILE* hFile, int iCount, int* piErr) {
  char ac4Bytes[4] = {0};

  getBytes(hFile, ac4Bytes, iCount, piErr);

  if (*piErr)
    return -1;

  *piErr = 0;
  return toInt(ac4Bytes, iCount);
}

/*******************************************************************************
 * Name:  printHeader
 * Purpose: Prints generic csv file header.
 *******************************************************************************/
void printHeader(void) {
  printf("Remark\tLongitude\tLatitude\tStart (UTC)\tEnd (UTC)");
  if (g_tOpts.iPrtOff)
    printf("\tOffset");
  printf("\n");
}

/*******************************************************************************
 * Name:  getValidData
 * Purpose: Gets raw bytes, converts the data and check its validity.
 *******************************************************************************/
int getValidData(void) {
  g_tE.iUsed = 0;

  // Ids shold be 0x1d 0x1e only.
  if (g_tE.iId != 0x1d && g_tE.iId != 0x1e) return 0;

  // Get coordinates and round to 6 digits.
  g_tE.ldLon = roundN((ldbl) g_tE.iLon * 90.0 / (1 << 30), 6);
  g_tE.ldLat = roundN((ldbl) g_tE.iLat * 90.0 / (1 << 30), 6);

  // Check for limits.
  if (g_tE.ldLon < g_tOpts.ldLonMin) return 0;
  if (g_tE.ldLon > g_tOpts.ldLonMax) return 0;
  if (g_tE.ldLat < g_tOpts.ldLatMin) return 0;
  if (g_tE.ldLat > g_tOpts.ldLatMax) return 0;

  g_tE.iUsed = 1;
  return 1;
}

/*******************************************************************************
 * Name:  itFitsToLastEntry
 * Purpose: Check if current entry is a valid continuation to the last.
 *******************************************************************************/
int itFitsToLastEntry(void) {
  long    lDOff = 0;
  t_entry tCe   = {0};  // Current entry.
  t_entry tLe   = {0};  // Last entry.

  tCe = g_tE;
  tLe = g_ptFifo[g_tOpts.iMatchCount - 1];

  // Try to get a positive follow up position in a possible track.
  lDOff = tCe.lOffset - tLe.lOffset;
  if (lDOff < 13 || lDOff > 360)           return 0;  // Is not the next data set in database.
  if (absLd(tCe.ldLon - tLe.ldLon) > 0.01) return 0;  // Lon's diff is way too big for Europe.
  if (absLd(tCe.ldLat - tLe.ldLat) > 0.01) return 0;  // Lat's diff is way too big.

  return 1;
}

/*******************************************************************************
 * Name:  addEntryToFifo
 * Purpose: Fills 'first in, first out' buffer.
 *          head => [0], [1],  ... [n - 1], [n] => tail
 *******************************************************************************/
t_entry addEntryToFifo(t_entry* ptTail) {
  t_entry tHead = {0};

  // Pop top entry.
  tHead = g_ptFifo[0];

  // Shift entries one step ahead the line.
  for(int i = 1; i < g_tOpts.iMatchCount; ++i)
    g_ptFifo[i - 1] = g_ptFifo[i];

  // Insert new tail.
   g_ptFifo[g_tOpts.iMatchCount - 1] = *ptTail;

  // Return popped entry.
  return tHead;
}

/*******************************************************************************
 * Name:  printEntry
 * Purpose: Prints entry if its not empty.
 *******************************************************************************/
void printEntry(t_entry* ptEntry) {
  // Sanity check.
  if (!ptEntry->iUsed) return;

  cstr csStart = csNew("-");
  cstr csEnd   = csNew("-");

  // Convert ticks to string for display.
  if (ptEntry->tStart != NO_TICK) ticks2datetime(&csStart, "", ptEntry->tStart);
  if (ptEntry->tEnd   != NO_TICK) ticks2datetime(&csEnd,   "", ptEntry->tEnd);

  printf("Trackpoint\t%.6Lf\t%.6Lf\t%s\t%s",
         ptEntry->ldLon,
         ptEntry->ldLat,
         csStart.cStr,
         csEnd.cStr);

  if (g_tOpts.iPrtOff)
    printf("\t%ld", ptEntry->lOffset);

  printf("\n");

  csFree(&csStart);
  csFree(&csEnd);
}

/*******************************************************************************
 * Name:  flushFifo
 * Purpose: Print left entries in fifo, if it's full and delete them.
 *******************************************************************************/
void flushFifo() {
  // Print entries if fifo is full.
  if (g_ptFifo[0].iUsed) {
    for(int i = 0; i < g_tOpts.iMatchCount; ++i)
      printEntry(&g_ptFifo[i]);
  }

  // Flush fifo.
  for(int i = 0; i < g_tOpts.iMatchCount; ++i)
    clearEntry(&g_ptFifo[i]);
}

/*******************************************************************************
 * Name:  processFiles
 * Purpose: .
 *******************************************************************************/
void processFiles(void) {
  FILE*   hFile      = NULL;
  int     iEndOfFile = 0;
  t_entry tTopEntry  = {0};

  // Get all data from all files.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    hFile = openFile(g_tArgs.pStr[i].cStr, "rb");
//-- file ----------------------------------------------------------------------
    // Set byte offset for each file.
    fseek(hFile, g_tOpts.lByteOff, SEEK_SET);

    // Loop all bytes in a file.
    iEndOfFile = 0;
    while (!iEndOfFile) {
      g_tE.lOffset = ftell(hFile);
      g_tE.iId     = getInt(hFile, 1, &iEndOfFile);
      /* unknown */  getInt(hFile, 4, &iEndOfFile);
      g_tE.iLon    = getInt(hFile, 4, &iEndOfFile);
      g_tE.iLat    = getInt(hFile, 4, &iEndOfFile);

      // End while-loop if EOA to execute flushFifo() the last time.
      if (iEndOfFile)
        continue;

      // Jump back to last offset plus one, if entry is not valid.
      if (!getValidData()) {
        fseek(hFile, g_tE.lOffset + 1, SEEK_SET);
        continue;
      }

      // Does it fit to last object in fifo?
      if (itFitsToLastEntry()) {
        tTopEntry = addEntryToFifo(&g_tE);
        printEntry(&tTopEntry);
      }
      else {
        flushFifo();
        addEntryToFifo(&g_tE);
      }
    }
    flushFifo();
//-- file ----------------------------------------------------------------------
    fclose(hFile);
  }
}

/*******************************************************************************
 * Name:  nibble2int
 * Purpose: Converts an hex-string nibble into an integer from 0 to 15.
 *******************************************************************************/
int nibble2int(char nibble) {
  if (nibble >= '0' && nibble <= '9') return nibble - '0';
  if (nibble >= 'a' && nibble <= 'f') return nibble - 'a' + 10;
  if (nibble >= 'A' && nibble <= 'F') return nibble - 'A' + 10;
  return -1;
}

/*******************************************************************************
 * Name:  hex2bin
 * Purpose: Converts an arbitrary hex-string into binary chars.
 *******************************************************************************/
long hex2bin(t_array_byte* pdabBytes, cstr* pcsHex) {
  int iMsn = 0;  // Most significant nibble.
  int iLsn = 0;  // Least significant nibble.

  for (int iLen = 0; iLen < pcsHex->len; iLen += 2) {
    // Convert an check for errors.
    if ((iMsn = nibble2int(pcsHex->cStr[iLen]    )) == -1 ||
        (iLsn = nibble2int(pcsHex->cStr[iLen + 1])) == -1)
      return -1;

    // Convert two hex nibbles into a unsigned char and add it to result-array.
    dabAdd(pdabBytes, (uchar) (iMsn * 16 + iLsn));
  }

  // Should be (pcsHex->len / 2)!
  return pdabBytes->sCount;
}


/*******************************************************************************
 * Name:  processHexData
 * Purpose: .
 *******************************************************************************/
void processHexData(void) {
  long         lLength   = 0;
  long         lSeek     = 0;
  t_array_byte dabBytes  = {0};
  t_entry      tTopEntry = {0};

  dabInit(&dabBytes);

  // Convert hex string to binary.
  lLength = hex2bin(&dabBytes, &g_tOpts.csHexData);

  if (lLength == -1)
    dispatchError(ERR_ELSE, "Hex string conversion error");

  // Loop all bytes.
  lSeek = g_tOpts.lByteOff;
  while (lSeek <= lLength) {
    g_tE.lOffset = lSeek;
    //------------------------------------------------
    g_tE.iId     = toInt((char*) &dabBytes.pBytes[lSeek], 1);
    ++lSeek;
    if (lSeek > lLength) continue;
    //------------------------------------------------
    /* unknown */
    lSeek += 4;
    if (lSeek > lLength) continue;
    //------------------------------------------------
    g_tE.iLon    = toInt((char*) &dabBytes.pBytes[lSeek], 4);
    lSeek += 4;
    if (lSeek > lLength) continue;
    //------------------------------------------------
    g_tE.iLat    = toInt((char*) &dabBytes.pBytes[lSeek], 4);
    lSeek += 4;
    if (lSeek > lLength) continue;
    //------------------------------------------------

    // Jump back to last offset plus one, if entry is not valid.
    if (!getValidData()) {
      lSeek = g_tE.lOffset + 1;
      continue;
    }

    // Does it fit to last object in fifo?
    if (itFitsToLastEntry()) {
      tTopEntry = addEntryToFifo(&g_tE);
      printEntry(&tTopEntry);
    }
    else {
      flushFifo();
      addEntryToFifo(&g_tE);
    }
  }
  flushFifo();

  // Delete and free bytes-array memory.
  dabFree(&dabBytes);
}

/*******************************************************************************
 * Name:  readLine
 * Purpose: Read a line from file, return it in a cstr.
 *******************************************************************************/
int readLine(FILE* hFile, cstr* pcsLine) {
  char*  pcLine     = NULL;
  size_t sLineLen   = 0;
  size_t sCharCount = 0;

  csSet(pcsLine, "");
  sCharCount = getline(&pcLine, &sLineLen, hFile);

  if (sCharCount == -1) return 0;

  // Get rid of trailing new line chars.
  csTrim(pcsLine, pcLine, 1);

  // Don't forget!
  free(pcLine);

  return 1;
}

/*******************************************************************************
 * Name:  processHexFile
 * Purpose: Open file and process data lines as '--start', '--end' and '--hex'.
 *******************************************************************************/
void processHexFile(void) {
  FILE* hFile  = NULL;
  cstr  csRest = csNew("");
  cstr  csLine = csNew("");

  // Get all data from all files.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    hFile = openFile(g_tArgs.pStr[i].cStr, "rt");
//-- file ----------------------------------------------------------------------
    // Pop first line (header).
    if (!readLine(hFile, &csLine)) goto nextfile;

    // Loop rest of lines (data).
    while (readLine(hFile, &csLine)) {
      // Split line into start, end, hex and set vars.
      // Assume: "Start \t End \t Hex-String \n".
      csSplit(&g_tOpts.csDateStart, &csRest,            csLine.cStr, "\t");
      csSplit(&g_tOpts.csDateEnd,   &g_tOpts.csHexData, csRest.cStr, "\t");

      g_tOpts.tTicksStart = datetime2ticks(1, g_tOpts.csDateStart.cStr, 0, 0, 0, 0, 0, 0);
      g_tOpts.tTicksEnd   = datetime2ticks(1, g_tOpts.csDateEnd.cStr,   0, 0, 0, 0, 0, 0);

      // This will insert current start and end timestamps into the entry fifo.
      /* Init all entry objects */                 clearEntry(&g_tE);
      for(int i = 0; i < g_tOpts.iMatchCount; ++i) clearEntry(&g_ptFifo[i]);

      processHexData();
    }
//-- file ----------------------------------------------------------------------
nextfile:
    fclose(hFile);
  }

  csFree(&csRest);
  csFree(&csLine);
}

//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // For timezone var in datetime2ticks().
  initTimeFunctions();

  printHeader();

  if (g_tOpts.iTrkFile)
    processHexFile();
  else {
    if (g_tOpts.csHexData.len == 0) processFiles();
    if (g_tOpts.csHexData.len >  0) processHexData();
  }

  return ERR_NOERR;
}
