/*******************************************************************************
 ** Name: denoiseData.c
 ** Purpose: Takes at least two files and write the most propable byte to file.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 15.01.2019  JE    Created program.
 ** 30.01.2019  JE    Correct byte to be iByte written to output file.
 ** 23.04.2019  JE    Now use c_dynamic_arrays.h v0.3.3.
 ** 24.04.2019  JE    Added struct names.
 ** 31.05.2019  JE    Added openFile() for convenience.
 ** 20.01.2020  JE    Now use functions, includes and defines from 'stdfcns.c'.
 ** 20.01.2020  JE    Deleted superfluous var hFile in main().
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 ** 24.06.2020  JE    Added '-d' to just write differences to stdout.
 ** 24.06.2020  JE    Adjusted output prints to past tense.
 ** 24.06.2020  JE    Minor fixes in compareNLogAllBytes().
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "denoiseData"
#define ME_VERSION "0.3.3"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"

#define NO_BYTE ((int) -1)


//******************************************************************************
//* outsourced standard functions

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  FILE* hFileOut;
  FILE* hFileLog;
  cstr  csFileOut;
  cstr  csFileLog;
  int   iPrtDiffs;
} t_options;


//******************************************************************************
//* Global variables

// Arguments
t_options    g_tOpts;   // CLI options and arguments.
t_array_cstr g_tArgs;   // Free arguments.
FILE**       g_phFiles; // File-handles.
int*         g_piBytes; // Bytes.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-o <file>] [-l <file>] file1 file2 [file3 ...]\n"
  "       " ME_NAME " -d file1 file2 [file3 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Compares at least two files byte by byte and write the most probable byte to\n"
  " a new file. Writes the differences and written bytes into a log-file.\n"
  " If the byte-count is ambigious, it writes a 0x00, and log it.\n"
  "  -o <file>:     output file name (default denoiseData.bin)\n"
  "  -l <file>:     log-file name (default denoiseData.log)\n"
  "  -d:            just print differences to stdout\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csOpt  = csNew("");
  int  iArg   = 1;  // Omit program name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Set defaults.
  g_tOpts.hFileOut  = NULL;
  g_tOpts.hFileLog  = NULL;
  g_tOpts.csFileOut = csNew("denoisedData.bin");
  g_tOpts.csFileLog = csNew("denoiseData.log");
  g_tOpts.iPrtDiffs = 0;

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'o') {
          if (! getArgStr(&g_tOpts.csFileOut, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Output file is missing");
          continue;
        }
        if (cOpt == 'l') {
          if (! getArgStr(&g_tOpts.csFileLog, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Log-file is missing");
          continue;
        }
        if (cOpt == 'd') {
          g_tOpts.iPrtDiffs = 1;
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount < 2)
    dispatchError(ERR_ARGS, "Need at least two files to denoise");

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);

  return;
}

/*******************************************************************************
 * Name:  initInFilesNBytesArray
 * Purpose: Inits read file-handles and bytes array.
 *******************************************************************************/
void initInFilesNBytesArray(void) {
  g_phFiles = (FILE**) malloc(g_tArgs.sCount * sizeof(FILE*));
  g_piBytes = (int*)   malloc(g_tArgs.sCount * sizeof(int));

  // Open all files, save the file-handles and init the read-bytes array.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    g_phFiles[i] = openFile(g_tArgs.pStr[i].cStr, "rb");
    g_piBytes[i] = NO_BYTE;
  }
}

/*******************************************************************************
 * Name:  openAllOutFiles
 * Purpose: Opens all output files, if iPrtDiffs not set.
 *******************************************************************************/
void openAllOutFiles(void) {
  if (g_tOpts.iPrtDiffs) return;

  cstr  csMsg = csNew("");

  // Open output file to save denoised data.
  if ((g_tOpts.hFileOut = fopen(g_tOpts.csFileOut.cStr, "wb")) == NULL) {
    csSetf(&csMsg, "Can't open output file '%s'", g_tOpts.csFileOut.cStr);
    dispatchError(ERR_FILE, csMsg.cStr);
  }

  // Open log-file.
  if ((g_tOpts.hFileLog = fopen(g_tOpts.csFileLog.cStr, "wb")) == NULL) {
    csSetf(&csMsg, "Can't open log-file '%s'", g_tOpts.csFileLog.cStr);
    dispatchError(ERR_FILE, csMsg.cStr);
  }

  csFree(&csMsg);
}

/*******************************************************************************
 * Name:  endOfAllFiles
 * Purpose: Returns eof if all files failed to read a byte.
 *******************************************************************************/
int endOfAllFiles(void) {
  for (int i = 0; i < g_tArgs.sCount; ++i)
    if (g_piBytes[i] != NO_BYTE)
      return 0;
  return 1;
}

/*******************************************************************************
 * Name:  getAllBytes
 * Purpose: Reads all bytes and sets shorter file's bytes to 0 and eof to 1.
 *******************************************************************************/
int getAllBytes(void) {
  uchar ucByte = 0;

  for (int i = 0; i < g_tArgs.sCount; ++i) {
    if (fread(&ucByte, sizeof(uchar), 1, g_phFiles[i]) == 1)
      g_piBytes[i] = (int) ucByte;
    else
      g_piBytes[i] = NO_BYTE;
  }

  return endOfAllFiles();
}

/*******************************************************************************
 * Name:  compareNLogAllBytes
 * Purpose: Compare bytes and log all differences and ambiguities with offset.
 *******************************************************************************/
int compareNLogAllBytes(li liOff) {
  cstr csMsg       = csNew("");
  cstr csBytes     = csNew("");
  cstr csType      = csNew("");
  int  aiByte[256] = {0};
  int  iHighest1   = 0;
  int  iHighest2   = 0;
  int  iByte       = NO_BYTE;

  // Count numbers of bytes found in the files at the same offset.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    if (g_piBytes[i] == NO_BYTE)
      csSetf(&csBytes, "%s, 0x--",   csBytes.cStr);
    else
      csSetf(&csBytes, "%s, 0x%02x", csBytes.cStr, g_piBytes[i]);
    ++aiByte[g_piBytes[i]];
  }

  // Search for most and second most byte occurrences, and save them.
  for (int i = 0; i < 256; ++i) {
    if (aiByte[i] != NO_BYTE) {
      if (iHighest1 <  aiByte[i]) {
        iHighest2 = iHighest1;
        iHighest1 = aiByte[i];
        iByte     = i;
      }
    }
  }

  // Everything OK, return saved byte.
  if (iHighest1 == g_tArgs.sCount) goto free_and_exit;

  // Cut the first ", ".
  csMid(&csBytes, csBytes.cStr, 2, -1);

  // Print appropriate message to stderr and log-file.
  if (iHighest1 == iHighest2) {
    iByte = 0;
    csSet(&csType, "amb");
  }
  else {
    csSet(&csType, "diff");
  }
  csSetf(&csMsg, "%s @ %li (%s) wrote 0x%02x\n", csType.cStr, liOff, csBytes.cStr, iByte);
  if (g_tOpts.iPrtDiffs) {
    printf(csMsg.cStr);
  }
  else {
    fprintf(stderr,           csMsg.cStr);
    fprintf(g_tOpts.hFileLog, csMsg.cStr);
  }

free_and_exit:
  csFree(&csMsg);
  csFree(&csBytes);
  csFree(&csType);

  return iByte;
}

/*******************************************************************************
 * Name:  writeByteToFile
 * Purpose: Counts all bytes. Writes byte of highest count to out file, if
 *          iPrtDiffs not set.
 *******************************************************************************/
void writeByteToFile(int iByte) {
  if (g_tOpts.iPrtDiffs) return;

  uchar cByte = (uchar) iByte;
  fwrite(&cByte, sizeof(uchar), 1, g_tOpts.hFileOut);
}

/*******************************************************************************
 * Name:  freeInFilesNBytesArray
 * Purpose: Free read file-handles and bytes array.
 *******************************************************************************/
void freeInFilesNBytesArray(void) {
  free(g_phFiles);
  free(g_piBytes);
}

/*******************************************************************************
 * Name:  closeAllOutFiles
 * Purpose: Closes all output files, if iPrtDiffs not set.
 *******************************************************************************/
void closeAllOutFiles(void) {
  if (g_tOpts.iPrtDiffs) return;

  fclose(g_tOpts.hFileOut);
  fclose(g_tOpts.hFileLog);
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  int iByte = NO_BYTE;
  li  liOff = 0;

  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  initInFilesNBytesArray();
  openAllOutFiles();

  // Compare all files, until at least one is eof.
  while (! getAllBytes()) {
    iByte = compareNLogAllBytes(liOff++);
    writeByteToFile(iByte);
  }

  freeInFilesNBytesArray();
  closeAllOutFiles();

  // Free used memory, prior end of program.
  dacsFree(&g_tArgs);

  return ERR_NOERR;
}
