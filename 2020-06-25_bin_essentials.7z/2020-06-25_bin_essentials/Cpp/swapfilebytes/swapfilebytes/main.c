/*******************************************************************************
 ** Name: swapfilebytes
 ** Purpose: Swap bytes and blocks from file(s) and print them to stdout.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 02.06.2020  JE    Created program.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "swapfilebytes"
#define ME_VERSION "0.1.1"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS  "Argument error"
#define sERR_FILE  "File error"
#define sERR_ELSE  "Unknown error"


//******************************************************************************
//* outsourced standard functions, includes and defines

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  int         iBytes2Swap;
  int         fInverse;
  t_array_int daiByteOrder;
  ll          llOffset;
} t_options;


//******************************************************************************
//* Global variables

// Arguments
t_options    g_tOpts;       // CLI options and arguments.
t_array_cstr g_tArgs;       // Free arguments.
int*         g_paiBytes;    // Bytes to swap.
int*         g_paiBytesOut; // Swapped bytes for output.
int          g_iByteCount;  // Number of bytes in swap array.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-b n] [-i] [-o <list>] [--offset n] file1 [file2 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Reads file(s) and prints swapped byte(s) to stdout.\n"
  " '-b' defines the bytes per block to swap with block order list '-o'. '-i'\n"
  " inverses the byte order per block.\n"
  " '--offset' can be entered as hexadecimal with '0x' prefix or as decimal\n"
  " with postfix K, M, G (meaning Kilo- Mega- and Giga-bytes based on 1024).\n"
  " \n"
  " Example: To swap bytes from '1 2 | 3 4 | 5 6' to '6 5 | 2 1 | 4 3'\n"
  "          use '-b 2 -i -o 3,1,2' as arguments.\n"
  " \n"
  "  -b n:          number of bytes per block to swap (default 1)\n"
  "  -i:            inverse byte order in block if '-b' > 1\n"
  "  -o <list>:     order of byte-blocks list to swap (default 2,1)\n"
  "  --offset n:    set byte offset where file(s) start to be read\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS)  csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE)  csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE)  csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  addItem2ArrayCut2Next
 * Purpose: Gets next item from oder list and snips it. Saves item in array.
 *******************************************************************************/
void addItem2ArrayCut2Next(ll llPos, cstr* pcsOrder) {
  int iItem = 0;

  iItem = cstr2ll(*pcsOrder) - 1;

  if (iItem < 0) dispatchError(ERR_ARGS, "All order list items must be > 1");

  daiAdd(&g_tOpts.daiByteOrder, iItem);

  csMid(pcsOrder, pcsOrder->cStr, llPos + 1, -1);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv  = csNew("");
  cstr csRv    = csNew("");
  cstr csOpt   = csNew("");
  cstr csOrder = csNew("");
  int  iArg    = 1;  // Omit program name in arg loop.
  int  iChar   = 0;
  char cOpt    = 0;
  ll   llPos   = 0;


  // Set defaults.
  g_tOpts.iBytes2Swap = 1;
  g_tOpts.fInverse    = 0;
  daiInit(&g_tOpts.daiByteOrder);
  g_tOpts.llOffset    = 0;

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      if (!strcmp(csArgv.cStr, "--offset")) {
        if (! getArgHexLong((ll*) &g_tOpts.llOffset, &iArg, argc, argv, ARG_CLI, NULL))
          dispatchError(ERR_ARGS, "No valid offset or missing");
        continue;
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'b') {
          if (! getArgLong((ll*) &g_tOpts.iBytes2Swap, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Bytes to swap is < 1 or missing");
          continue;
        }
        if (cOpt == 'i') {
          g_tOpts.fInverse = 1;
          continue;
        }
        if (cOpt == 'o') {
          if (! getArgStr(&csOrder, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Bytes order List is missing");
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount  == 0) dispatchError(ERR_ARGS, "No file");
  if (g_tOpts.llOffset < 0) dispatchError(ERR_ARGS, "Offset < 0");

  if (csOrder.len == 0) {
    // Defaults -o 2,1 (1 0)
    daiAdd(&g_tOpts.daiByteOrder, 1);
    daiAdd(&g_tOpts.daiByteOrder, 0);
  }
  else {
    // Turn '3,1,2' into '2' '0' '1'.
    while ((llPos = csInStr(0, csOrder.cStr, ",")) != -1)
      addItem2ArrayCut2Next(llPos, &csOrder);
    // Get item after last ','.
    if (csOrder.len > 0)
      addItem2ArrayCut2Next(llPos, &csOrder);
  }

  // Allocate 'byte-count' times 'order list size' sized byte array.
  g_iByteCount  = g_tOpts.iBytes2Swap * g_tOpts.daiByteOrder.sCount;
  g_paiBytes    = (int*) malloc(sizeof(int) * g_iByteCount);
  g_paiBytesOut = (int*) malloc(sizeof(int) * g_iByteCount);

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);
  csFree(&csOrder);
}

/*******************************************************************************
 * Name:  readBytes2List
 * Purpose: Reads bytes from current file into the global byte array.
 *******************************************************************************/
int readBytes2List(FILE* hFile) {
  char cByte = 0;

  // Read needed bytes from file and store it in the byte swap array.
  for (int i = 0; i < g_iByteCount; ++i) {
    if (fread(&cByte, sizeof(char), 1, hFile) == 0) return 1;
    g_paiBytes[i] = (int) cByte;
  }
  return 0;
}

/*******************************************************************************
 * Name:  swapBytesInList
 * Purpose: Swaps bytes in array according options -b, -i and -o.
 *******************************************************************************/
void swapBytesInList(void) {
  int iOffIn  = 0;
  int iOffOut = 0;
  // 1 2 | 3 4 | 5 6  => -b 2 -i -o 3,1,2 ( = 2 0 1)
  // 6 5 | 2 1 | 4 3  <=

  for (int i = 0; i < g_tOpts.daiByteOrder.sCount; ++i) {
    iOffIn  = g_tOpts.iBytes2Swap * g_tOpts.daiByteOrder.pInt[i];
    iOffOut = g_tOpts.iBytes2Swap * i;

    if (g_tOpts.fInverse)
      for (int iPos = 0; iPos < g_tOpts.iBytes2Swap; ++iPos)
        g_paiBytesOut[iOffOut + g_tOpts.iBytes2Swap - 1 - iPos] = g_paiBytes[iOffIn + iPos];
    else
      for (int iPos = 0; iPos < g_tOpts.iBytes2Swap; ++iPos)
        g_paiBytesOut[iOffOut + iPos] = g_paiBytes[iOffIn + iPos];
  }
}

/*******************************************************************************
 * Name:  .
 * Purpose: .
 *******************************************************************************/
void printNewBytesOrder(void) {
  for (int i = 0; i < g_iByteCount; ++i)
    printf("%c", (char) g_paiBytesOut[i]);
}

//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  FILE* hFile  = NULL;

  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // Get all data from all files.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    hFile = openFile(g_tArgs.pStr[i].cStr, "rb");
//-- file ----------------------------------------------------------------------
    if (g_tOpts.llOffset > 0) fseek(hFile, g_tOpts.llOffset, SEEK_SET);
    while (!feof(hFile)) {
      if (readBytes2List(hFile)) continue;
      swapBytesInList();
      printNewBytesOrder();
    }
//-- file ----------------------------------------------------------------------
    fclose(hFile);
  }

  // Free all used memory, prior end of program.
  dacsFree(&g_tArgs);
  daiFree(&g_tOpts.daiByteOrder);
  free(g_paiBytes);
  free(g_paiBytesOut);

  return ERR_NOERR;
}
