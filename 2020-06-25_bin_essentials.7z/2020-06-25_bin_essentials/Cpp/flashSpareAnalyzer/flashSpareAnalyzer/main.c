/*******************************************************************************
 ** Name: flashSpareAnalyzer.c
 ** Purpose: Print analyzed spare data bytes as offset over bytes table.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 18.12.2018  JE    Created program.
 ** 31.12.2018  JE    Added '-c' to print count of spare data areas.
 ** 31.12.2018  JE    Added '--percent' to print percents instead of numbers.
 ** 02.01.2019  JE    Now checks for premature end of file while reading bytes.
 ** 02.01.2019  JE    Added checks wether page or spare sizes are reater zero.
 ** 07.01.2019  JE    Now is able to use multiple files.
 ** 08.01.2019  JE    Added progress printed to stderr.
 ** 08.01.2019  JE    Adjusted offset and file size to 'li'.
 ** 23.04.2019  JE    Now use c_dynamic_arrays.h v0.3.3.
 ** 24.04.2019  JE    Added struct names.
 ** 31.05.2019  JE    Added openFile() for convenience.
 ** 07.08.2019  JE    Added '-o' for a byte-offset in the file(s) to start at.
 ** 28.09.2019  JE    Now option '-o n' and '-d' work together.
 ** 20.01.2020  JE    Now use functions, includes and defines from 'stdfcns.c'.
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "flashSpareAnalyzer"
#define ME_VERSION "0.6.2"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"


//******************************************************************************
//* outsourced standard functions

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  li     liOffset;
  int    fCountSpares;
  int    fTranspose;
  int    fPageFirst;
  int    iPageSize;
  int    iSpareSize;
  int    fPercent;
  uchar* pucSpareData;
  int*   paiMatrix;
} t_options;


//******************************************************************************
//* Global variables

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-o n] [-c] [-t] [-d] [-p n] [-s n] [--percent] file1 [file2 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Print analyzed spare data bytes as offset (e.g. 0 to 64) over bytes (0 to 255)\n"
  " printing the count in each cell.\n"
  " '-o', '-p' and '-s' can be entered as hexadecimal with '0x' prefix or as\n"
  " decimal with postfix K, M, G (meaning Kilo- Mega- and Giga-bytes based on\n"
  " 1024).\n"
  "  -o n:          offset in bytes to start at\n"
  "  -c:            print count of accumulated spare-data areas\n"
  "  -t:            print transposed table\n"
  "  -d:            spare data comes first (default page data)\n"
  "  -p n:          page size in bytes (default 2048 bytes)\n"
  "  -s n:          spare size in bytes (default 64 bytes)\n"
  "  --percent      print percentage instead of numbers\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csOpt  = csNew("");
  int  iArg   = 1;  // Omit program name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Set defaults.
  g_tOpts.liOffset     = 0;
  g_tOpts.fCountSpares = 0;
  g_tOpts.fTranspose   = 0;
  g_tOpts.fPageFirst   = 1;
  g_tOpts.iPageSize    = 2048;
  g_tOpts.iSpareSize   = 64;
  g_tOpts.fPercent     = 0;
  g_tOpts.pucSpareData = NULL;
  g_tOpts.paiMatrix    = NULL;

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      if (!strcmp(csArgv.cStr, "--percent")) {
        g_tOpts.fPercent = 1;
        continue;
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'o') {
          if (! getArgHexLong((ll*) &g_tOpts.liOffset, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "No valid offset or missing");
          continue;
        }
        if (cOpt == 'c') {
          g_tOpts.fCountSpares = 1;
          continue;
        }
        if (cOpt == 't') {
          g_tOpts.fTranspose = 1;
          continue;
        }
        if (cOpt == 'd') {
          g_tOpts.fPageFirst = 0;
          continue;
        }
        if (cOpt == 'p') {
          if (! getArgHexLong((ll*) &g_tOpts.iPageSize, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "No valid page size or missing");
          continue;
        }
        if (cOpt == 's') {
          if (! getArgHexLong((ll*) &g_tOpts.iSpareSize, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "No valid spare size or missing");
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount < 1)
    dispatchError(ERR_ARGS, "Need at least one file");

  // Check of correct sizes.
  if (g_tOpts.iPageSize < 1)
    dispatchError(ERR_ARGS, "Page size should be at least 1 byte");
  if (g_tOpts.iSpareSize < 1)
    dispatchError(ERR_ARGS, "Spare-area size should be at least 1 byte");

  // Create space for spare data and a 2 dimensional (256 by size of spare
  // data) int arrays.
  g_tOpts.pucSpareData = (uchar*) malloc(      g_tOpts.iSpareSize * sizeof(uchar));
  g_tOpts.paiMatrix    = (int*)   malloc(256 * g_tOpts.iSpareSize * sizeof(int));

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);

  return;
}

/*******************************************************************************
 * Name:  incMatrix
 * Purpose: Increments propper byte value in the matrix.
 *******************************************************************************/
void incMatrix(int iByte, int iSpareOff) {
  ++g_tOpts.paiMatrix[iByte * g_tOpts.iSpareSize + iSpareOff];
}

/*******************************************************************************
 * Name:  getMatrix
 * Purpose: Gets matrix value.
 *******************************************************************************/
int getMatrix(int iByte, int iSpareOff) {
  return g_tOpts.paiMatrix[iByte * g_tOpts.iSpareSize + iSpareOff];
}

/*******************************************************************************
 * Name:  goOffCalcNext
 * Purpose: Sets offset and calc offset to the next spare area.
 *******************************************************************************/
void goOffCalcNext(FILE* hFile, li* pliOff) {
  fseek(hFile, *pliOff, SEEK_SET);
  *pliOff += g_tOpts.iPageSize + g_tOpts.iSpareSize;
}

/*******************************************************************************
 * Name:  readSpareBytes
 * Purpose: Saves spare bytes into global spare data char array.
 *******************************************************************************/
int readSpareBytes(FILE* hFile) {
  size_t count = fread(g_tOpts.pucSpareData, sizeof(uchar), g_tOpts.iSpareSize, hFile);
  if (count == g_tOpts.iSpareSize) return 1;
  return 0;
}

/*******************************************************************************
 * Name:  accumulateSpareBytes
 * Purpose: Reads spare data and increments byte counts in matrix.
 *******************************************************************************/
void accumulateSpareBytes(void) {
  for (int iOff = 0; iOff < g_tOpts.iSpareSize; ++iOff)
    incMatrix(g_tOpts.pucSpareData[iOff], iOff);
}

/*******************************************************************************
 * Name:  printVal
 * Purpose: Prints value as integer or percentage.
 *******************************************************************************/
void printVal(int iCount, int iVal, const char* pcEnd) {
  if (g_tOpts.fPercent) {
    float fVal = (float) iVal / (float) iCount * 100.0;
    printf("%.2f%%", fVal);
  }
  else
    printf("%d", iVal);
  printf("%s", pcEnd);
}

/*******************************************************************************
 * Name:  printResultingTable
 * Purpose: Prints resulting table to stdout.
 *        0 1 2 3 4 5 6 7          0x00 0x01 ... 0xfe 0xff
 *  0x00  0 0 0 0 0 0 0 0       0    0    0  ...   0    0
 *   ...                   OR   ...
 *  0xff  0 2 4 9 9 9 1 0       7    1    0  ...   9    1
 *******************************************************************************/
void printResultingTable(int iCount) {
  cstr csLine = csNew("");

  // Print spare data area count
  if (g_tOpts.fCountSpares)
    printf("Total count of spare-data areas: %d\n", iCount);

  // Print it normal or kind of reversed.
  if (g_tOpts.fTranspose) {
    // Print first line.
    printf("off \\ byte\t");
    for (int iByte = 0; iByte < 255; ++iByte)
      printf("0x%02x\t", iByte);
    printf("0x%02x\n", 255);

    // Print byte value over spare offset.
    for (int iOff = 0; iOff < g_tOpts.iSpareSize; ++iOff) {
      printf("%d\t", iOff);

      for (int iByte = 0; iByte < 255; ++iByte)
        printVal(iCount, getMatrix(iByte, iOff), "\t");
      printVal(iCount, getMatrix(255, iOff), "\n");
    }
  }
  else {
    // Print first line.
    printf("byte \\ off\t");
    for (int iOff = 0; iOff < g_tOpts.iSpareSize - 1; ++iOff)
      printf("%d\t", iOff);
    printf("%d\n", g_tOpts.iSpareSize - 1);

    // Print spare offset over byte value.
    for (int iByte = 0; iByte < 256; ++iByte) {
      printf("0x%02x\t", iByte);

      for (int iOff = 0; iOff < g_tOpts.iSpareSize - 1; ++iOff)
        printVal(iCount, getMatrix(iByte, iOff), "\t");
      printVal(iCount, getMatrix(iByte, g_tOpts.iSpareSize - 1), "\n");
    }
  }

  csFree(&csLine);
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  FILE* hFile       = NULL;
  li    liOff       = 0;
  li    liFileSize  = 0;
  int   iSpareMax   = 0;
  int   iSpareCount = 0;

  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // Get all data from all files.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    hFile = openFile(g_tArgs.pStr[i].cStr, "rb");
//-- file ----------------------------------------------------------------------
    // Reset values for next file.
    liFileSize  = getFileSize(hFile);
    iSpareMax   = liFileSize / (g_tOpts.iPageSize + g_tOpts.iSpareSize);
    iSpareCount = 0;
    liOff       = g_tOpts.liOffset
                + ((g_tOpts.fPageFirst) ? g_tOpts.iPageSize : 0);
    while (!feof(hFile)) {
      goOffCalcNext(hFile, &liOff);
      if (!readSpareBytes(hFile)) break;
      accumulateSpareBytes();
      ++iSpareCount;
      fprintf(stderr, "\rFile '%s', Page %d of %d (%.2f%%)",
              g_tArgs.pStr[i].cStr,
              iSpareCount,
              iSpareMax,
              (float) iSpareCount / (float) iSpareMax * 100.0);
    }
//-- file ----------------------------------------------------------------------
    fclose(hFile);
    fprintf(stderr, "\n");
  }
  // Print analyze-table.
  printResultingTable(iSpareCount);

  // Free all used memory, prior end of program.
  dacsFree(&g_tArgs);
  free(g_tOpts.pucSpareData);
  free(g_tOpts.paiMatrix);

  return ERR_NOERR;
}
