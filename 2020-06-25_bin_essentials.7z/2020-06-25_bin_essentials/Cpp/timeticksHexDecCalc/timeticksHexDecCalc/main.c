/*******************************************************************************
 ** Name: timeticksHexDecCalc
 ** Purpose: What the programm should do.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 09.03.2020  JE    Created program from script 'timeticksHexDecCalc.pl'.
 ** 09.03.2020  JE    Deleted calcTicksdiff(), added invInt() for '-l'.
 ** 09.03.2020  JE    Changed '-t' from just integer to hex and integer.
 ** 10.03.2020  JE    Fixed error calculating ticks prior '-l'.
 ** 10.03.2020  JE    Changed output layout.
 ** 10.03.2020  JE    Updated logic for cli error checking.
 ** 11.03.2020  JE    Now dateime can also be set as 'YYYY/MM/DD'.
 ** 11.03.2020  JE    Updated usage text.
 ** 11.03.2020  JE    Added error check for use at least '-d' or '-t'.
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "timeticksHexDecCalc"
#define ME_VERSION "0.3.4"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"

// getOptions(): Defines empty values.
#define NO_TICK ((time_t) ~0)   // Fancy contruction to get a (-1). ;o)


//******************************************************************************
//* outsourced standard functions, includes and defines

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  cstr   csDateTimeStart;
  cstr   csDateTime;
  time_t tDateTimeStart;
  time_t tDateTime;
} t_options;


//******************************************************************************
//* Global variables

// Arguments
t_options g_tOpts; // CLI options and arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " -d <datetime> [-s <datetime>]\n"
  "       " ME_NAME " -t n [-l] [-s <datetime>]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Convert and calculate between datetime, ticks, hex and decimal.\n"
  " datetime can be given as 'YYYY/MM/DD, hh:mm:ss' or 'YYYY/MM/DD', where\n"
  " 'hh:mm:ss' will be set to '00:00:00'. n is given either as decimal\n"
  " (1221746602) or hex (0x48d25faa) number, where the input number will be\n"
  " interpreted as little-endian, if '-l' is set.\n"
  "  -d <datetime>: target datetime to calculate\n"
  "  -t n:          target ticks to calculate\n"
  "  -l:            interpret the number given wth '-t' as little-endian\n"
  "  -s <datetime>: set start of ticks (default '1970/01/01, 00:00:00')\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csOpt  = csNew("");
  int  iArg   = 1;  // Omit program name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Set defaults.
  g_tOpts.csDateTimeStart = csNew("1970/01/01, 00:00:00");
  g_tOpts.csDateTime      = csNew("");
  g_tOpts.tDateTimeStart  = NO_TICK;
  g_tOpts.tDateTime       = NO_TICK;
  int iLittleendian       = 0;

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'd') {
          if (! getArgStr(&g_tOpts.csDateTime, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Date time missing");
          continue;
        }
        if (cOpt == 't') {
          if (! getArgHexLong((ll*) &g_tOpts.tDateTime, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Ticks are missing");
          continue;
        }
        if (cOpt == 's') {
          if (! getArgStr(&g_tOpts.csDateTimeStart, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "Start date time missing");
          continue;
        }
        if (cOpt == 'l') {
          iLittleendian = 1;
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
  }

  // Sanity check of arguments and flags.
  if (g_tOpts.csDateTime.len == 0 && g_tOpts.tDateTime == NO_TICK)
    dispatchError(ERR_ARGS, "Use at least '-d' or '-t'");

  if (g_tOpts.csDateTime.len != 0 && g_tOpts.tDateTime != NO_TICK)
    dispatchError(ERR_ARGS, "Use either '-d' or '-t'");

  if (g_tOpts.csDateTimeStart.len == 0)
    dispatchError(ERR_ARGS, "You need a start date time to get a result!");

  if (iLittleendian && g_tOpts.tDateTime == NO_TICK)
    dispatchError(ERR_ARGS, "Use of '-l' only with '-t n'");

  if (g_tOpts.csDateTimeStart.len > 0 &&
      checkDateTime(&g_tOpts.csDateTimeStart) == DT_NONE)
    dispatchError(ERR_ARGS, "Start datetime malformed");

  if (g_tOpts.csDateTime.len > 0 &&
      checkDateTime(&g_tOpts.csDateTime) == DT_NONE)
    dispatchError(ERR_ARGS, "Datetime malformed");

  // If datetimes are set to 'YYYY/MM/DD', add 'hh:mm:ss'.
  if (g_tOpts.csDateTimeStart.len > 0 &&
      checkDateTime(&g_tOpts.csDateTimeStart) == DT_SHORT)
    csCat(&g_tOpts.csDateTimeStart, g_tOpts.csDateTimeStart.cStr, ", 00:00:00");

  if (g_tOpts.csDateTime.len > 0 &&
      checkDateTime(&g_tOpts.csDateTime) == DT_SHORT)
    csCat(&g_tOpts.csDateTime, g_tOpts.csDateTime.cStr, ", 00:00:00");

  //****************************************************************************
  //* Insert rest of vars, when '-s datetime', '-t ticks' or '-d datetime'
  //* is given at cli.

  // Invert ticks if '-t <ticks>' and '-l' was given at cli.
  if (iLittleendian && g_tOpts.tDateTime != NO_TICK) g_tOpts.tDateTime = revInt32(g_tOpts.tDateTime);
  // Set rest of vars.
  g_tOpts.tDateTimeStart = datetime2ticks(1, g_tOpts.csDateTimeStart.cStr, 0, 0, 0, 0, 0, 0);
  if (g_tOpts.csDateTime.len == 0)
    ticks2datetime(&g_tOpts.csDateTime, "", g_tOpts.tDateTime);
  else
    g_tOpts.tDateTime = datetime2ticks(1, g_tOpts.csDateTime.cStr, 0, 0, 0, 0, 0, 0);

  //****************************************************************************

  // Continue error checking, after all vars are set.
  if ((g_tOpts.tDateTime != NO_TICK) &&
      (g_tOpts.tDateTime < g_tOpts.tDateTimeStart))
    dispatchError(ERR_ARGS, "Start time is greater than given time");

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);

  return;
}

/*******************************************************************************
 * Name:  printResult
 * Purpose: Prints resulting list of variables.
 *******************************************************************************/
void printResult(uint32_t uiTicks) {
  uint32_t uiInvTicks = 0;

  uiInvTicks = revInt32(uiTicks);

  printf("+------------------------+----------------------+\n");
  printf("| Zero tick starts at    | %s |\n", g_tOpts.csDateTimeStart.cStr);
  printf("+------------------------+----------------------+\n");
  printf("| Given datetime         | %s |\n", g_tOpts.csDateTime.cStr);
  printf("+------------------------+----------------------+\n");
  printf("| Ticks decimal          | %-20u |\n", uiTicks);
  printf("+------------------------+----------------------+\n");
  printf("| Ticks hex bigendian    | 0x%08x           |\n", uiTicks);
  printf("+------------------------+----------------------+\n");
  printf("| Ticks hex littleendian | 0x%08x           |\n", uiInvTicks);
  printf("+------------------------+----------------------+\n");
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  initTimeFunctions();

  printResult(g_tOpts.tDateTime - g_tOpts.tDateTimeStart);

  return ERR_NOERR;
}
