/*******************************************************************************
 ** Name: getUsbId
 ** Purpose: What the programm should do.
 **
 ** Author: (CL) clyfe 'https://stackoverflow.com/questions/2432759/usb-drive-serial-number-under-linux-c'
 **         (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 04.08.2012  CL    Created code snippets.
 ** 11.01.2019  JE    Adapted code snippets into one prorgram.
 ** 23.04.2019  JE    Now use c_dynamic_arrays.h v0.3.3.
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <scsi/sg.h>
#include <scsi/scsi.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "getUsbId"
#define ME_VERSION "0.2.1"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ID    0x04
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ID   "ID error"
#define sERR_ELSE "Unknown error"

// isNumber()
#define NUM_NONE  0x00
#define NUM_INT   0x01
#define NUM_FLOAT 0x02

// getOptions(): Defines empty values.
#define NO_TICK ((time_t) ~0)   // Fancy contruction to get a (-1). ;o)


//******************************************************************************
//* outsourced standard functions, includes and defines

#include "../../libs/stdfcns.c"


//******************************************************************************
//* Global variables

// Arguments
t_array_cstr g_tArgs; // Free arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " dev1 [dev2 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Get the device IDs of all given SCSI devices like /dev/sdX.\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csOpt  = csNew("");
  int  iArg   = 1;  // Omit program name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount == 0)
    dispatchError(ERR_ARGS, "No file");

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);

  return;
}

/*******************************************************************************
 * Name:  getSataId
 * Purpuse: Retrieves the ID of given SATA devices.
 *******************************************************************************/
void getSataId(void) {
}

/*******************************************************************************
 * Name:  getUsbId
 * Purpuse: Retrieves the ID of given USB devices.
 *******************************************************************************/
int getUsbId(int fd, void *buf, size_t buf_len) {
  uchar            inq_cmd[] = {INQUIRY, 1, 0x80, 0, buf_len, 0};
  uchar            sense[32] = {0};;
  struct sg_io_hdr io_hdr    = {0};
  int              result    = 0;

  io_hdr.interface_id    = 'S';
  io_hdr.cmdp            = inq_cmd;
  io_hdr.cmd_len         = sizeof (inq_cmd);
  io_hdr.dxferp          = buf;
  io_hdr.dxfer_len       = buf_len;
  io_hdr.dxfer_direction = SG_DXFER_FROM_DEV;
  io_hdr.sbp             = sense;
  io_hdr.mx_sb_len       = sizeof (sense);
  io_hdr.timeout         = 5000;

  result = ioctl(fd, SG_IO, &io_hdr);

  if (result < 0)
    return result;

  if ((io_hdr.info & SG_INFO_OK_MASK) != SG_INFO_OK)
    return 1;

  return 0;
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  cstr csMsg        = csNew("");
  int  hFile        = 0;
  char scsi_sn[255] = {0};
  int  iRv          = 0;

  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // Get all IDs from all devices.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    if ((hFile = open(g_tArgs.pStr[i].cStr, O_RDONLY | O_NONBLOCK)) < 0) {
      csSetf(&csMsg, "Can't open '%s'", g_tArgs.pStr[i].cStr);
      dispatchError(ERR_FILE, csMsg.cStr);
    }
//-- device---------------------------------------------------------------------
    iRv = getUsbId(hFile, scsi_sn, 255);

    // scsi_serial[3] is the length of the serial number
    // scsi_serial[4] is serial number (raw, NOT null terminated)
    if (iRv < 0) {
      csSetf(&csMsg, "Returned %d, error code = %d\n", iRv, errno);
      dispatchError(ERR_ID, csMsg.cStr);
    }
    if (iRv == 1) {
      csSetf(&csMsg, "Returned %d, drive doesn't report serial number\n", iRv);
      dispatchError(ERR_ID, csMsg.cStr);
    }

    // Print result.
    if (!scsi_sn[3]) {
      csSetf(&csMsg, "Failed to retrieve serial for '%s'", g_tArgs.pStr[i].cStr);
      dispatchError(ERR_ID, csMsg.cStr);
    }
    printf("S/N '%s': %.*s\n",
           g_tArgs.pStr[i].cStr,
           (int) (size_t) scsi_sn[3],
           (char*) &scsi_sn[4]);
//-- device---------------------------------------------------------------------
    close(hFile);
  }

  // Free all used memory, prior end of program.
  dacsFree(&g_tArgs);

  return ERR_NOERR;
}
