#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <scsi/scsi.h>
#include <scsi/sg.h>
#include <sys/ioctl.h>

// we shall retrieve page 0x80 as per http://en.wikipedia.org/wiki/SCSI_Inquiry_Command
int scsi_get_serial(const char* dev, void *buf, size_t buf_len) {
  int           fd               = 0;
  unsigned char inq_cmd[]        = {INQUIRY, 1, 0x80, 0, buf_len, 0};
  unsigned char sense[32]        = {0};;
  struct        sg_io_hdr io_hdr = {0};
  int           result           = 0;

  fd = open(dev, O_RDONLY | O_NONBLOCK);
  if (fd < 0) perror(dev);

  io_hdr.interface_id    = 'S';
  io_hdr.cmdp            = inq_cmd;
  io_hdr.cmd_len         = sizeof (inq_cmd);
  io_hdr.dxferp          = buf;
  io_hdr.dxfer_len       = buf_len;
  io_hdr.dxfer_direction = SG_DXFER_FROM_DEV;
  io_hdr.sbp             = sense;
  io_hdr.mx_sb_len       = sizeof (sense);
  io_hdr.timeout         = 5000;
  
  result = ioctl(fd, SG_IO, &io_hdr);
  
  close(fd);

  if (result < 0)
    return result;
  
  if ((io_hdr.info & SG_INFO_OK_MASK) != SG_INFO_OK)
    return 1;
  
  return 0;
}


int main(int argc, char** argv) {
  char* dev              = "/dev/sda";
  char  scsi_serial[255] = {0};
  int   rc               = 0;
  
  rc = scsi_get_serial(dev, scsi_serial, 255);
  
  // scsi_serial[3] is the length of the serial number
  // scsi_serial[4] is serial number (raw, NOT null terminated)
  if (rc < 0)
    printf("FAIL, rc=%d, errno=%d\n", rc, errno);
  else if (rc == 1)
    printf("FAIL, rc=%d, drive doesn't report serial number\n", rc);
  else {
    if (!scsi_serial[3]) {
      printf("Failed to retrieve serial for %s\n", dev);
      return -1;
    }
    printf("Serial Number: %.*s\n", (size_t) scsi_serial[3], (char *) & scsi_serial[4]);
  }
  
  return (EXIT_SUCCESS);
}


//#include <stdlib.h>
//#include <stdio.h>
//#include <sys/ioctl.h>
//#include <linux/hdreg.h>
//#include <fcntl.h>
//#include <errno.h>
//#include <string.h>
//#include <cctype>
//#include <unistd.h>

//int main(){
//  struct hd_driveid* id = {0};
//  char*  dev            = "/dev/hda";
//  int    fd             = 0;
  
//  fd = open(dev, O_RDONLY|O_NONBLOCK);
  
//  if(fd < 0)
//    perror("cannot open");
  
//  if (ioctl(fd, HDIO_GET_IDENTITY, id) < 0) {
//    close(fd);
//    perror("ioctl error");
//  }
//  else {
//    // if we want to retrieve only for removable drives use this branching
//    if ((id->config & (1 << 7)) || (id->command_set_1 & 4)) {
//      close(fd);
//      printf("Serial Number: %s\n", id->serial_no);
//    }
//    else {
//      perror("support not removable");
//    }
//    close(fd);
//  }
//}

