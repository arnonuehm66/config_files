#!/usr/bin/perl
#*******************************************************************************
#** Name: make_qnx_modules_for_current_kernel.pl
#** Purpose:  Compile qnx6 and qnx4 modules for current running system kernel.
#** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
#*******************************************************************************
#** With a little help from my friends. ;o)
#** https://riptutorial.com/bash/example/13124/case-insensitive-matching
#** https://wiki.archlinux.org/index.php/Compile_kernel_module
#** https://unix.stackexchange.com/questions/46077/where-to-download-linux-kernel-source-code-of-a-specific-version
#*******************************************************************************
#** Date        User  Changelog
#**-----------------------------------------------------------------------------
#** 06.05.2020  JE    Created program.
#*******************************************************************************


#*******************************************************************************
#* pragmas

use 5.014;
use strict;


#*******************************************************************************
#* infos

my $g_meversion = '0.1.1';
my $g_mename    = getMeName();


#*******************************************************************************
#* constants

# usage()
use constant ERR_NOERR => 0x00;
use constant ERR_ARGS  => 0x01;
use constant ERR_FILE  => 0x02;
use constant ERR_ELSE  => 0xff;

use constant sERR_ARGS => 'Argument error';
use constant sERR_FILE => 'File error';
use constant sERR_ELSE => 'Unknown error';


#*******************************************************************************
#* global variables

# Global var container.
my %g_ = ();

# Regexes.
my $g_C  = '';
my %g_rx = ();

# Arguments
my %g_a    = ();
my @g_args = ();


#*******************************************************************************
#* functions

#*******************************************************************************
#* Name:  version
#* Purpose: Prints version of script and end it.
#*******************************************************************************
sub version() {
  print "$g_mename v$g_meversion\n";
  exit(ERR_NOERR);
}

#*******************************************************************************
#* Name:  getMeName
#* Purpose: Gets calling name of the script.
#*******************************************************************************
sub getMeName() {
  $0 =~ /([^\\\/]+)$/;
  return $1;
}

#*******************************************************************************
#* Name:  usage
#* Purpose: Prints usage of script and end it.
#*******************************************************************************
sub usage($;$) { my ($err, $txt) = @_;
  my $msg = '';

  # Ensure text ends appropriate, if printed.
  chomp($txt);
  $txt = "$txt\n\n" if defined $txt;

  #Summary:************************ 80 chars width ****************************************
  $msg .= "usage: $g_mename [-t] [-k] [-f] [-n]\n";
  $msg .= "       $g_mename [-h|--help|-v|--version]\n";
  $msg .= " Compile qnx6 and qnx4 modules for current running system kernel.\n";
  $msg .= " If '-fn' is used script will skip module check and compile them from the\n";
  $msg .= " current module-path of the kernel sources, check with '-t'.\n";
  $msg .= "  -t:            don't execute printed commands (default execute)\n";
  $msg .= "  -k:            get kernel sources from kernel.org (default Manjaro)\n";
  $msg .= "  -f:            force new download of source (default check module's presence)\n";
  $msg .= "  -n:            do not download source again\n";
  $msg .= "  -h|--help:     print this help\n";
  $msg .= "  -v|--version:  print version of program\n";
  #Summary:************************ 80 chars width ****************************************

  # Print to appropriate output channel.
  if ($err == ERR_NOERR) {
    print STDOUT "$txt$msg";
  }
  else {
    print STDERR "$txt$msg";
  }
  
  exit($err);
}

#*******************************************************************************
#* Name:  dispatchError
#* Purpose: Print out specific error message, if any occurres.
#*******************************************************************************
sub dispatchError(@) { my ($rv, $msg) = @_;
  my $txt = ($msg ne '') ? ": $msg" : '';
  
  usage(ERR_ARGS, sERR_ARGS . $txt) if $rv == ERR_ARGS;
  usage(ERR_FILE, sERR_FILE . $txt) if $rv == ERR_FILE;
  usage(ERR_ELSE, sERR_ELSE . $txt) if $rv == ERR_ELSE;
}

#*******************************************************************************
#* Name:  getOptions
#* Purpose: Filters command line.
#*******************************************************************************
sub getOptions(@) { my (@args) = @_;
  my $arg = '';
  my $opt = '';
  
  # Set arguments's defaults.
  $g_a{'testMode'}      = 0;
  $g_a{'kernel.org'}    = 0;
  $g_a{'forceDownload'} = 0;
  $g_a{'noDownload'}    = 0;
  
  # Rest of cli list.
  @g_args = ();
  
  # Loop all arguments from command line POSIX style.
argument:
  while (defined($arg = shift(@args))) {
  
    # Long options:
    if ($arg =~ /^--/) {
      if ($arg eq '--help') {
        usage(ERR_NOERR);
      }
      if ($arg eq '--version') {
        version();
      }
      dispatchError(ERR_ARGS, 'Invalid long option');
    }
  
    # Short options:
    if ($arg =~ /^-([^-].*)/) {
      $arg = $1;
      while ($arg =~ /(.)/g) {
        $opt = $1;
        if ($opt eq 'h') {
          usage(ERR_NOERR);
        }
        if ($opt eq 'v') {
          version();
        }
        if ($opt eq 't' ) {
          $g_a{'testMode'} = 1;
          next;
        }
        if ($opt eq 'k' ) {
          $g_a{'kernel.org'} = 1;
          next;
        }
        if ($opt eq 'f' ) {
          $g_a{'forceDownload'} = 1;
          next;
        }
        if ($opt eq 'n' ) {
          $g_a{'noDownload'} = 1;
          next;
        }
        dispatchError(ERR_ARGS, 'Invalid short option');
      }
      next argument;
    }

    # All else are treated as free arguments.
    push(@g_args, $arg);
  }
  
  # Sanity check of arguments and flags.
  dispatchError(ERR_ARGS, 'No files needed') if @g_args != 0;
}

#*******************************************************************************
#* Name:  cmd
#* Purpose: Prints what will be done and do it.
#*******************************************************************************
sub cmd($) { my ($cmd) = @_;
  print "$g_mename: [$cmd]\n";
  system("$cmd") if not $g_a{'testMode'};
}

#*******************************************************************************
#* Name:  cd
#* Purpose: Prints cd command and do it.
#*******************************************************************************
sub cd($) { my ($dir) = @_;
  print "$g_mename: [cd $dir]\n";
  chdir $dir if not $g_a{'testMode'};
}

#*******************************************************************************
#* Name:  printVars
#* Purpose: Prints vars for checking.
#*******************************************************************************
sub printVars() {
  print '-' x 80, "\n";
  print "Get ", ($g_a{'kernel.org'}) ? "kernel.org" : "Manjaro", " source\n";
  print "Modpath: $g_{'modpath'}\n";
  print "Kernel:  $g_{'uname'}\n";
  print "Extra:   $g_{'extra'}\n";
  print "Version: $g_{'version'}\n";
  print "VersDot: $g_{'versDot'}\n";
  print "Branch:  $g_{'branch'}\n";
  print '-' x 80, "\n";
}

#*******************************************************************************
#* Name:  initVars
#* Purpose: Prepare global variables from current kernel ('uname -r').
#*******************************************************************************
sub initVars($) { my ($uname) = @_;
  # Break down kernel version (e.g. '54', '5.4', '5.4.6' and '-2' from '5.4.6-2-MANJARO').
  $uname =~ / ([0-9]+) \. ([0-9]+) \. ([0-9]+) (-[0-9]+) /xo;
  
  $g_{'uname'}   = $uname;
  $g_{'version'} = "$1$2";
  $g_{'versDot'} = "$1.$2";
  $g_{'branch'}  = "v$1.$2.$3";
  $g_{'extra'}   = "$4";
    
  # Set path to modules
  if ($g_a{'kernel.org'}) {
    $g_{'modpath'} = "linux-stable";
  }
  else {
    $g_{'modpath'} = "linux$g_{'version'}/linux-$g_{'versDot'}";
  }
  
  printVars();
}

#*******************************************************************************
#* Name:  removeKernelDir
#* Purpose: Prepare new build.
#*******************************************************************************
sub removeKernelDir() {
  cmd("rm -rf linux-stable");
}

#*******************************************************************************
#* Name:  getKernelOrgStable
#* Purpose: Clones stable kernel from kernel.org and cd into source.
#*******************************************************************************
sub getKernelOrgStable() {
  cmd("git clone git://git.kernel.org/pub/scm/linux/kernel/git/stable/linux-stable.git --branch=$g_{'branch'}");
  cd("$g_{'modpath'}");
}

#*******************************************************************************
#* Name:  removeManjaroDir
#* Purpose: Prepare new build.
#*******************************************************************************
sub removeManjaroDir() {
  cmd("rm -rf linux$g_{'version'}");
}

#*******************************************************************************
#* Name:  getKernelManjaro
#* Purpose: Clones current kernel from Manjaro and cd into source.
#*******************************************************************************
sub getKernelManjaro() {
  cmd("git clone https://gitlab.manjaro.org/packages/core/linux$g_{'version'}.git");
  
  cd("linux$g_{'version'}");
  
  # Get the source-code for this kernel in the path.
  cmd("updpkgsums");
  
  # Decompress source in the path.
  cmd("tar xf linux-$g_{'versDot'}.tar.xz");
  
  cd("linux-$g_{'versDot'}");
}

#*******************************************************************************
#* Name:  getKernel
#* Purpose: Fetches kernel sources.
#*******************************************************************************
sub getKernel() {
  if ($g_a{'kernel.org'}) {
    removeKernelDir();
    getKernelOrgStable();
  }
  else {
    removeManjaroDir();
    getKernelManjaro();
  }
}

#*******************************************************************************
#* Name:  prepConfigs
#* Purpose: Prepares the config files for compilation.
#*******************************************************************************
sub prepConfigs() {
  cmd("make mrproper");
  cmd("cp /usr/lib/modules/$g_{'uname'}/build/.config ./");
  cmd("cp /usr/lib/modules/$g_{'uname'}/build/Module.symvers ./");
}

#*******************************************************************************
#* Name:  addQnxToConfig
#* Purpose: Adds QNX4 and QNX6 kernel modules to config.
#*******************************************************************************
sub addQnxToConfig() {
  cmd("perl -i -lpe 's/^.+(CONFIG_QNX4FS_FS).+\$/\$1=m/' .config");
  cmd("perl -i -lpe 's/^.+(CONFIG_QNX6FS_FS).+\$/\$1=m/' .config");
}

#*******************************************************************************
#* Name:  makeQnx
#* Purpose: Compiles modules for current kernel
#*******************************************************************************
sub makeQnx() {
  cmd("make EXTRAVERSION=$g_{'extra'} modules_prepare");
  cmd("make M=fs/qnx4");
  cmd("make M=fs/qnx6");
  cmd("xz fs/qnx4/qnx4.ko");
  cmd("xz fs/qnx6/qnx6.ko");
}

#*******************************************************************************
#* Name:  installQnx
#* Purpose: Copies module from kernel tree to installed.
#*******************************************************************************
sub installQnx() {
  cmd("sudo mkdir -p /usr/lib/modules/$g_{'uname'}/kernel/fs/qnx4");
  cmd("sudo mkdir -p /usr/lib/modules/$g_{'uname'}/kernel/fs/qnx6");
  cmd("sudo cp -f fs/qnx4/qnx4.ko.xz /usr/lib/modules/$g_{'uname'}/kernel/fs/qnx4/");
  cmd("sudo cp -f fs/qnx6/qnx6.ko.xz /usr/lib/modules/$g_{'uname'}/kernel/fs/qnx6/");
}

#*******************************************************************************
#* Name:  makeDepmod
#* Purpose: Makes modules available.
#*******************************************************************************
sub makeDepmod() {
  cmd("sudo depmod");
}


#*******************************************************************************
#* main

sub main() {
  my $uname = `uname -r`;
  
  chomp($uname);
  
  # Print apropriate error message, if necessary.
  getOptions(@ARGV);
  
  initVars($uname);

  if (-s "$g_{'modpath'}/fs/qnx4/qnx4.ko.xz" and
      -s "$g_{'modpath'}/fs/qnx6/qnx6.ko.xz" and
      not $g_a{'forceDownload'}) {
    print "Compiled modules found, just install.\n";
    cd("$g_{'modpath'}");
  }
  else {
    if ($g_a{'noDownload'}) {cd("$g_{'modpath'}")} else {getKernel()}
    prepConfigs();
    addQnxToConfig();
    makeQnx();
  }
  
  installQnx();
  makeDepmod();
  
  exit(ERR_NOERR);
}


#*******************************************************************************
#* start programm
main()
__END__
