/*******************************************************************************
 ** Name: data2TimeCoord
 ** Purpose: What the programm should do.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 18.06.2020  JE    Created program from script 'data2TimeCoord.pl'.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "../../libs/c_string.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "data2TimeCoord"
#define ME_VERSION "0.1.1"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_ELSE "Unknown error"

// processData()
#define STRING_DATA 0x00
#define BINARY_DATA 0x01
#define FROM_VAR    0x00
#define FROM_FILE   0x01

// utm2wgs()
#define iLON    0x01
#define iLAT    0x02
#define iRADIUS 6371000
#define dPI     3.14159265358979 // acos(-1) :o)


// getOptions(): Defines empty values.
#define NO_TICK (~((time_t) 0))   // Fancy contruction to get a (-1). ;o)


//******************************************************************************
//* outsourced standard functions, includes and defines

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// Arguments and options.
typedef struct s_options {
  int      fIsBigEndian;
  int32_t  i32Lon;
  int32_t  i32Lat;
  uint32_t u32Time;
} t_options;

typedef union u_f2i32 {
  float   fFloat;
  int32_t i32Int;
} t_f2i32;


//******************************************************************************
//* Global variables

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-b] [-o 'data'] [-a 'data'] [-t 'data']\n"
  "       " ME_NAME " [-b] ['data']\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Try to make sense (i.e. time date coordinates) of binary data at command line.\n"
  " Data can be decimal or hexadecimal with prefix '0x'.\n"
  " Hex:     4 byte short integer '0x7bff0205'.\n"
  " Decimal: 4 byte short integer '2080309765'.\n"
  " Every data not entered explicitly as longitue, latitude or timestamp is set to\n"
  " 0x00000000. If data is given without options, it s is used as longitude,\n"
  " latitude and timestamp simultaniously.\n"
  "  -b:            use data as big endian (default little endian)\n"
  "  -o 'data':     longitude data\n"
  "  -a 'data':     latitude data\n"
  "  -t 'data':     timestamp data\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_FILE);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csOpt  = csNew("");
  int  iArg   = 1;  // Omit program name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // For easier usage check.
  int fLon = 0;
  int fLat = 0;
  int fTme = 0;

  // Set defaults.
  g_tOpts.fIsBigEndian = 0;
  g_tOpts.i32Lon       = 0;
  g_tOpts.i32Lat       = 0;
  g_tOpts.u32Time     = 0;

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'b') {
          g_tOpts.fIsBigEndian = 1;
          continue;
        }
        if (cOpt == 'o') {
          if (! getArgHexLong((ll*) &g_tOpts.i32Lon, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "No longitude given");
          fLon = 1;
          continue;
        }
        if (cOpt == 'a') {
          if (! getArgHexLong((ll*) &g_tOpts.i32Lat, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "No latitude given");
          fLat = 1;
          continue;
        }
        if (cOpt == 't') {
          if (! getArgHexLong((ll*) &g_tOpts.u32Time, &iArg, argc, argv, ARG_CLI, NULL))
            dispatchError(ERR_ARGS, "No time given");
          fTme = 1;
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Fill all data fields with argument if nothing else is given.
  if (g_tArgs.sCount == 1 && fLon + fLat + fTme == 0) {
    if (! getArgHexLong((ll*) &g_tOpts.i32Lon,  NULL, 0, NULL, ARG_VALUE, g_tArgs.pStr[0].cStr))
      dispatchError(ERR_ARGS, "Can't convert hex/int argument");
    getArgHexLong((ll*) &g_tOpts.i32Lat,  NULL, 0, NULL, ARG_VALUE, g_tArgs.pStr[0].cStr);
    getArgHexLong((ll*) &g_tOpts.u32Time, NULL, 0, NULL, ARG_VALUE, g_tArgs.pStr[0].cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount >  1)
    dispatchError(ERR_ARGS, "Too many free arguments");
                                    ;
  if (g_tArgs.sCount == 1 && fLon + fLat + fTme > 0)
    dispatchError(ERR_ARGS, "Use either arguments or one value for lo, la and time");

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);

  return;
}

/*******************************************************************************
 * Name:  tomtom2wgs
 * Purpose: Converts an 4 byte binary string into an short integer, that into
 *          a TomTom coordinate. A number with 5 digits after decimal point.
 *******************************************************************************/
float tomtom2wgs(int32_t u32Coor) {
  return (float) u32Coor / 1e5;
}

/*******************************************************************************
 * Name:  utm2wgs
 * Purpose: Converts coordinates from Mercator (X, Y) into WGS84 (Lat, Long).
 *******************************************************************************/
float utm2wgs(int32_t u32Coor, int iType) {
  ldbl ldCoor = 0.0;

  if (iType == iLON)
    ldCoor = (ldbl) u32Coor / iRADIUS * 180.0 / dPI;
  if (iType == iLAT)
    ldCoor = 360.0 / dPI * atan(exp((ldbl) u32Coor / iRADIUS)) - 90.0;

  return (float) roundN(ldCoor, 6);
}

/*******************************************************************************
 * Name:  semi2wgs
 * Purpose: Converts coordinates from semicircles into WGS84 (Lat, Long).
 *******************************************************************************/
float semi2wgs(int32_t u32Coor, int iFac, int iPot) {
  ldbl ldCoor = (ldbl) u32Coor * (ldbl) iFac / pow(2.0, (ldbl) iPot);

  return (float) roundN(ldCoor, 6);
}

/*******************************************************************************
 * Name:  aisin2Wgs
 * Purpose: Converts coordinates from Aisin format into WGS84 (Lat, Long).
 *******************************************************************************/
float aisin2wgs(int32_t u32Coor) {
  ldbl ldCoor = (ldbl) u32Coor / 128.0 / 3600.0;

  return (float) roundN(ldCoor, 6);
}

////*******************************************************************************
////* Name:  vdo2wgs
////* Purpose: Converts coordinates from VDO style into WGS84 (Lat, Long).
////*******************************************************************************
float vdo2wgs(int32_t u32Coor, int iType) {
  ldbl ldCoor = 0.0;

  if (iType == iLON) {
    ldCoor = (ldbl) u32Coor * 180.0 / 1e9 - 30.0;
    if (ldCoor > 180.0) ldCoor = 360.0 -ldCoor;
  }
  if (iType == iLAT)
    ldCoor = (ldbl) u32Coor * 180.0 / 1e9;

  return (float) roundN(ldCoor, 6);
}

/*******************************************************************************
 * Name:  mtb2wgs
 * Purpose: Converts coordinates from Mitsubishi style into WGS84 (Lat, Long).
 *******************************************************************************/
float mtb2wgs(int32_t u32Coor) {
  ldbl ldCoor = (ldbl) u32Coor / 360.0 / 1e4;

  return (float) roundN(ldCoor, 6);
}

/*******************************************************************************
 * Name:  alpine2wgs
 * Purpose: Converts coordinates from Mitsubishi style into WGS84 (Lat, Long).
 *******************************************************************************/
float alpine2wgs(int32_t u32Coor) {
  ldbl ldCoor = (ldbl) u32Coor / 180.0 / 512.0 / 100.0;

  return (float) roundN(ldCoor, 6);
}

/*******************************************************************************
 * Name:  reverseIfBigendian
 * Purpose: Reverse byte order in lo, la and time if big endianess is wanted.
 *******************************************************************************/
void reverseIfBigendian(void) {
  if (g_tOpts.fIsBigEndian) return;

  g_tOpts.i32Lon  = (int32_t) revInt32((uint32_t) g_tOpts.i32Lon);
  g_tOpts.i32Lat  = (int32_t) revInt32((uint32_t) g_tOpts.i32Lat);
  g_tOpts.u32Time =           revInt32(           g_tOpts.u32Time);
}

/*******************************************************************************
 * Name:  printData
 * Purpose: .
 *******************************************************************************/
void printHeader(void) {
  if (g_tOpts.fIsBigEndian)
    printf("-------------------- BIG ENDIAN ------");
  else
    printf("-------------------- LITTLE ENDIAN ---");

  // Add 60 times '-'
  printf("------------------------------------------------------------\n");

  printf("---What-------\t---Longitude--\t----Latitude--\t------Timestamp-----\t----Remark----------------\n");
}

/*******************************************************************************
 * Name:  printDataXXX
 * Purpose: .
 *******************************************************************************/
void printDataHex(const char* pcRem, int32_t i32Lon, int32_t i32Lat, int32_t i32Time, const char* pcRem2) {
  cstr csLon  = csNew("");
  cstr csLat  = csNew("");
  cstr csTime = csNew("");

  csSetf(&csLon,  "0x%08x", i32Lon);
  csSetf(&csLat, " 0x%08x", i32Lat);
  csSetf(&csTime, "0x%08x", i32Time);

  printf("%-14s\t%14s\t%14s\t%20s\t%s\n", pcRem, csLon.cStr, csLat.cStr, csTime.cStr, pcRem2);

  csFree(&csLon);
  csFree(&csLat);
  csFree(&csTime);
}

//******************************************************************************
void printDataInt(const char* pcRem, int32_t i32Lon, int32_t i32Lat, int32_t i32Time, const char* pcRem2) {
  printf("%-14s\t%14i\t%14i\t%20i\t%s\n", pcRem, i32Lon, i32Lat, i32Time, pcRem2);
}

//******************************************************************************
void printDataFloat(const char* pcRem, int32_t i32Lon, int32_t i32Lat, uint32_t u32Time, const char* pcRem2) {
  t_f2i32 f2iLon  = {0};
  t_f2i32 f2iLat  = {0};

  // Watch out, floats are littelendian, too!
  f2iLon.i32Int  = (int32_t) revInt32((uint32_t) i32Lon);
  f2iLat.i32Int  = (int32_t) revInt32((uint32_t) i32Lat);
  u32Time = 0;

  printf("%-14s\t%14.7e\t%14.7e\t%20u\t%s\n", pcRem, f2iLon.fFloat, f2iLat.fFloat, u32Time, pcRem2);
}

//******************************************************************************
void printData(const char* pcRem, float fLon, float fLat, const char* pcTime, const char* pcRem2) {
  printf("%-14s\t%14.6f\t%14.6f\t%20s\t%s\n", pcRem, fLon, fLat, pcTime, pcRem2);
}

/*******************************************************************************
 * Name:  printData
 * Purpose: .
 *******************************************************************************/
void printConversions(void) {
  float fLon   = 0.0;
  float fLat   = 0.0;
  cstr  csTime = csNew("");

  // Standards:
  printDataHex("Hex, hex",       g_tOpts.i32Lon, g_tOpts.i32Lat, g_tOpts.u32Time, "Neutral hex");
  printDataInt("Int, int",       g_tOpts.i32Lon, g_tOpts.i32Lat, g_tOpts.u32Time, "Standard 32bit integer");
  printDataFloat("Float, float", g_tOpts.i32Lon, g_tOpts.i32Lat, g_tOpts.u32Time, "Standard 32bit float");

  // Conversions:

  fLon = tomtom2wgs(g_tOpts.i32Lon);
  fLat = tomtom2wgs(g_tOpts.i32Lat);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time);
  printData("TomTom, unix", fLon, fLat, csTime.cStr,
            "coord=INT/1e5");

  fLon = utm2wgs(g_tOpts.i32Lon, iLON);
  fLat = utm2wgs(g_tOpts.i32Lat, iLAT);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time);
  printData("Mercator, unix", fLon, fLat, csTime.cStr,
            "lon=INT/Rearth*180/pi; lat=360/pi*atan(e^(INT/Rearth))-90");

  // Set start to "12:00:00, 31.12.1989" instead "00:00:00, 01.01.1970".
  fLon    = semi2wgs(g_tOpts.i32Lon, 180, 31);
  fLat    = semi2wgs(g_tOpts.i32Lat,  90, 31);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time + 631108800);
  printData("Semicl, garmin", fLon, fLat, csTime.cStr,
            "lon=INT*180/2^31; lat=INT*90/2^31");

  // Set start to "12:00:00, 31.12.1989" instead "00:00:00, 01.01.1970".
  fLon    = semi2wgs(g_tOpts.i32Lon,  90, 31);
  fLat    = semi2wgs(g_tOpts.i32Lat, 180, 31);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time + 631108800);
  printData("Semicl, garmin", fLon, fLat, csTime.cStr,
            "lon=INT*90/2^31; lat=INT*180/2^31");

  // Set start to "00:00:00, 31.12.1989" instead "00:00:00, 01.01.1970".
  fLon    = semi2wgs(g_tOpts.i32Lon, 180, 30);
  fLat    = semi2wgs(g_tOpts.i32Lat,  90, 30);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time + 631065600);
  printData("Semicl, nuvi 2", fLon, fLat, csTime.cStr,
            "lon=INT*180/2^30; lat=INT*90/2^30");

  // Set start to "00:00:00, 31.12.1989" instead "00:00:00, 01.01.1970".
  fLon    = semi2wgs(g_tOpts.i32Lon,  90, 30);
  fLat    = semi2wgs(g_tOpts.i32Lat, 180, 30);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time + 631065600);
  printData("Semicl, nuvi 2", fLon, fLat, csTime.cStr,
            "lon=INT*90/2^30; lat=INT*180/2^30");

  fLon    = semi2wgs(g_tOpts.i32Lon, 180, 23);
  fLat    = semi2wgs(g_tOpts.i32Lat, 180, 23);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time);
  printData("iGo8, unix", fLon, fLat, csTime.cStr,
            "coord=INT*180/2^23");

  fLon    = semi2wgs(g_tOpts.i32Lon, 1, 23);
  fLat    = semi2wgs(g_tOpts.i32Lat, 1, 23);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time);
  printData("iGo8 trk, unix", fLon, fLat, csTime.cStr,
            "coord=INT/2^23");

  fLon    = aisin2wgs(g_tOpts.i32Lon);
  fLat    = aisin2wgs(g_tOpts.i32Lat);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time);
  printData("Aisin, unix", fLon, fLat, csTime.cStr,
            "coord=INT/128/3600");

  fLon    = vdo2wgs(g_tOpts.i32Lon, iLON);
  fLat    = vdo2wgs(g_tOpts.i32Lat, iLAT);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time);
  printData("VDO, unix", fLon, fLat, csTime.cStr,
            "lon=INT*180/1e9-30 (if(lon>180)lon=360-lon); lat=INT*180/1e9");

  fLon    = mtb2wgs(g_tOpts.i32Lon);
  fLat    = mtb2wgs(g_tOpts.i32Lat);
  ticks2datetime(&csTime, "", (time_t) g_tOpts.u32Time);
  printData("Mitsub., unix", fLon, fLat, csTime.cStr,
            "coord=INT/360/1e4");

  fLon    = alpine2wgs(g_tOpts.i32Lon);
  fLat    = alpine2wgs(g_tOpts.i32Lat);
  printData("Alpine, -", fLon, fLat, "-",
            "coord=INT/180/512/100");

  printf("--------------\t--------------\t--------------\t--------------------\t"
         "--------------------------\n");

  csFree(&csTime);
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  initTimeFunctions();

  reverseIfBigendian();
  printHeader();
  printConversions();

  // Free all used memory, prior end of program.
  dacsFree(&g_tArgs);

  return ERR_NOERR;
}
