#ifndef WINMAIN_H
#define WINMAIN_H

#include <QDialog>

namespace Ui {
  class winMain;
}

class winMain : public QDialog
{
  Q_OBJECT

public:
  explicit winMain(QWidget *parent = nullptr);
  ~winMain();

private:
  Ui::winMain *ui;
};

#endif // WINMAIN_H
