/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License v2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 021110-1307, USA.
 */

typedef unsigned int __u32;
//typedef long unsigned int __u64;

#include <linux/mmc/ioctl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>

#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <libgen.h>
#include <limits.h>
#include <ctype.h>


#define CHECK(expr, msg, err_stmt) { if (expr) { fprintf(stderr, msg); err_stmt; } }
#define _GNU_SOURCE  //getline
#define MMC_BLOCK_MAJOR         179
/* From kernel linux/mmc/core.h */
#define MMC_RSP_PRESENT (1 << 0)
#define MMC_RSP_136     (1 << 1)                /* 136 bit response */
#define MMC_RSP_CRC     (1 << 2)                /* expect valid crc */
#define MMC_RSP_BUSY    (1 << 3)                /* card may send busy */
#define MMC_RSP_OPCODE  (1 << 4)                /* response contains opcode */

#define MMC_CMD_AC      (0 << 5)
#define MMC_CMD_ADTC    (1 << 5)

#define MMC_RSP_SPI_S1  (1 << 7)                /* one status byte */
#define MMC_RSP_SPI_BUSY (1 << 10)              /* card may send busy */

#define MMC_RSP_SPI_R1  (MMC_RSP_SPI_S1)
#define MMC_RSP_SPI_R1B (MMC_RSP_SPI_S1|MMC_RSP_SPI_BUSY)

#define MMC_RSP_R1      (MMC_RSP_PRESENT|MMC_RSP_CRC|MMC_RSP_OPCODE)
#define MMC_RSP_R1B     (MMC_RSP_PRESENT|MMC_RSP_CRC|MMC_RSP_OPCODE|MMC_RSP_BUSY)

int send_status(int fd, unsigned int *response)
{
        int ret = 0;
        struct mmc_ioc_cmd idata;


        memset(&idata, 0, sizeof(idata));
        idata.opcode = 13;// MMC_SEND_STATUS;
        idata.arg = (1 << 16);
        idata.flags = MMC_RSP_R1 | MMC_CMD_AC;
        //idata.data_timeout_ns=1000000;
        ret = ioctl(fd, MMC_IOC_CMD, &idata);
        if (ret)
                perror("ioctl");

        *response = idata.response[0];

        return ret;
}


int set_blocklen(int fd, int len)
{
	int ret;
	struct mmc_ioc_cmd idata;
        memset(&idata, 0, sizeof(idata));
        //set blocklen 
        idata.write_flag = 1;
        idata.opcode = 16;//BlocklenCMD
        idata.arg = len;
        idata.flags = MMC_RSP_SPI_R1B | MMC_RSP_R1B |MMC_CMD_AC;
        ret = ioctl(fd, MMC_IOC_CMD, &idata);   //set blocklen
        if (ret)
        {
                //perror("ioctl");
                printf("\nset_blocklen Result:%d Occured\n",ret);
        }
	return(ret);
}



int hex2data(unsigned char *data, const unsigned char *hexstring)
{
	char *endptr;
	size_t hexcount = 0;	//in
	size_t bincount = 0;	//out

	do
	{
		if(hexstring[hexcount] == '\0'|| hexstring[hexcount] == '\r'||hexstring[hexcount] == '\n')	return(bincount);
		if(hexstring[hexcount] == ' ')	hexcount++;
		else
		{
			if(hexstring[hexcount+1] == '\0'|| hexstring[hexcount+1] == '\r'||hexstring[hexcount+1] == '\n')      return(bincount);
			char buf[5] = {'0', 'x', hexstring[hexcount], hexstring[hexcount+1], 0};
			data[bincount++] = strtol(buf, &endptr, 0);
			hexcount+=2;
		}
	}while(1);
		/*
		len=strlen((char*)hexstring);
		for(count = 0; count < len; count++) {
		char buf[5] = {'0', 'x', pos[0], pos[1], 0};
		data[count] = strtol(buf, &endptr, 0);
		pos += 2 * sizeof(char);

		if (endptr[0] != '\0') {
			//non-hexadecimal character encountered
			return -1;
		}

	}
*/
	return bincount;
}

int main(int nargs, char **argv)
{
	FILE *pwlist=NULL;
	int fd, ret, pwlen, flag,i;
	char *device;
	unsigned char buffer[20];
	unsigned char * line = (unsigned char*) malloc(100);	//max line
	unsigned char * binline = (unsigned char*) malloc(100);	//max bytes hex
	size_t len=0;
	ssize_t read;
	
	printf("mmc_password_remover v0.0.1 Copyright 2014 BKA, Gerhard Wagner, KT52@bka.bund.de - Law enforcement only!\n\n");

	CHECK(nargs != 4, "Usage: mmc_password_remover 0(unlock)|2(remove) pwlistfile /dev/mmcblk0\n", exit(1));

	flag = strtol(argv[1], NULL, 10);
	if((flag!=2)&&(flag!=0))
	{
		printf("Bad FLAG! - Only 0 to unlock or 2 to remove the password is allowed!\n");
		return(-1);
	}

	if((pwlist=fopen(argv[2],"r"))==NULL)
	{
		perror("open passwordlistfile");
		exit(1);
	}
	device = argv[3];

	fd = open(device, O_RDWR);
	if (fd < 0) {
		perror("ROOT needed! - open");
		exit(1);
	}

	while((read=getline((char**)&line, &len, pwlist))!=-1)
	{
		pwlen=hex2data(binline, line);
		for(i=0;i<pwlen;i++)   buffer[2+i]=binline[i]; 
		buffer[0]=0;//flag;
		buffer[1]=pwlen;
		//password cmd
		struct mmc_ioc_cmd idata;
		memset(&idata, 0, sizeof(idata));
		idata.write_flag = 1;   //1 write
		idata.opcode = 42;//MMC_PW
		idata.arg = 0;
		//idata.flags =  MMC_RSP_SPI_R1B | MMC_RSP_R1B |MMC_CMD_AC;
		idata.flags =  MMC_RSP_SPI_R1 | MMC_RSP_R1 |MMC_CMD_AC;
		
		idata.blksz =  pwlen+2;
		idata.blocks = 1;
		mmc_ioc_cmd_set_data(idata, buffer);
		printf("\ntrying: ");
		for(i=2;i<idata.blksz;i++)  printf("%2.2X ",buffer[i]);
		set_blocklen(fd, idata.blksz); //set blocklen!  
		ret = ioctl(fd, MMC_IOC_CMD, &idata);
		if (ret)
		{
			printf("\ncmd42 Result:%d Occured\n",ret);
		}
		
		unsigned int response;
		ret = send_status(fd, &response);
		if (ret) 
		{
			fprintf(stderr, "Could not read response to SEND_STATUS from %s\n", device);
			exit(1);
		}

		//printf("SEND_STATUS response: 0x%08x\n", response);
		if((response & 0x02000000)==0x00)	
		{	
        printf("Password found! :)\n");
        if(flag==2)	//remove password
        {
            buffer[0]=2;
            ret = ioctl(fd, MMC_IOC_CMD, &idata);
            if (ret)
            {
                fprintf(stderr, "Could not read response to SEND_STATUS from %s\n", device);
                exit(1);
            }
            else printf("Password removed ;)\n");
        }
        else printf("Card temporarily unlocked ;)\n");
        set_blocklen(fd, 512);  //set blocklen back to 512!
        return(1);
		}
	}

	set_blocklen(fd, 512);  //set blocklen back to 512!

	return(-1);
}
