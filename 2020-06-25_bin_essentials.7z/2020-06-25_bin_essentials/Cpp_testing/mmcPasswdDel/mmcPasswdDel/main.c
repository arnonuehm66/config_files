/*******************************************************************************
 ** Name: mmcPasswdDel
 ** Purpose: Set, unset, lock and unlock sd-cards via '/dev/mmcblkX' node.
 ** Author: (JW) Gerhard Wagner <kt52@bka.bund.de>
 **         (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 01.01.2014  JW    Created program.
 ** 20.02.2018  JE    Modified to fit 'skeleton_main.c' v0.0.5.
 *******************************************************************************
 * Licence
 *------------------------------------------------------------------------------
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License v2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 021110-1307, USA.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <sys/ioctl.h>
//#include <dirent.h>
//#include <unistd.h>
//#include <libgen.h>
//#include <limits.h>
//#include <ctype.h>
//#include <sys/stat.h>
//#include <sys/types.h>

#include <linux/mmc/ioctl.h>

#include "c_string.h"
#include "c_dynamic_arrays.h"
//#include "../../libs/c_string.h"
//#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "mmcPasswdDel"
#define ME_VERSION "0.2.1"

#define ERR_NOERR  0x00
#define ERR_ARGS   0x01
#define ERR_FILE   0x02
#define ERR_IOCTL  0x04
#define ERR_DEVICE 0x08
#define ERR_PASSWD 0x10
#define ERR_ELSE   0xff

#define sERR_ARGS   "Argument error"
#define sERR_FILE   "File error"
#define sERR_IOCTL  "ioctl error"
#define sERR_DEVICE "Device error"
#define sERR_PASSWD "Password error"
#define sERR_ELSE   "Unknown error"

// isNumber()
#define NUM_NONE  0x00
#define NUM_INT   0x01
#define NUM_FLOAT 0x02

// Original from 'c_password_remover.c'.
#define _GNU_SOURCE      //getline
#define MMC_BLOCK_MAJOR  179

/* From kernel linux/mmc/core.h */
#define MMC_RSP_PRESENT  (1 << 0)
#define MMC_RSP_136      (1 << 1)                /* 136 bit response */
#define MMC_RSP_CRC      (1 << 2)                /* expect valid crc */
#define MMC_RSP_BUSY     (1 << 3)                /* card may send busy */
#define MMC_RSP_OPCODE   (1 << 4)                /* response contains opcode */

#define MMC_CMD_AC       (0 << 5)
#define MMC_CMD_ADTC     (1 << 5)

#define MMC_RSP_SPI_S1   (1 << 7)                /* one status byte */
#define MMC_RSP_SPI_BUSY (1 << 10)              /* card may send busy */

#define MMC_RSP_SPI_R1   (MMC_RSP_SPI_S1)
#define MMC_RSP_SPI_R1B  (MMC_RSP_SPI_S1|MMC_RSP_SPI_BUSY)

#define MMC_RSP_R1       (MMC_RSP_PRESENT|MMC_RSP_CRC|MMC_RSP_OPCODE)
#define MMC_RSP_R1B      (MMC_RSP_PRESENT|MMC_RSP_CRC|MMC_RSP_OPCODE|MMC_RSP_BUSY)


//******************************************************************************
//* typedefs

// Original from 'c_password_remover.c'.
//typedef unsigned int __u32;
//typedef long unsigned int __u64;

// For convienience.
typedef unsigned int  uint;
typedef unsigned char uchar;
typedef long double   ldbl;

// From 'linux/mmc/ioctl.h'
typedef struct mmc_ioc_cmd t_mmcCmd;

// Arguments and options.
typedef struct {
  cstr csDevice;
  int  iSetPasswd;
  int  iDelPasswd;
  int  iUnlockDevice;
  int  iPassIsChar;
  cstr csPassword;
  cstr csPassFile;
} t_options;


//******************************************************************************
//* Global variables

// Arguments
t_options    g_tOpts;     // CLI options and arguments.
t_array_cstr g_tArgs;     // Free arguments.
t_array_cstr g_tPswdHex;  // Passwords from file.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  version
 * Purpose: Print version and exit program.
 *******************************************************************************/
void version(void) {
  cstr csOut = csNew(ME_NAME);

  csCat(&csOut, csOut.cStr, " v" ME_VERSION);
  printf("%s\n", csOut.cStr);

  csFree(&csOut);

  exit(ERR_NOERR);
}

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-d <device>] -s|-d|-u [-c] -p <passwd>|-f <passwdfile>\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Unlock MMC devices or delete or set passwords on them via '/dev/mmcblkX' node.\n"
  "  -d <device>:   device node (default 'dev'mmcblk0')\n"
  "  -s:            set password <passwd>\n"
  "  -d:            delete password <passwd> permanently \n"
  "  -u:            unlock device temporarily with <passwd>\n"
  "  -c:            passwords consists of ASCII chars (default hex chars)\n"
  "  -p <passwd>:   use password <passwd>\n"
  "  -f <file>:     use a list of passwords from file\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
  //|************************ 80 chars width ****************************************|
          );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS)   csCat(&csErr, csErr.cStr, sERR_ARGS);
  if (rv == ERR_FILE)   csCat(&csErr, csErr.cStr, sERR_FILE);
  if (rv == ERR_IOCTL)  csCat(&csErr, csErr.cStr, sERR_IOCTL);
  if (rv == ERR_DEVICE) csCat(&csErr, csErr.cStr, sERR_DEVICE);
  if (rv == ERR_PASSWD) csCat(&csErr, csErr.cStr, sERR_PASSWD);
  if (rv == ERR_ELSE)   csCat(&csErr, csErr.cStr, sERR_ELSE);

  // Add ': ', if a message was given.
  if (csMsg.len != 0) {
    csCat(&csErr, csErr.cStr, ": ");
    csCat(&csErr, csErr.cStr, csMsg.cStr);
  }

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  shift
 * Purpose: Shifts one argument from CLI.
 *******************************************************************************/
cstr shift(int argc, char* argv[], int* pI) {
  cstr csRv = csNew("");

  if (*pI < argc)
    csSet(&csRv, argv[*pI]);

  // Save way to increment the value of the pointed var.
  *pI += 1;

  // No csFree() necessary, because data pointer is copied.
  return csRv;
}

/*******************************************************************************
 * Name:  isNumber
 * Purpose: Check if string is a int or float number.
 *******************************************************************************/
int isNumber(cstr sString, int* piSign) {
  int iDecPt = 0;

  // Assume no sign.
  *piSign = 0;

  // Check for plus or minus sign in front of number.
  if (sString.cStr[0] == '-')
    *piSign = -1;

  if (sString.cStr[0] == '+')
    *piSign = 1;

  // Continuation depends wether sign was found.
  // Check for digits and decimal point.
  for (int i = (*piSign != 0) ? 1 : 0; i < sString.len; ++i) {
    if (sString.cStr[i] == '.') {
      // Only one decimal point allowed!
      if (iDecPt)
        return NUM_NONE;
      else {
        iDecPt = 1;
        continue;
      }
    }

    // Not a digit, no number.
    if (sString.cStr[i] < '0' || sString.cStr[i] > '9')
      return NUM_NONE;
  }

  if (iDecPt)
    return NUM_FLOAT;

  return NUM_INT;
}

/*******************************************************************************
 * Name:  readPasswordsFromFile
 * Purpose: Reads passwords from file into dynamic array.
 *******************************************************************************/
void readPasswordsFromFile(void) {
  FILE*   hFile   = NULL;
  size_t  stLen   = 0;
  ssize_t sstRead = 0;
  char*   pcline  = (char*) malloc(100);

  if (!(hFile = fopen(g_tOpts.csPassFile.cStr, "rb"))) {
    cstr csMsg = csNew("Can't open '");
    csCat(&csMsg, csMsg.cStr, g_tOpts.csPassFile.cStr);
    csCat(&csMsg, csMsg.cStr, "'");
    dispatchError(ERR_FILE, csMsg.cStr);
  }

  // Read all lines into the dynamic array.
  while ((sstRead = getline(&pcline, &stLen, hFile)) != -1)
    dacsAdd(&g_tPswdHex, pcline);

  fclose(hFile);
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  int  iArg   = 1;  // Omit programm name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Set defaults.
  g_tOpts.csDevice      = csNew("/dev/mmcblk0");
  g_tOpts.iDelPasswd    = 0;
  g_tOpts.iUnlockDevice = 0;
  g_tOpts.iPassIsChar   = 0;
  g_tOpts.csPassword    = csNew("");
  g_tOpts.csPassFile    = csNew("");

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);
  dacsInit(&g_tPswdHex);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    csArgv = shift(argc, argv, &iArg);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'd') {
          csRv = shift(argc, argv, &iArg);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "Device node is missing");
          csSet(&g_tOpts.csDevice, csRv.cStr);
          continue;
        }
        if (cOpt == 's') {
          g_tOpts.iSetPasswd    = 1;
          g_tOpts.iDelPasswd    = 0;
          g_tOpts.iUnlockDevice = 0;
          continue;
        }
        if (cOpt == 'd') {
          g_tOpts.iSetPasswd    = 0;
          g_tOpts.iDelPasswd    = 1;
          g_tOpts.iUnlockDevice = 0;
          continue;
        }
        if (cOpt == 'u') {
          g_tOpts.iSetPasswd    = 0;
          g_tOpts.iDelPasswd    = 0;
          g_tOpts.iUnlockDevice = 1;
          continue;
        }
        if (cOpt == 'c') {
          g_tOpts.iPassIsChar = 1;
          continue;
        }
        if (cOpt == 'p') {
          csRv = shift(argc, argv, &iArg);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "No password given");
          csSet(&g_tOpts.csPassword, csRv.cStr);
          continue;
        }
        if (cOpt == 'f') {
          csRv = shift(argc, argv, &iArg);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "No password file given");
          csSet(&g_tOpts.csPassFile, csRv.cStr);
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.iCount != 0)
    dispatchError(ERR_ARGS, "No free argument necessary");

  if (g_tOpts.csPassword.len == 0 && g_tOpts.csPassFile.len == 0)
    dispatchError(ERR_ARGS, "No password and password file");

  if (g_tOpts.csPassword.len > 0)
    dacsAdd(&g_tPswdHex, g_tOpts.csPassword.cStr);

  if (g_tOpts.csPassFile.len > 0)
    readPasswordsFromFile();

  csFree(&csArgv);
  csFree(&csRv);

  return;
}

/*******************************************************************************
 * Name:  send_status
 * Purpose: .
 *******************************************************************************/
int send_status(int hDevice, unsigned int* puiResponse) {
  int      iRv    = 0;
  t_mmcCmd mmcCmd = {0};

  // => = {0};
  //memset(&mmcCmd, 0, sizeof(mmcCmd));

  mmcCmd.opcode          = 13;           // MMC_SEND_STATUS;
  mmcCmd.arg             = (1 << 16);
  mmcCmd.flags           = MMC_RSP_R1 | MMC_CMD_AC;
//  mmcCmd.data_timeout_ns = 1000000;

  iRv = ioctl(hDevice, MMC_IOC_CMD, &mmcCmd);

  if (iRv)
    dispatchError(ERR_IOCTL, "Status");

  *puiResponse = mmcCmd.response[0];

  return iRv;
}

/*******************************************************************************
 * Name:  set_blocklen
 * Purpose: .
 *******************************************************************************/
int set_blocklen(int hDevice, int iLen) {
  int      iRv    = 0;
  t_mmcCmd mmcCmd = {0};

  // => = {0};
  //memset(&mmcCmd, 0, sizeof(mmcCmd));

  //set blocklen
  mmcCmd.write_flag = 1;
  mmcCmd.opcode     = 16;   // BlocklenCMD
  mmcCmd.arg        = iLen;
  mmcCmd.flags      = MMC_RSP_SPI_R1B | MMC_RSP_R1B |MMC_CMD_AC;

  // Set blocklen.
  iRv = ioctl(hDevice, MMC_IOC_CMD, &mmcCmd);

  if (iRv) {
    char cBuff[48] = {0};
    sprintf(cBuff, "Set blocklen: Result %d occured", iRv);
    dispatchError(ERR_IOCTL, cBuff);
  }

  return(iRv);
}

///*******************************************************************************
// * Name:  unlock_device
// * Purpose: .
// *******************************************************************************/
//int unlock_device(int hDevice, unsigned int* puiResponse) {
//  int      iRv    = 0;
//  t_mmcCmd mmcCmd = {0};

//  mmcCmd.arg              = 0;
//  mmcCmd.blksz            = 0;
//  mmcCmd.blocks           = 0;
//  mmcCmd.cmd_timeout_ms   = 0;
//  mmcCmd.data_ptr         = 0;
//  mmcCmd.data_timeout_ns  = 0;
//  mmcCmd.flags            = 0;
//  mmcCmd.is_acmd          = 0;
//  mmcCmd.opcode           = 0;
//  mmcCmd.postsleep_max_us = 0;
//  mmcCmd.postsleep_min_us = 0;
//  mmcCmd.response[0]      = 0;
//  mmcCmd.response[1]      = 0;
//  mmcCmd.response[2]      = 0;
//  mmcCmd.response[3]      = 0;
//  mmcCmd.write_flag       = 0;

//  // Issue command to mmc controller ...
//  iRv = ioctl(hDevice, MMC_IOC_CMD, &mmcCmd);

//  // ... and process errors.
//  if (iRv)
//    dispatchError(ERR_IOCTL, "Status");

//  *puiResponse = mmcCmd.response[0];

//  return iRv;
//}

/*******************************************************************************
 * Name:  hexChars2bytes
 * Purpose: .
 *******************************************************************************/
void hexChars2bytes(cstr* pcsByte, cstr* pcsHex) {
  cstr   csZero    = csNew("0");
  cstr   csLeft    = csNew("");
  cstr   csRight   = csNew("");
  cstr   csErr     = csNew("");
  char*  pcEnd     = NULL;
  size_t hexCount  = 0;  //in
  size_t byteCount = 0;  //out
  char   cBuff[5]  = {0};
  char   cChar     = 0;
  int    iIsHex    = 1;
  int    iPos      = 0;

  // If hex starts with '0x' delete it.
  if (pcsHex->cStr[0] == '0' && pcsHex->cStr[1] == 'x')
    csMid(pcsHex, pcsHex->cStr, 2, -1);

  // If hex ends with \n and/or \r delete it/them.
  while (pcsHex->cStr[pcsHex->len - 1] == '\r' ||
         pcsHex->cStr[pcsHex->len - 1] == '\n')
    csMid(pcsHex, pcsHex->cStr, 0, pcsHex->len - 2);

  // If hex contains spaces delete them.
  while ((iPos = csInStr(pcsHex->cStr, " ")) != -1) {
    csSplit(&csLeft, &csRight, pcsHex->cStr, " ");
    csSet(pcsHex, csLeft.cStr);
    csCat(pcsHex, pcsHex->cStr, csRight.cStr);
  }

  // Check if rest of string consists only of 0-9, a-f and A-F.
  for (int i = 0; i < pcsHex->len; ++i) {
    cChar = (uchar) pcsHex->cStr[i];
    if ((cChar < '0' || cChar > '9') &&
        (cChar < 'a' || cChar > 'f') &&
        (cChar < 'A' || cChar > 'F'))
      iIsHex = 0;
  }

  if (!iIsHex) {  // Should this be an error or just awarning?!
    csSet(&csErr, "Line '");
    csCat(&csErr, csErr.cStr, pcsHex->cStr);
    csCat(&csErr, csErr.cStr, "' seems to be not all in hex");
    dispatchError(ERR_PASSWD, csErr.cStr);
  }

  // Add a leading zero if nibble count is odd.
  if (pcsHex->len % 2 == 1)
    csCat(pcsHex, csZero.cStr, pcsHex->cStr);

//********* XXX ****************************************************************
//printf("%s\n", pcsHex->cStr); exit(1);
//********* XXX ****************************************************************

  for (hexCount = 0; hexCount < pcsHex->len - 1; hexCount += 2) {
    // Make it a isolated hex string like "0xff" ...
    sprintf(cBuff, "0x%c%c", pcsHex->cStr[hexCount], pcsHex->cStr[hexCount + 1]);
    // ...  and convert it to a long integer.
    pcsByte->cStr[byteCount++] = (char) strtol(cBuff, &pcEnd, 0);
  }
  pcsByte->len = byteCount;

  // Don't forget to clear used memory.
  csFree(&csZero);
  csFree(&csLeft);
  csFree(&csRight);
  csFree(&csErr);
}

/*******************************************************************************
 * Name:  unlockDeviceDelPassword
 * Purpose: Unlocks device temporarily or deletes password permanently.
 *******************************************************************************/
void unlockDeviceDelPassword(int hDevice, cstr* pcsPasswd, int iDelPasswd) {
  uint     uiResponse  = 0;
  int      iRv         = 0;
  char     cPasswd[20] = {0};
  t_mmcCmd mmcCmd      = {0};
  cstr     csErr       = csNew("");

  // Fill buffer with command flag, password length and password itself.
  cPasswd[0] = 0;                         // Command unlock.
  cPasswd[1] = pcsPasswd->len;            // Length of following password.
  for (int i = 0; i < pcsPasswd->len; ++i)
    cPasswd[2 + i] = pcsPasswd->cStr[i];  // Bytes of password.

  // Assemble the password command
  // mmcCmd = (t_mmcCmd) {0};   // == memset(&mmcCmd, 0, sizeof(mmcCmd))
  mmcCmd.write_flag = 1;
  mmcCmd.opcode     = 42;   // CMD42: LOCK_UNLOCK
  mmcCmd.arg        = 0;
  mmcCmd.flags      = MMC_RSP_SPI_R1 | MMC_RSP_R1 | MMC_CMD_AC;
  mmcCmd.blksz      = pcsPasswd->len + 2;
  mmcCmd.blocks     = 1;

  // Issue password and unlock command to mmc.
  mmc_ioc_cmd_set_data(mmcCmd, cPasswd);

  // Feedback for user.
  printf("trying: '0x");
  for (int i = 2; i < mmcCmd.blksz; ++i)
    printf(" %2.2X",cPasswd[i]);
  printf("'\n");

  // Set block length an check return value for errors.
  set_blocklen(hDevice, mmcCmd.blksz);

  if ((iRv = ioctl(hDevice, MMC_IOC_CMD, &mmcCmd)))
    printf("CMD42 %d while unlocking device\n", iRv);

  if (send_status(hDevice, &uiResponse)) {
    csSet(&csErr, "Could not read response of 'send_status' from '");
    csCat(&csErr, csErr.cStr, g_tOpts.csDevice.cStr);
    csCat(&csErr, csErr.cStr, "'\n");
    dispatchError(ERR_DEVICE, csErr.cStr);
  }

  // Wrong password.
  if ((uiResponse & 0x02000000) == 0x00)
    goto unlockDeviceDelPassword_clean_exit;

  printf("Password found:\n");

  if (iDelPasswd) {

    // Issue command again with the delete flag set.
    cPasswd[0] = 2;
    if ((iRv = ioctl(hDevice, MMC_IOC_CMD, &mmcCmd))) {
      csSet(&csErr, "Could not read response of 'ioctl' from '");
      csCat(&csErr, csErr.cStr, g_tOpts.csDevice.cStr);
      csCat(&csErr, csErr.cStr, "'\n");
      dispatchError(ERR_DEVICE, csErr.cStr);
    }
    else
      printf("Password removed.\n");

  }
  else
    printf("Card temporarily unlocked.\n");


unlockDeviceDelPassword_clean_exit:
  set_blocklen(hDevice, 512);
  csFree(&csErr);
}

/*******************************************************************************
 * Name:  setPasswd
 * Purpose: .
 *******************************************************************************/
void setPasswd(int hDevice, cstr* pcsPasswd) {
  printf("Future implementation is necessary.\n");
}

/*******************************************************************************
 * Name:  tryPasswd
 * Purpose: .
 *******************************************************************************/
void tryPasswd(int hDevice, cstr* pcsPasswd) {
  cstr csBytes = csNew(""); // Allocates a pointer to 256 chars.

  // Make a decent password, from hex chars or ASCII.
  if (!g_tOpts.iPassIsChar)
    hexChars2bytes(&csBytes, pcsPasswd);
  else
    csSet(&csBytes, pcsPasswd->cStr);

  // Decide what to do with it.
  if (g_tOpts.iUnlockDevice)
    unlockDeviceDelPassword(hDevice, pcsPasswd, 0);

  if (g_tOpts.iDelPasswd)
    unlockDeviceDelPassword(hDevice, pcsPasswd, 1);

  if (g_tOpts.iSetPasswd)
    setPasswd(hDevice, &csBytes);
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  int  hDevice = 0;
  cstr csErr   = csNew("");

  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // Check, if device can be opend with the users access rights.
  if ((hDevice = open(g_tOpts.csDevice.cStr, O_RDWR)) < 0) {
    csSet(&csErr, "Can't open device '");
    csCat(&csErr, csErr.cStr, g_tOpts.csDevice.cStr);
    csCat(&csErr, csErr.cStr, "'  without beeing root");
    dispatchError(ERR_DEVICE, csErr.cStr);
  }

  // for each password in array try an 'unlock' / 'delete password' attempt.
  for (int iPswdLine = 0; iPswdLine < g_tPswdHex.iCount; ++iPswdLine)
    tryPasswd(hDevice, &g_tPswdHex.pcsData[iPswdLine]);

  // Free all used memory, prior end of program.
  dacsFree(&g_tArgs);
  dacsFree(&g_tPswdHex);

  return ERR_NOERR;
}
