/*******************************************************************************
 ** Name: macime
 ** Purpose: What the programm should do.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 07.10.2018  JE    Created program.
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#define _XOPEN_SOURCE 700   // To get POSIX 2008 (SUS) strptime() and mktime()
#define _DEFAULT_SOURCE     // To use settimeofday() from 'sys/time.h'
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <utime.h>
#include <sys/stat.h>
#include <sys/sem.h>
#include <sys/time.h>
#include <pthread.h>

//#include "../../libs/c_string.h"
//#include "../../libs/c_dynamic_arrays.h"
#include "c_string.h"
#include "c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "macime"
#define ME_VERSION "0.0.1"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_TIME  0x04
#define ERR_ELSE  0xff

#define sERR_ARGS "Argument error"
#define sERR_FILE "File error"
#define sERR_TIME "Time error"
#define sERR_ELSE "Unknown error"

// isNumber()
#define NUM_NONE  0x00
#define NUM_INT   0x01
#define NUM_FLOAT 0x02

// getOptions(): Defines empty values.
#define NO_TICK -1


//******************************************************************************
//* typedefs

// For convienience.
typedef unsigned int  uint;
typedef unsigned char uchar;
typedef long double   ldbl;
typedef long long     ll;

// Arguments and options.
typedef struct {
  int    iTestMode;
  cstr   csMtime;
  cstr   csAtime;
  cstr   csCtime;
  time_t t_mtime;
  time_t t_atime;
  time_t t_ctime;
  int    fChangeMtime;
  int    fChangeAtime;
  int    fChangeCtime;
} t_options;


//******************************************************************************
//* Global variables

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  version
 * Purpose: Print version and exit program.
 *******************************************************************************/
void version(void) {
  cstr csOut = csNew(ME_NAME);

  csCat(&csOut, csOut.cStr, " v" ME_VERSION);
  printf("%s\n", csOut.cStr);

  csFree(&csOut);

  exit(ERR_NOERR);
}

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [-t] [-M <datetime>|-m <ticks>] [-A <datetime>|-a <ticks>] [-C <datetime>|-c <ticks>] file1 [file2 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Changes mtime, atime and ctime timstamps of given file(s).\n"
  " <ticks> are seconds from the beginnig of the epoch, i.e. 1970/01/01, 00.00:00.\n"
  " <datetime> is an string formatted as 'YYYY/MM/DD, hh:mm:ss'.\n"
  "  -t:            don't execute printed commands (default execute)\n"
  "  -M <datetime>: use date-time-string to change mtime\n"
  "  -m <ticks>:    use ticks to change mtime\n"
  "  -A <datetime>: use date-time-string to change atime\n"
  "  -a <ticks>:    use ticks to change atime\n"
  "  -C <datetime>: use date-time-string to change ctime\n"
  "  -c <ticks>:    use ticks to change ctime\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
        );

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE) csSet(&csErr, sERR_ARGS);
  if (rv == ERR_ELSE) csSet(&csErr, sERR_ARGS);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
* Name: shift
* Purpose: Shifts one argument from CLI and increments the counter.
*******************************************************************************/
void shift(cstr* pcsRv, int* pI, int argc, char* argv[]) {
   csSet(pcsRv, "");
   if (*pI < argc) csSet(pcsRv, argv[(*pI)++]);
}

/*******************************************************************************
 * Name:  isNumber
 * Purpose: Check if string is a int or float number.
 *******************************************************************************/
int isNumber(cstr sString, int* piSign) {
  int iDecPt = 0;

  // Assume no sign.
  *piSign = 0;

  // Check for plus or minus sign in front of number.
  if (sString.cStr[0] == '-')
    *piSign = -1;

  if (sString.cStr[0] == '+')
    *piSign = 1;

  // Continuation depends wether sign was found.
  // Check for digits and decimal point.
  for (int i = (*piSign != 0) ? 1 : 0; i < sString.len; ++i) {
    if (sString.cStr[i] == '.') {
      // Only one decimal point allowed!
      if (iDecPt)
        return NUM_NONE;
      else {
        iDecPt = 1;
        continue;
      }
    }

    // Not a digit, no number.
    if (sString.cStr[i] < '0' || sString.cStr[i] > '9')
      return NUM_NONE;
  }

  if (iDecPt)
    return NUM_FLOAT;

  return NUM_INT;
}

/*******************************************************************************
 * Name:  ticks2datetime
 * Purpose: Converts integer to "2017/11/03, 11:14:23" string.
 *******************************************************************************/
void ticks2datetime(cstr* pcsTxt, time_t* ptTicks) {
  char       acTxt[30] = {0};
  struct tm* psTime    = gmtime(ptTicks);

  // Returns "2017/11/03, 11:14:23" => 21 Bytes including '\0' Byte.
  strftime(acTxt, sizeof(acTxt), "%Y/%m/%d, %H:%M:%S", psTime);
  csSet(pcsTxt, acTxt);
}

/*******************************************************************************
 * Name:  datetime2ticks
 * Purpose: Converts ""2017/11/03, 11:14:23 (UTC)" string to ticks.
 *******************************************************************************/
time_t datetime2ticks(int fUseString, const char* pcTime,
                      int iYear, int iMonth, int iDay,
                      int iHour, int iMin,   int iSec) {
  cstr      csItem = csNew("");
  struct tm sTime  = {0};

  //                   1111111111222222
  //         01234567890123456789012345
  // Assume "2017/11/03, 11:14:23 (UTC)"
  if (fUseString) {
    csMid(&csItem, pcTime,  0, 4);
    iYear = (int) cstr2ll(csItem);

    csMid(&csItem, pcTime,  5, 2);
    iMonth = (int) cstr2ll(csItem);

    csMid(&csItem, pcTime,  8, 2);
    iDay = (int) cstr2ll(csItem);

    csMid(&csItem, pcTime, 12, 2);
    iHour = (int) cstr2ll(csItem);

    csMid(&csItem, pcTime, 15, 2);
    iMin = (int) cstr2ll(csItem);

    csMid(&csItem, pcTime, 18, 2);
    iSec = (int) cstr2ll(csItem);
  }

  // Corrections
  iYear  -= 1900;
  iMonth -= 1;

  // Fille struct;
  sTime.tm_year = iYear;    // Year	- 1900.
  sTime.tm_mon  = iMonth;   // Month.   [0-11]
  sTime.tm_mday = iDay;     // Day.     [1-31]
  sTime.tm_hour = iHour;    // Hours.   [0-23]
  sTime.tm_min  = iMin;     // Minutes. [0-59]
  sTime.tm_sec  = iSec;     // Seconds. [0-60] (1 leap second)

  sTime.tm_isdst = -1;

  // Just tick away ... timezone is set with tzset() in main().
  return mktime(&sTime) - timezone;
}

/*******************************************************************************
 * Name:  validDateTime
 * Purpose: Check time strings format '2018/10/07, 12:09:52'.
 *******************************************************************************/
int validDateTime(cstr csDateTime) {
  cstr  csYear  = csNew("");
  cstr  csMonth = csNew("");
  cstr  csDay   = csNew("");
  cstr  csHour  = csNew("");
  cstr  csMin   = csNew("");
  cstr  csSec   = csNew("");
  int   iYear   = 0;
  int   iMonth  = 0;
  int   iDay    = 0;
  int   iHour   = 0;
  int   iMin    = 0;
  int   iSec    = 0;
  int   iRv     = 1;

  //                   1111111111
  //         01234567890123456789
  // Assume "2017/11/03, 11:14:23"
  csMid(&csYear,  csDateTime.cStr,  0, 4);
  csMid(&csMonth, csDateTime.cStr,  5, 2);
  csMid(&csDay,   csDateTime.cStr,  8, 2);
  csMid(&csHour,  csDateTime.cStr, 12, 2);
  csMid(&csMin,   csDateTime.cStr, 15, 2);
  csMid(&csSec,   csDateTime.cStr, 18, 2);

  iYear  = (int) cstr2ll(csYear);
  iMonth = (int) cstr2ll(csMonth);
  iDay   = (int) cstr2ll(csDay);
  iHour  = (int) cstr2ll(csHour);
  iMin   = (int) cstr2ll(csMin);
  iSec   = (int) cstr2ll(csSec);

  if (iYear  < 1970 || iYear  > 2038) iRv = 0;
  if (iMonth <    1 || iMonth >   12) iRv = 0;
  if (iDay   <    1 || iDay   >   31) iRv = 0;
  if (iHour  <    0 || iHour  >   23) iRv = 0;
  if (iMin   <    0 || iMin   >   59) iRv = 0;
  if (iSec   <    0 || iSec   >   59) iRv = 0;

  csFree(&csYear);
  csFree(&csMonth);
  csFree(&csDay);
  csFree(&csHour);
  csFree(&csMin);
  csFree(&csSec);

  return iRv;
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csOpt  = csNew("");
  int  iArg   = 1;  // Omit programm name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;
//  int  iRv    = 0;
//  int  iPos   = 0;
//  int  iErr   = 0;
  int  iSign  = 0;

  // Set defaults.
  g_tOpts.iTestMode    = 0;
  g_tOpts.csMtime      = csNew("");
  g_tOpts.csAtime      = csNew("");
  g_tOpts.csCtime      = csNew("");
  g_tOpts.t_mtime      = NO_TICK;
  g_tOpts.t_atime      = NO_TICK;
  g_tOpts.t_ctime      = NO_TICK;
  g_tOpts.fChangeMtime = 0;
  g_tOpts.fChangeAtime = 0;
  g_tOpts.fChangeCtime = 0;


  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 't') {
          g_tOpts.iTestMode = 1;
          continue;
        }
        if (cOpt == 'M') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "mtime string is missing");
          csSet(&g_tOpts.csMtime, csRv.cStr);
          g_tOpts.fChangeMtime = 1;
          continue;
        }
        if (cOpt == 'A') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "atime string is missing");
          csSet(&g_tOpts.csAtime, csRv.cStr);
          g_tOpts.fChangeAtime = 1;
          continue;
        }
        if (cOpt == 'C') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0)
            dispatchError(ERR_ARGS, "ctime string is missing");
          csSet(&g_tOpts.csCtime, csRv.cStr);
          g_tOpts.fChangeCtime = 1;
          continue;
        }
        if (cOpt == 'm') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0 || isNumber(csRv, &iSign) != NUM_INT)
            dispatchError(ERR_ARGS, "mtime ticks are missing");
          g_tOpts.t_mtime = (time_t) cstr2ll(csRv);
          g_tOpts.fChangeMtime = 1;
          continue;
        }
        if (cOpt == 'a') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0 || isNumber(csRv, &iSign) != NUM_INT)
            dispatchError(ERR_ARGS, "atime ticks are missing");
          g_tOpts.t_atime = (time_t) cstr2ll(csRv);
          g_tOpts.fChangeAtime = 1;
          continue;
        }
        if (cOpt == 'c') {
          shift(&csRv, &iArg, argc, argv);
          if (csRv.len == 0 || isNumber(csRv, &iSign) != NUM_INT)
            dispatchError(ERR_ARGS, "ctime ticks are missing");
          g_tOpts.t_ctime = (time_t) cstr2ll(csRv);
          g_tOpts.fChangeCtime = 1;
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.iCount == 0)
    dispatchError(ERR_ARGS, "No file");

  // Check sanity if given mtime timestamp at cli.
  if (g_tOpts.fChangeMtime) {
    if (g_tOpts.t_mtime != NO_TICK && g_tOpts.csMtime.len > 0)
      dispatchError(ERR_ARGS, "Just ticks or string for mtime");

    if (!validDateTime(g_tOpts.csMtime))
      dispatchError(ERR_ARGS, "No valid date-time-string for mtime");
  }
  // Check sanity if given atime timestamp at cli.
  if (g_tOpts.fChangeAtime) {
    if (g_tOpts.t_atime != NO_TICK && g_tOpts.csAtime.len > 0)
      dispatchError(ERR_ARGS, "Just ticks or string for atime");

    if (!validDateTime(g_tOpts.csAtime))
      dispatchError(ERR_ARGS, "No valid date-time-string for atime");
  }
  // Check sanity if given ctime timestamp at cli.
  if (g_tOpts.fChangeCtime) {
    if (g_tOpts.t_ctime != NO_TICK && g_tOpts.csCtime.len > 0)
      dispatchError(ERR_ARGS, "Just ticks or string for ctime");

    if (!validDateTime(g_tOpts.csCtime))
      dispatchError(ERR_ARGS, "No valid date-time-string for ctime");
  }

  // Set missing ticks if necessary.
  if (g_tOpts.t_mtime == NO_TICK)
    g_tOpts.t_mtime = datetime2ticks(1, g_tOpts.csMtime.cStr, 0, 0, 0, 0, 0, 0);
  if (g_tOpts.t_atime == NO_TICK)
    g_tOpts.t_atime = datetime2ticks(1, g_tOpts.csAtime.cStr, 0, 0, 0, 0, 0, 0);
  if (g_tOpts.t_ctime == NO_TICK)
    g_tOpts.t_ctime = datetime2ticks(1, g_tOpts.csCtime.cStr, 0, 0, 0, 0, 0, 0);

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);

  return;
}

/*******************************************************************************
 * Name:  getMACTime
 * Purpose: .
 *******************************************************************************/
void getMACTime(cstr* pcsFile, time_t* pMtime, time_t* pAtime, time_t* pCtime) {
  struct stat s_statFile = {0};

  stat(pcsFile->cStr, &s_statFile);

  *pMtime = s_statFile.st_mtim.tv_sec;
  *pAtime = s_statFile.st_atim.tv_sec;
  *pCtime = s_statFile.st_ctim.tv_sec;
}

/*******************************************************************************
 * Name:  setMACTime
 * Purpose: .
 *******************************************************************************/
void setMACTime(cstr* pcsFile, time_t* pCtime, time_t* pMtime, time_t* pAtime) {
  pthread_mutex_t t_mutex;
  struct timeval  s_tvNow;
  struct timezone s_tzNow;
  struct timeval  s_tvCtime;
  struct timezone s_tzCtime;
  struct utimbuf  new_times;

  //printf("Use semaphores/mutexes to change ctime with more security\n");

  if (g_tOpts.fChangeCtime) {
    //- Start ----1-----------------------------------------
    pthread_mutex_lock(&t_mutex);
    if (gettimeofday(&s_tvNow, &s_tzNow))
      dispatchError(ERR_TIME, "Couldn't get system time");
    // ----------------------------------------------------

    s_tvCtime.tv_sec         = *pCtime;
    s_tvCtime.tv_usec        = 0;
    s_tzCtime.tz_dsttime     = s_tzNow.tz_dsttime;
    s_tzCtime.tz_minuteswest = s_tzNow.tz_minuteswest;
    if (settimeofday(&s_tvCtime, &s_tzCtime))
      dispatchError(ERR_TIME, "Couldn't set 'ctime'");
  }

  // Kind of 'touch' to set ctime to 'now'.
  new_times.modtime = *pMtime;
  new_times.actime  = *pAtime;
  utime(pcsFile->cStr, &new_times);

  if (g_tOpts.fChangeCtime) {
    //- End -----------------------------------------------
    if (settimeofday(&s_tvNow, &s_tzNow))
      dispatchError(ERR_TIME, "Couldn't set system time");
    pthread_mutex_unlock(&t_mutex);
    // ----------------------------------------------------
  }
}

/*******************************************************************************
 * Name:  changeMAC
 * Purpose: .
 *******************************************************************************/
void printMACTime(const char* pacTxt, cstr* pcsFile, time_t* pMtime, time_t* pAtime, time_t* pCtime) {
  cstr csMtime = csNew("");
  cstr csAtime = csNew("");
  cstr csCtime = csNew("");

  ticks2datetime(&csMtime, pMtime);
  ticks2datetime(&csAtime, pAtime);
  ticks2datetime(&csCtime, pCtime);

  // Print new settings.
  printf("%s: '%s'\n"
         "  mtime: %ld (%s)\n"
         "  atime: %ld (%s)\n"
         "  ctime: %ld (%s)\n"
         "--------------------------------------------------------------------------------\n",
          pacTxt, pcsFile->cStr,
            *pMtime, csMtime.cStr,
            *pAtime, csAtime.cStr,
            *pCtime, csCtime.cStr);

  csFree(&csMtime);
  csFree(&csAtime);
  csFree(&csCtime);
}

/*******************************************************************************
 * Name:  modeMAC
 * Purpose: .
 *******************************************************************************/
void doMAC(int fChange, cstr* pcsFile) {
  time_t mtime = {0};
  time_t atime = {0};
  time_t ctime = {0};

  getMACTime(pcsFile, &mtime, &atime, &ctime);

  printMACTime("Old", pcsFile, &mtime, &atime, &ctime);

  if (g_tOpts.fChangeMtime) mtime = g_tOpts.t_mtime;
  if (g_tOpts.fChangeAtime) atime = g_tOpts.t_atime;
  if (g_tOpts.fChangeCtime) ctime = g_tOpts.t_ctime;

  if (fChange)
    setMACTime(pcsFile, &ctime, &mtime, &atime);

  printMACTime("Now", pcsFile, &mtime, &atime, &ctime);
}

//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  FILE* hFile = NULL;

  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  // For 'timezone' var in datetime2ticks().
  tzset();

  // Loop through all files.
  for (int i = 0; i < g_tArgs.iCount; ++i) {
    // Just make sure the file exists. We only need the filename.
    if (!(hFile = fopen(g_tArgs.pcsData[i].cStr, "rb"))) {
      cstr csMsg = csNew("");
      csSetf(&csMsg, "Can't open '%s'", g_tArgs.pcsData[i].cStr);
      dispatchError(ERR_FILE, csMsg.cStr);
    }
    fclose(hFile);

    // Let's do it.
    doMAC((g_tOpts.iTestMode) ? 0 : 1, &g_tArgs.pcsData[i]);
  }

  // Free all used memory, prior end of program.
  dacsFree(&g_tArgs);

  return ERR_NOERR;
}
