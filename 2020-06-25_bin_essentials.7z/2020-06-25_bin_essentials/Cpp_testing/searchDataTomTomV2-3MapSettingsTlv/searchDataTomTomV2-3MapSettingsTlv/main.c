﻿/*******************************************************************************
 ** Name: searchDataTomTomV2-3MapSettingsTlv
 ** Purpose: Extract all valid TomTom Live position entries from file or image.
 ** Author: (JE) Jens Elstner <jens.elstner@bka.bund.de>
 *******************************************************************************
 ** Date        User  Log
 **-----------------------------------------------------------------------------
 ** 01.01.2018  JE    Created program from
 **                   'searchDataTomTomV2-3MapSettingsTlv_s3g.pl'.
 ** 15.04.2020  JE    Now use stdfcns.c v0.6.1.
 *******************************************************************************
 ** Skript tested with:
 ** TomTom Via series.
 ** mapsettings,tlv files.
 ** TomTom *.tlv files from Hacky V3 Modell 610
 *******************************************************************************/


//******************************************************************************
//* includes & namespaces

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../../libs/c_string.h"
#include "../../libs/c_my_regex.h"
#include "../../libs/c_dynamic_arrays.h"


//******************************************************************************
//* defines & macros

#define ME_NAME    "searchDataTomTomV2-3MapSettingsTlv"
#define ME_VERSION "0.1.2"

#define ERR_NOERR 0x00
#define ERR_ARGS  0x01
#define ERR_FILE  0x02
#define ERR_ICONV 0x03
#define ERR_REGEX 0x04
#define ERR_ELSE  0xff

#define sERR_ARGS  "Argument error"
#define sERR_FILE  "File error"
#define sERR_ICONV "iconv error"
#define sERR_REGEX "Regex error"
#define sERR_ELSE  "Unknown error"


//******************************************************************************
//* outsourced standard functions, includes and defines

#include "../../libs/stdfcns.c"


//******************************************************************************
//* typedefs

// toWgs84().
typedef struct s_coord {
  ldbl ldlVal;
  cstr csVal;
} t_coord;

// Binary data chunks from file.
typedef struct s_data {
  uchar*  pBytes;
  size_t  sSize;
} t_data;

// Arguments and options.
typedef struct s_options {
  int iPrtPrec;
  int iPrtAllLbl;
  int iPrtAllCord;
  int iPrtOff;
} t_options;

typedef struct s_entry {
  int     iPrec;
  int     iType;
  t_coord tcLon1;
  t_coord tcLat1;
  t_coord tcLon2;
  t_coord tcLat2;
  cstr    csLbl1Sys;
  cstr    csLbl2Usr;
  cstr    csLbl3Adr;
  cstr    csLbl4No;
  t_coord tcLon3;
  t_coord tcLat3;
  t_coord tcLon4;
  t_coord tcLat4;
  t_coord tcLon5;
  t_coord tcLat5;
  t_coord tcLon6;
  t_coord tcLat6;
  t_coord tcLon7;
  t_coord tcLat7;
} t_entry;


//******************************************************************************
//* Global variables

char* g_cPrec[] = {
                    "-",
                    "City center",              // 1
                    "Street crossing",          // 2
                    "House number or premises", // 3
                    "Anywhere on a street",     // 4
                    "-"
                  };
char* g_cType[] = {
                    "-",
                    "Entered via map, zip or coord.", // 1
                    "Entered via favorite",           // 2
                    "Home location",                  // 3
                    "Entered via address",            // 4
                    "Entered via POI",                // 5
                    "Start of last calculated route", // 6
                    "-"
                  };

t_rx_matcher g_rx_c2Lbl1_Sys   = {0};
t_rx_matcher g_rx_c2Lbl2_Usr   = {0};
t_rx_matcher g_rx_c2Lbl3_Adr   = {0};
t_rx_matcher g_rx_c2Lbl4_No    = {0};
t_rx_matcher g_rx_c2Coords     = {0};
t_rx_matcher g_rx_c2Coords45   = {0};
t_rx_matcher g_rx_c4Coords67   = {0};
t_rx_matcher g_rx_c7TomTomLive = {0};

t_entry g_tE;

// Arguments
t_options    g_tOpts; // CLI options and arguments.
t_array_cstr g_tArgs; // Free arguments.


//******************************************************************************
//* Functions

/*******************************************************************************
 * Name:  usage
 * Purpose: Print help text and exit program.
 *******************************************************************************/
void usage(int iErr, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);

  // Print at least one newline with message.
  if (csMsg.len != 0)
    csCat(&csMsg, csMsg.cStr, "\n\n");

  csCat(&csMsg, csMsg.cStr,
//|************************ 80 chars width ****************************************|
  "usage: " ME_NAME " [[-p] [-l] [-c] [-o] | -a] file1 [file2 ...]\n"
  "       " ME_NAME " [-h|--help|-v|--version]\n"
  " Extract all valid TomTom Live position entries from file or image. Print\n"
  " entries in generic csv format. Search Images in chunks of 1GiB plus 1024\n"
  " overlapped bytes.\n"
  "  -p:            print precision of entry\n"
  "  -l:            print rest of labels\n"
  "  -c:            print rest of coordinates\n"
  "  -o:            print additional byte offset of entry\n"
  "  -a:            print all columns, same as -plco\n"
  "  -h|--help:     print this help\n"
  "  -v|--version:  print version of program\n"
//|************************ 80 chars width ****************************************|
);

  if (iErr == ERR_NOERR)
    printf("%s", csMsg.cStr);
  else
    fprintf(stderr, "%s", csMsg.cStr);

  csFree(&csMsg);

  exit(iErr);
}

/*******************************************************************************
 * Name:  dispatchError
 * Purpose: Print out specific error message, if any occurres.
 *******************************************************************************/
void dispatchError(int rv, const char* pcMsg) {
  cstr csMsg = csNew(pcMsg);
  cstr csErr = csNew("");

  if (rv == ERR_NOERR) return;

  if (rv == ERR_ARGS)  csSet(&csErr, sERR_ARGS);
  if (rv == ERR_FILE)  csSet(&csErr, sERR_FILE);
  if (rv == ERR_ICONV) csSet(&csErr, sERR_ICONV);
  if (rv == ERR_REGEX) csSet(&csErr, sERR_REGEX);
  if (rv == ERR_ELSE)  csSet(&csErr, sERR_ELSE);

  // Set to '<err>: <message>', if a message was given.
  if (csMsg.len != 0) csSetf(&csErr, "%s: %s", csErr.cStr, csMsg.cStr);

  usage(rv, csErr.cStr);
}

/*******************************************************************************
 * Name:  clearEntry
 * Purpose: Clears entry's struct to 'zero'.
 *******************************************************************************/
void clearEntry() {
  g_tE.iPrec         = 0;
  g_tE.iType         = 0;
  g_tE.tcLon1.ldlVal = 0.0;
  g_tE.tcLon1.csVal  = csNew("-");
  g_tE.tcLat1.ldlVal = 0.0;
  g_tE.tcLat1.csVal  = csNew("-");
  g_tE.tcLon2.ldlVal = 0.0;
  g_tE.tcLon2.csVal  = csNew("-");
  g_tE.tcLat2.ldlVal = 0.0;
  g_tE.tcLat2.csVal  = csNew("");
  g_tE.csLbl1Sys     = csNew("");
  g_tE.csLbl2Usr     = csNew("");
  g_tE.csLbl3Adr     = csNew("");
  g_tE.csLbl4No      = csNew("");
  g_tE.tcLon3.ldlVal = 0.0;
  g_tE.tcLon3.csVal  = csNew("-");
  g_tE.tcLat3.ldlVal = 0.0;
  g_tE.tcLat3.csVal  = csNew("-");
  g_tE.tcLon4.ldlVal = 0.0;
  g_tE.tcLon4.csVal  = csNew("-");
  g_tE.tcLat4.ldlVal = 0.0;
  g_tE.tcLat4.csVal  = csNew("-");
  g_tE.tcLon5.ldlVal = 0.0;
  g_tE.tcLon5.csVal  = csNew("-");
  g_tE.tcLat5.ldlVal = 0.0;
  g_tE.tcLat5.csVal  = csNew("-");
  g_tE.tcLon6.ldlVal = 0.0;
  g_tE.tcLon6.csVal  = csNew("-");
  g_tE.tcLat6.ldlVal = 0.0;
  g_tE.tcLat6.csVal  = csNew("-");
  g_tE.tcLon7.ldlVal = 0.0;
  g_tE.tcLon7.csVal  = csNew("-");
  g_tE.tcLat7.ldlVal = 0.0;
  g_tE.tcLat7.csVal  = csNew("-");
}

/*******************************************************************************
 * Name:  getOptions
 * Purpose: Filters command line.
 *******************************************************************************/
void getOptions(int argc, char* argv[]) {
  cstr csArgv = csNew("");
  cstr csRv   = csNew("");
  cstr csOpt  = csNew("");
  int  iArg   = 1;  // Omit program name in arg loop.
  int  iChar  = 0;
  char cOpt   = 0;

  // Set defaults.
  g_tOpts.iPrtPrec    = 0;
  g_tOpts.iPrtAllLbl  = 0;
  g_tOpts.iPrtAllCord = 0;
  g_tOpts.iPrtOff     = 0;

  clearEntry();

  // Init free argument's dynamic array.
  dacsInit(&g_tArgs);

  // Loop all arguments from command line POSIX style.
  while (iArg < argc) {
next_argument:
    shift(&csArgv, &iArg, argc, argv);
    if(strcmp(csArgv.cStr, "") == 0)
      continue;

    // Long options:
    if (csArgv.cStr[0] == '-' && csArgv.cStr[1] == '-') {
      if (!strcmp(csArgv.cStr, "--help")) {
        usage(ERR_NOERR, "");
      }
      if (!strcmp(csArgv.cStr, "--version")) {
        version();
      }
      dispatchError(ERR_ARGS, "Invalid long option");
    }

    // Short options:
    if (csArgv.cStr[0] == '-') {
      for (iChar = 1; iChar < csArgv.len; ++iChar) {
        cOpt = csArgv.cStr[iChar];
        if (cOpt == 'h') {
          usage(ERR_NOERR, "");
        }
        if (cOpt == 'v') {
          version();
        }
        if (cOpt == 'p') {
          g_tOpts.iPrtPrec = 1;
          continue;
        }
        if (cOpt == 'l') {
          g_tOpts.iPrtAllLbl = 1;
          continue;
        }
        if (cOpt == 'c') {
          g_tOpts.iPrtAllCord = 1;
          continue;
        }
        if (cOpt == 'o') {
          g_tOpts.iPrtOff = 1;
          continue;
        }
        if (cOpt == 'a') {
          g_tOpts.iPrtPrec    = 1;
          g_tOpts.iPrtAllLbl  = 1;
          g_tOpts.iPrtAllCord = 1;
          g_tOpts.iPrtOff     = 1;
          continue;
        }
        dispatchError(ERR_ARGS, "Invalid short option");
      }
      goto next_argument;
    }
    // Else, it's just a filename.
    dacsAdd(&g_tArgs, csArgv.cStr);
  }

  // Sanity check of arguments and flags.
  if (g_tArgs.sCount == 0) dispatchError(ERR_ARGS, "No file");

  // Free string memory.
  csFree(&csArgv);
  csFree(&csRv);
  csFree(&csOpt);
}

/*******************************************************************************
 * Name:  initMatcher
 * Purpose: Initialize Matcher struct with regex string.
 *******************************************************************************/
void initMatcher(t_rx_matcher* pMatcher, const char* pcRegex) {
  cstr csErr = csNew("");
  if (rxInitMatcher(pMatcher, pcRegex, "", &csErr) != RX_NO_ERROR)
    dispatchError(ERR_REGEX, csErr.cStr);
}

/*******************************************************************************
 * Name:  initGlobalRegexes
 * Purpose: Assembles all global regexes.
 *******************************************************************************/
void initGlobalRegexes(void) {
  char* C                = "[\\x00-\\xff]";
  cstr  cs_rx_cPrec      = csNew("");
  cstr  cs_rx_cType      = csNew("");
  cstr  cs_rx_c2Coords_1 = csNew("");
  cstr  cs_rx_c2Coords_2 = csNew("");
  cstr  cs_rx_temp       = csNew("");

  //  Main header fields:          Tag   Length  Tag Length  Value
  csSetf(&cs_rx_cPrec,      "(?x: \\x81\\x19  \\x03  \\x68  \\x01  (%s) )", C);
  csSetf(&cs_rx_cType,      "(?x: \\x82\\x19  \\x03  \\x68  \\x01  (%s) )", C);
  csSetf(&cs_rx_c2Coords_1, "(?x: \\x83\\x19  \\x0a  \\x66  \\x08  (%s{4})(%s{4}) )", C, C);
  csSetf(&cs_rx_c2Coords_2, "(?x: \\x84\\x19  \\x0a  \\x66  \\x08  (%s{4})(%s{4}) )", C, C);

  // Rest of labels and coordinates.
  csSetf(&cs_rx_temp, "(?x: \\x85\\x19 (%s) \\x64 (%s) )", C, C);
  initMatcher(&g_rx_c2Lbl1_Sys, cs_rx_temp.cStr);

  csSetf(&cs_rx_temp, "(?x: \\x86\\x19 (%s) \\x64 (%s) )", C, C);
  initMatcher(&g_rx_c2Lbl2_Usr, cs_rx_temp.cStr);

  csSetf(&cs_rx_temp, "(?x: \\x87\\x19 (%s) \\x64 (%s) )", C, C);
  initMatcher(&g_rx_c2Lbl3_Adr, cs_rx_temp.cStr);

  csSetf(&cs_rx_temp, "(?x: \\xf5\\x1c (%s) \\x64 (%s) )", C, C);
  initMatcher(&g_rx_c2Lbl4_No, cs_rx_temp.cStr);

  csSetf(&cs_rx_temp, "(?x: \\xf6\\x1c \\x0a \\x66 \\x08 (%s{4})(%s{4}) )", C, C);
  initMatcher(&g_rx_c2Coords, cs_rx_temp.cStr);

  csSetf(&cs_rx_temp, "(?x: \\xba\\x17 \\x0a \\x66 \\x08 (%s{4})(%s{4}) )", C, C);
  initMatcher(&g_rx_c2Coords45, cs_rx_temp.cStr);

  csSetf(&cs_rx_temp, "(?x: \\x8f\\x19 \\x12 \\x67 \\x10 (%s{4})(%s{4})(%s{4})(%s{4}) )", C, C, C, C);
  initMatcher(&g_rx_c4Coords67, cs_rx_temp.cStr);

  //  qr/
  //    rx_cPrec rx_cType.cStr rx_c2Coords_1.cStr rx_c2Coords_2.cStr
  //      (C+?)
  //    (?= (?: rx_cPrec rx_cType rx_c2Coords_1 rx_c2Coords_2 ) | \Z | )
  //  /xo
  // Last " | )" must be there to prevent ([\x00-\xff]?) causing limit errors!
  csSetf(&cs_rx_temp,
           "(?x:"
             "%s %s %s %s"
               "(%s?)"
             "(?= (?: %s %s %s %s ) | \\Z | )"
           ")",
           cs_rx_cPrec.cStr, cs_rx_cType.cStr, cs_rx_c2Coords_1.cStr, cs_rx_c2Coords_2.cStr,
           C,
           cs_rx_cPrec.cStr, cs_rx_cType.cStr, cs_rx_c2Coords_1.cStr, cs_rx_c2Coords_2.cStr
        );
  initMatcher(&g_rx_c7TomTomLive, cs_rx_temp.cStr);

  csFree(&cs_rx_cPrec);
  csFree(&cs_rx_cType);
  csFree(&cs_rx_c2Coords_1);
  csFree(&cs_rx_c2Coords_2);
  csFree(&cs_rx_temp);
}

/*******************************************************************************
 * Name:  freeRxStructs
 * Purpose: Free all global regex structs.
 *******************************************************************************/
void freeRxStructs(void) {
  rxFreeMatcher(&g_rx_c2Lbl1_Sys);
  rxFreeMatcher(&g_rx_c2Lbl2_Usr);
  rxFreeMatcher(&g_rx_c2Lbl3_Adr);
  rxFreeMatcher(&g_rx_c2Lbl4_No);
  rxFreeMatcher(&g_rx_c2Coords);
  rxFreeMatcher(&g_rx_c2Coords45);
  rxFreeMatcher(&g_rx_c4Coords67);
  rxFreeMatcher(&g_rx_c7TomTomLive);
}

/*******************************************************************************
 * Name:  printHeader
 * Purpose: Prints generic csv file header.
 *******************************************************************************/
void printHeader(void) {
  printf("Remark\tLongitude\tLatitude\tLabel");

  if (g_tOpts.iPrtPrec)
    printf("\tPrecision");

  if (g_tOpts.iPrtAllLbl) {
    printf("\tLabel System");
    printf("\tLabel User");
    printf("\tLabel Address");
    printf("\tLabel Street No");
  }
  if (g_tOpts.iPrtAllCord) {
    printf("\tCoordinates nearby street");
    printf("\tCoordinates target");
    printf("\tCoordinates helper");
    printf("\tCoordinates helper");
    printf("\tCoordinates helper");
    printf("\tCoordinates helper");
  }
  if (g_tOpts.iPrtOff)
    printf("\tOffset");

  printf("\n");
}

//*******************************************************************************
//* Name:  getLable
//* Purpose: Cut labels from tlv: 85 19 l1 64 l2 "data".
//*******************************************************************************
void getLable(t_rx_matcher* rxMatcher, t_data* ptData, cstr* pcsLbl) {
  cstr csLbl = csNew("");
  int  iOff  = rxMatcher->dasEnd.pSize[2];
  int  iLen1 = toInt((char*) &ptData->pBytes[rxMatcher->dasStart.pSize[1]], 1);
  int  iLen2 = toInt((char*) &ptData->pBytes[rxMatcher->dasStart.pSize[2]], 1);

  // Error check.
  if (iLen1 != iLen2 + 2) return;

  // Create string with special printf format using a length and an offset.
  csSetf(&csLbl, "%.*s", iLen2, &ptData->pBytes[iOff]);

  csSanitize(&csLbl);

  csSet(pcsLbl, csLbl.cStr);

  csFree(&csLbl);
}

//*******************************************************************************
//* Name:  getLblWrapper
//* Purpose: Ease the use of getLable().
//*******************************************************************************
void getLblWrapper(t_rx_matcher* rxM, t_data* ptD, size_t sOff, cstr* csLbl) {
  cstr csErr = csNew("");
  int  iErr  = 0;

  // Shorten by copying.
  char*  pB = (char*) ptD->pBytes;
  size_t sS = ptD->sSize;

  // Fetch matched string.
  if (rxMatch(rxM, sOff, pB, sS, &iErr, &csErr)) {
    getLable(rxM, ptD, csLbl);
    if (! csIconv(csLbl, csLbl, "ISO8859-1", "UTF-8//TRANSLIT"))
      dispatchError(ERR_ICONV, "codepage conversion failed");
  }
}

//*******************************************************************************
//* Name:  getLables
//* Purpose: Searches for the labels and converts them to utf8.
//*******************************************************************************
void getLables(t_data* ptD, size_t sOff) {
  getLblWrapper(&g_rx_c2Lbl1_Sys, ptD, sOff, &g_tE.csLbl1Sys);
  getLblWrapper(&g_rx_c2Lbl2_Usr, ptD, sOff, &g_tE.csLbl2Usr);
  getLblWrapper(&g_rx_c2Lbl3_Adr, ptD, sOff, &g_tE.csLbl3Adr);
  getLblWrapper(&g_rx_c2Lbl4_No,  ptD, sOff, &g_tE.csLbl4No);
}

/*******************************************************************************
 * Name:  toWgs84
 * Purpose: Converts coordinates to WGS84.
 *******************************************************************************/
int toWgs84(t_coord* ptcLon, t_coord* ptcLat) {
  // Convert given cordinates to WGS84.
  ptcLon->ldlVal = ptcLon->ldlVal / 1e5;
  ptcLat->ldlVal = ptcLat->ldlVal / 1e5;

  // Round to 5 digits.
  ptcLon->ldlVal = roundN(ptcLon->ldlVal, 5);
  ptcLat->ldlVal = roundN(ptcLat->ldlVal, 5);

  // Check coordinate's integrity.
  if (ptcLon->ldlVal < -180.0 || ptcLon->ldlVal > 180.0) {
    ptcLon->ldlVal = 0;
    ptcLat->ldlVal = 0;
    return 0;
  }
  if (ptcLat->ldlVal <  -90.0 || ptcLat->ldlVal >  90.0) {
    ptcLon->ldlVal = 0;
    ptcLat->ldlVal = 0;
    return 0;
  }

  // Write to 5 digits formated floating points into srings.
  csSetf(&ptcLon->csVal, "%.5Lf", ptcLon->ldlVal);
  csSetf(&ptcLat->csVal, "%.5Lf", ptcLat->ldlVal);

  return 1;
}

//*******************************************************************************
//* Name:  getCoord
//* Purpose: Converts one or two coordinate pairs from bin to integer.
//*******************************************************************************
void getCoord(t_rx_matcher* rxM, t_data* ptD, ldbl* ldLo1, ldbl* ldLa1, ldbl* ldLo2, ldbl* ldLa2) {
  *ldLo1 = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[1]], 4);
  *ldLa1 = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[2]], 4);
  if (! (ldLo2 != NULL && ldLa2 != NULL)) return;
  *ldLo2 = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[3]], 4);
  *ldLa2 = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[4]], 4);
}

//*******************************************************************************
//* Name:  getCordWrapper
//* Purpose: Ease the use of getCoord().
//*******************************************************************************
void getCordWrapper(t_rx_matcher* rxM, t_data* ptD, size_t sOff, t_coord* tcLon1, t_coord* tcLat1, t_coord* tcLon2, t_coord* tcLat2) {
  cstr csErr = csNew("");
  int  iErr  = 0;

  // Shorten by copying.
  char*  pB    = (char*) ptD->pBytes;
  size_t sS    = ptD->sSize;
  ldbl*  pLon1 = &tcLon1->ldlVal;
  ldbl*  pLat1 = &tcLat1->ldlVal;
  ldbl*  pLon2 = &tcLon2->ldlVal;
  ldbl*  pLat2 = &tcLat2->ldlVal;

  // Get one or two pairs of coordinates from matches.
  if (rxMatch(rxM, sOff, pB, sS, &iErr, &csErr)) {
    getCoord(rxM, ptD, pLon1, pLat1, pLon2, pLat2);
    toWgs84(tcLon1, tcLat1);
    if (tcLon2 != NULL && tcLat2 != NULL)
      toWgs84(tcLon2, tcLat2);
  }

  csFree(&csErr);
}

//*******************************************************************************
//* Name:  getCoordinates
//* Purpose: Searches for rest of coordinate pairs and converts them to wgs84.
//*******************************************************************************
void getCoordinates(t_data* ptD, size_t sOff) {
  // Coordinate pairs 4 and 5 have the same header, that's why they have to be
  // matched one after the other with RX_KEEP_POS.
  getCordWrapper(&g_rx_c2Coords,   ptD,        sOff, &g_tE.tcLon3, &g_tE.tcLat3,         NULL,         NULL);
  getCordWrapper(&g_rx_c2Coords45, ptD,        sOff, &g_tE.tcLon4, &g_tE.tcLat4,         NULL,         NULL);
  getCordWrapper(&g_rx_c2Coords45, ptD, RX_KEEP_POS, &g_tE.tcLon5, &g_tE.tcLat5,         NULL,         NULL);
  getCordWrapper(&g_rx_c4Coords67, ptD,        sOff, &g_tE.tcLon6, &g_tE.tcLat6, &g_tE.tcLon7, &g_tE.tcLat7);
}

/*******************************************************************************
 * Name:  getData
 * Purpose: Gets raw bytes and converts them to readable data.
 *******************************************************************************/
int getData(t_rx_matcher* rxM, t_data* ptD) {
  size_t sPos = rxM->dasStart.pSize[0];

  // Convert matched bytes.
  g_tE.iPrec         = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[1]], 1);
  g_tE.iType         = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[2]], 1);
  g_tE.tcLon1.ldlVal = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[3]], 4);
  g_tE.tcLat1.ldlVal = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[4]], 4);
  g_tE.tcLon2.ldlVal = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[5]], 4);
  g_tE.tcLat2.ldlVal = toInt((char*) &ptD->pBytes[rxM->dasStart.pSize[6]], 4);

  // Quick error check.
  if (g_tE.iPrec == 0 || g_tE.iType == 0) return 0;

  // Convert and error check.
  if (! toWgs84(&g_tE.tcLon1, &g_tE.tcLat1)) return 0;
  if (! toWgs84(&g_tE.tcLon2, &g_tE.tcLat2)) return 0;

  // Get labels and the rest of coordinates (if necessary).
  getLables(ptD, sPos);
  if (g_tOpts.iPrtAllCord) getCoordinates(ptD, sPos);

  return 1;
}

/*******************************************************************************
 * Name:  printEntry
 * Purpose: Prints generic csv file entry.
 *******************************************************************************/
void printEntry(size_t sOffset) {
  cstr csPrec = csNew("");
  cstr csType = csNew("");
  cstr csLbl  = csNew("-");

  if (g_tE.iPrec < 1 || g_tE.iPrec > 4)
    csSetf(&csPrec, "Unkown (0x%02x)", g_tE.iPrec);
  else
    csSet(&csPrec, g_cPrec[g_tE.iPrec]);
  if (g_tE.iType < 1 || g_tE.iType > 6)
    csSetf(&csType, "Unkown (0x%02x)", g_tE.iType);
  else
    csSet(&csType, g_cType[g_tE.iType]);

  // The first location is the supposed target.
  // The second location is perpendicular to the target's nearest street.
  // The third location is the target.
  // All subsequent locations are likely helper for routing to the target.
  //
  //                  1st/3rd            |  |  |
  //                                     |  |  |
  // ------------------------------------+     +---
  // -  -  -  -  -  - 2nd -  -  -  -  -  -  -  -  -
  // -----+     +------------------------+     +---
  //      |  |  |                        |  |  |
  //      |  |  |                        |  |  |

  if (g_tE.csLbl1Sys.len > 0) csSet(&csLbl, g_tE.csLbl1Sys.cStr);
  if (g_tE.csLbl2Usr.len > 0) csSet(&csLbl, g_tE.csLbl2Usr.cStr);
  if (g_tE.csLbl3Adr.len > 0) csSet(&csLbl, g_tE.csLbl3Adr.cStr);

  printf("%s\t%s\t%s\t%s", csType.cStr, g_tE.tcLon1.csVal.cStr, g_tE.tcLat1.csVal.cStr, csLbl.cStr);

  if (g_tOpts.iPrtPrec)
    printf("\t%s", csPrec.cStr);
  if (g_tOpts.iPrtAllLbl) {
    printf("\t%s", g_tE.csLbl1Sys.cStr);
    printf("\t%s", g_tE.csLbl2Usr.cStr);
    printf("\t%s", g_tE.csLbl3Adr.cStr);
    printf("\t%s", g_tE.csLbl4No.cStr);
  }
  if (g_tOpts.iPrtAllCord) {
    printf("\t%s;%s", g_tE.tcLon2.csVal.cStr, g_tE.tcLat2.csVal.cStr);
    printf("\t%s;%s", g_tE.tcLon3.csVal.cStr, g_tE.tcLat3.csVal.cStr);
    printf("\t%s;%s", g_tE.tcLon4.csVal.cStr, g_tE.tcLat4.csVal.cStr);
    printf("\t%s;%s", g_tE.tcLon5.csVal.cStr, g_tE.tcLat5.csVal.cStr);
    printf("\t%s;%s", g_tE.tcLon6.csVal.cStr, g_tE.tcLat6.csVal.cStr);
    printf("\t%s;%s", g_tE.tcLon7.csVal.cStr, g_tE.tcLat7.csVal.cStr);
  }
  if (g_tOpts.iPrtOff)
    printf("\t%lu",   sOffset);

  printf("\n");

  // Reset entry.
  clearEntry();

  csFree(&csPrec);
  csFree(&csType);
  csFree(&csLbl);
}

/*******************************************************************************
 * Name:  readBytes2ByteArray
 * Purpose: Reads count bytes at offset into the dynamic byte array.
 *******************************************************************************/
int readBytes2ByteArray(t_data* ptData, size_t sOff, size_t sCount, FILE* hFile) {
  // Set file to offset befor reading from it!
  fseek(hFile, sOff, SEEK_SET);

  // Allocate memory only once.
  if (ptData->pBytes == NULL) ptData->pBytes = (uchar*) malloc(sCount);

  // Now read all
  ptData->sSize = fread(ptData->pBytes, sizeof(char), sCount, hFile);

  // No bytes is the end of file.
  if (ptData->sSize == 0) {
    free(ptData->pBytes);
    return 0;
  }

  return 1;
}

/*******************************************************************************
 * Name:  getNextDataChunk
 * Purpose: Wrapper function for readBytes2ByteArray().
 *******************************************************************************/
int getNextDataChunk(t_data* ptData, size_t sChunkSize, size_t sChunk, size_t sTwice, FILE* hFile) {
  return readBytes2ByteArray(ptData, sChunk * sChunkSize, sChunkSize + sTwice, hFile);
}


//******************************************************************************
//* main

int main(int argc, char *argv[]) {
  FILE*  hFile  = NULL;
  size_t sOff   = 0;
  size_t sChunk = 0;

  // 1 GiB chunks with 1 KiB overlap.
  t_data tData      = {0};
  size_t sChunkSize = 1024 * 1024 * 1024;
  size_t sTwice     = 1024;

  // Regex helper vars.
  cstr csErr = csNew("");
  int  iErr  = 0;


  // Get options and dispatch errors, if any.
  getOptions(argc, argv);

  initGlobalRegexes();

  initTimeFunctions();

  printHeader();

  // 'tData' will be initialized and destroyed in 'getNextDataChunk()'.

  // Get all data from all files.
  for (int i = 0; i < g_tArgs.sCount; ++i) {
    hFile = openFile(g_tArgs.pStr[i].cStr, "rb");
//-- file ----------------------------------------------------------------------
    sChunk       = 0;
    tData.pBytes = NULL;
    tData.sSize  = 0;
    while (getNextDataChunk(&tData, sChunkSize, sChunk, sTwice, hFile)) {
      g_rx_c7TomTomLive.sPos = 0; // Reset start of regex for each chunk.
      while (rxMatch(&g_rx_c7TomTomLive, RX_KEEP_POS, (char*) tData.pBytes, tData.sSize, &iErr, &csErr)) {
        // Get global offset.
        sOff = sChunk * sChunkSize + g_rx_c7TomTomLive.dasStart.pSize[0];

        if (! getData(&g_rx_c7TomTomLive, &tData)) continue;
        printEntry(sOff);
      }
      ++sChunk;
    }
//-- file ----------------------------------------------------------------------
    fclose(hFile);
  }

  // Free all used memory, prior end of program.
  csFree(&csErr);
  dacsFree(&g_tArgs);
  freeRxStructs();

  return ERR_NOERR;
}
